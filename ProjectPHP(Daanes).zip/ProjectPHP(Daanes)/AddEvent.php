<?php
$cookie = $_COOKIE['username'];
echo  "Welcome, ".$cookie;
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
    <title>Add Event</title>
    <link href="navigation.css" rel="stylesheet" type="text/css">
</head>

<p align="right" style=" margin-right:150px; font-size:20px;" ><label>Logout</label> &nbsp; <a href="default.php">Sign Out</a></p>

<body align="center;">

<div align="center" id="container"  >
	<ul style="align-content:center;">
    	<li><a href="defaultUser.php">Home</a></li>
        <li><a href="AddEvent.php">Add Route</a></li>
        <li><a href="Update.php">Update Route</a></li>
        <li><a href="Delete.php">Delete Route</a></li>
	</ul>
</div>


<form action="event.php" method="post" enctype="multipart/form-data" style=" align-content:center; padding:100px; margin-top:0px; height:50px;">
       <h4 style="text-align: center; font-size:40px;"><strong>Add Car Pool Route&nbsp;</strong></h4>
       <br>
      <table style="height: 280px; margin-left: auto; margin-right: auto; border-radius:45px; padding:5px;" width="500">
            <tbody>
                <tr>
                <td>
                <h3 style="text-align: center;"><strong>Route Name:</strong></h3>
                </td>
                <td style="text-align: center;"><input name="eventname" type="text" placeholder="route name" required="" oninvalid="this.setCustomValidity('Please Enter Route Name')" oninput="setCustomValidity('')" /></td>
                </tr>
                <tr style="text-align: center;">
                <td>
                <h3><strong>Starting Point</strong></h3>
                </td>
                <td><input name="starting_point" type="text" placeholder=" starting point" required="" oninvalid="this.setCustomValidity('Please Enter Starting Point')"oninput="setCustomValidity('')" /></p></td>
                </tr>
                <tr style="text-align: center;">
                <td>
                <h3><strong>Destination Point</strong></h3>
                </td>
                <td><input name="destination_point" type="text" placeholder=" destination point" required="" oninvalid="this.setCustomValidity('Please Enter Destination Point')" oninput="setCustomValidity('')"/></p></td>
                </tr>
                <tr style="text-align: center;">
                <td>
                <h3><strong>Time</strong></h3>
                </td>
                <td><input name="time" type="time" required="" oninvalid="this.setCustomValidity('Select Time')" oninput="setCustomValidity('')"/></p></td>
                </tr>
                <tr style="text-align: center;">
                <td>
                <h3><strong>Date</strong></h3>
                </td>
                <td><input name="date" type="date" min="2016-01-01" max="2021-12-31" required="" oninvalid="this.setCustomValidity('Select Date')"  oninput="setCustomValidity('')"/></p></td>
                </tr>
                <tr style="text-align: center;">
                	<td>&nbsp;</td>
                    <td><input name="image" type="file" multiple /></p></td>

                	<!--<td><input type="submit" value="Upload" name="upload"/></p></td>-->
                </tr>
                <tr style="text-align: center;">
                <td>
                <h3><strong>Comment</strong></h3>
                </td>
                <td><input name="comment"  type="text" placeholder=" comment" cols="50" rows="10" style="width:300px; text-wrap:normal; height:70px;" /></p></td>
                </tr>
                <tr style="text-align: center;">
                <td>&nbsp;</td>
                <td><input name="event" type="submit" value="Create" style="border-radius: 8px; border-width: medium;width: 100px;height: 45px;"/></td>
                </tr>
            </tbody>
        </table>
        <br>
</form>
<!--<form action="" method="post" enctype="multipart/form-data" style="padding:100px;margin-top:45px;height:50px;">
		<table>
            <tbody>
            	<h3><strong>Optional:-</strong></h3>
                <br>
                <tr style="text-align: center;">
                <td>
                <h3><strong>Select image to upload :</strong></h3>
                </td>
                <td>&nbsp;</td>
                </tr>
                <tr style="text-align: center;">
                	<td><input name="image" type="file" multiple/></p></td>

                	<td><input type="submit" value="Upload" name="upload"/></p></td>
                </tr>
             </tbody>
         </table>
</form>-->


</body>
</html>
