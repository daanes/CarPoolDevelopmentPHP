<?php
          include 'config.php';
		  
         //$conn = mysqli_connect('localhost', 'root', '', 'php'); 
        
            $event_id =$_REQUEST['event_id'];
            
            $delete = "DELETE FROM event WHERE event_id = '$event_id'";
            // sending query;
            mysqli_query($conn , $delete);
            
            header("Location: Delete.php");
            
            mysqli_close($conn);
        ?>