<?php

//if(strlen($_POST['password']) > 5){
//	echo 'ERROR: password is too short';
//}else{
//	echo 'Congratulations! Your password is secured';
//}

include 'config.php';

function send_mail($email,$message,$subject)
 {      
	require 'phpmailer/PHPMailerAutoload.php'; /*  <----This thing need PHPMailer.. Remember dont delete PHPMailer !*/

		$mail = new PHPMailer;

		//$mail->SMTPDebug = 3;                               // Enable verbose debug output
		$mail->isSMTP();                                      // Set mailer to use SMTP
		$mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
		$mail->SMTPAuth = true;                               // Enable SMTP authentication
		$mail->Username = 'daanes.dev@gmail.com';                 // SMTP username
		$mail->Password = 'daanes94';                           // SMTP password
		$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
		$mail->Port = 587;                                    // TCP port to connect to

		$mail->setFrom('fdaanes.dev@gmail.com', 'Mailer');
		$mail->addAddress('daanes.dev@gmail.com', 'Admin');     // Add a recipient
		$mail->addAddress($email);               // Name is optional
		$mail->addReplyTo('daanes.dev@gmail.com', 'Information');

		$mail->isHTML(true);                                  // Set email format to HTML
		$mail->Subject = $subject;
		$mail->MsgHTML($message);

		if(!$mail->send()) 
		{
			echo 'Message could not be sent.';
			echo 'Mailer Error: ' . $mail->ErrorInfo;
		} 
		else 
		{
			echo 'Message has been sent';
		}

 }
 
 //$email = trim($_POST['email']); /* <--this email will received a mail from sender*/
// $length = 5;
//
//$randomString = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, $length);

$link = mysqli_connect("localhost", "root", "", "php");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

$email = trim($_POST['email']); /* <--this email will received a mail from sender*/
 $length = 5;

$randomString = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, $length);


$username = mysqli_real_escape_string($link, $_POST['username']);
$password = mysqli_real_escape_string($link, $_POST['password']);
//$isql = "UPDATE login SET activation='$randomString' WHERE username='$username'";
//$link->query($isql);
  
   $message = "  
   		
	  You have an email from Carpool Website from Royal Borough Greenwich	
	  <br /><br />   
      Email Confirmation & Activation
      <br /><br />
	 Your username : $username <br/>
	 Your password : $password <br/>
	  
      This is your Carpool Activation Code<br/><br>
	  $randomString<br/>
	  <br>
     Please activate your Account!<br/>";
      
   $subject = "Registration for Carpool Route Website";
      
    /* <---- use the function created at top */




if (isset($_POST['submit'])) {
/*
Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password)
*/
$link = mysqli_connect("localhost", "root", "", "php");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Escape user inputs for security
$username = mysqli_real_escape_string($link, $_POST['username']);
$email = mysqli_real_escape_string($link, $_POST['email']);
$password = mysqli_real_escape_string($link, $_POST['password']);
//$password = sha1($password); //encryption password purpose
$captcha = mysqli_real_escape_string($link, $_POST['captcha']);
 

//Username prevent from duplication.

$userdup = "SELECT * FROM login WHERE username='$username' ";
$result = $conn->query($userdup);

if ($row = $result->fetch_assoc()) {
	echo ("Your username exists!");
}
else {
	

// attempt insert query execution

$sql = "INSERT INTO login (username, email, password, captcha, activation) VALUES ('$username', '$email', '$password', '$captcha', '$randomString') ";
if(mysqli_query($link, $sql)){
    echo "Records added successfully.";
	 send_mail($email,$message,$subject);
	 header('location:activate.php');
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// close connection
mysqli_close($link);
}
}
?>