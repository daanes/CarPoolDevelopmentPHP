<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Activate Account</title>
<link href="navigation.css" rel="stylesheet" type="text/css">
</head>

<body>

<div align="center" id="container" >
                <ul style="align-content:center; text-align:center;">
                    <li><a href="default.php">Home</a></li>
                    <li><a href="Register.html">Register</a></li>
                    <li><a href="Login.html">Login</a></li>
                    <li><a href="activate.php">Activation</a></li>
                </ul>
 </div>
            
<form name="activate" action="?" method="post" >
			<br>
            <br>
            <br>
            <p>&nbsp;</p>
            <h4 style="text-align: center; font-size:40px;"><strong>Activation Form&nbsp;</strong></h4>
            <p>&nbsp;</p>
                <table style="height: 280px; margin-left: auto; margin-right: auto; border-radius:45px; background-color:#A5CEFF; color:white;padding:5px;"" width="500">
                    <tbody>
                    <tr>
                    <td> 
                    <h3 style="text-align: center; font-size:20px; color:#3B3B3B;" ><strong>User Name :</strong></h3>
                    </td>
                    <td style="text-align: center;"><input name="username" type="text" placeholder=" username" required style="width: 180px; height: 30px; border-radius: 15px; text-align:center;" /></td>
                    </tr>
                    <tr style="text-align: center;">
                    <td>
                    <h3 style="text-align: center; font-size:20px; color:#3B3B3B;"><strong>Password :</strong></h3>
                    </td>
                    <td><input name="password" type="password" placeholder=" ******" required style="width: 180px; height: 30px; border-radius: 15px; text-align:center;"/></p></td>
                    </tr>
                    <tr style="text-align: center;">
                    <td>
                    <h3 style="text-align: center; font-size:20px; color:#3B3B3B;"><strong>Activation Code :</strong></h3>
                    </td>
                    <td><input name="activation" type="text" placeholder=" Activate code" required style="width: 180px; height: 30px; border-radius: 15px; text-align:center;"/></p></td>
                    </tr>
                    <tr style="text-align: center;">
                        <td>&nbsp;</td>
                        <td><input name="activate" type="submit" value="Activate" style="border-radius:10px; border-color: white; width:100px; height:45px;"/></td>
                        </tr>
                   	</tbody>
                  </table>

</form>

<?php
	include 'config.php';
	//include 'register.php';
	if (isset($_POST['activate'])) {			
		//$link = mysqli_connect("localhost", "root", "", "php");
//		 
//		// Check connection
//		if($link === false){
//			die("ERROR: Could not connect. " . mysqli_connect_error());
//		}
	
		$username=$_POST['username'];
		$password=$_POST['password'];
		//$password = sha1($password);
		$activation =$_POST['activation'];

	$sql = "SELECT * FROM login WHERE username='$username' AND password='$password' AND activation='$activation' AND active='0' ";
	$result = $conn->query($sql);
	
	if (!$row = $result->fetch_assoc()) {
	echo ("Activation number incorrect");
	
	}
	else {
		//echo ("You are logged in!");
		$update ="UPDATE login SET active='1' WHERE username='$username'";
		
		if(mysqli_query($conn, $update)){
			echo ("You are logged in!");
			header('location:defaultUser.php');
			//header('Location: http://www.example.com/')
		} else {
				
			echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
			
			//header('location:activate.php');
			
		}
		
		
	}

}
		
//	
//	if ($randomString = $activation) {
//		echo ("Activate");
//		//Update active column to 1 table to the particular username
//		$sql = "UPDATE login SET active='1' WHERE username='$username'";
//		
//		if ($link->query($sql) === TRUE) {
//			echo "Member Activated";
//		} else {
//			echo "Not Activated" . $link->error;
//		}	
//		
//	}
//	else {
//		echo ("Activation is incorrect");
//	}
	
		

?>


</body>
</html>