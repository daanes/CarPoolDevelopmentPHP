<?php
$conn = mysqli_connect("localhost", "root", "", "php");

$event_id = $_REQUEST['event_id'];

$sql = "SELECT * FROM event WHERE event_id  = '$event_id'";

$result = mysqli_query($conn,$sql);

$test = mysqli_fetch_array($result);

if (!$result) 
		{
		die("Error: Data not found..");
		}
				$eventname=$test['eventname'] ;
				$image= $test['image'] ;					
				/*$Description=$test['Co'] ;*/
				$starting_point=$test['starting_point'] ;
				$destination_point=$test['destination_point'];
				$date=$test['date'];
				$time=$test['time'];
				$comment=$test['comment'];

if(isset($_POST['save']))
{	
	$eventname = $_POST['eventname'];
	$image= $_POST['image'];
	/*$Description_save = $_POST['Description'];*/
	$starting_point = $_POST['starting_point'];
	$destination_point= $_POST['destination_point'];
	$date= $_POST['date'];
	$time= $_POST['time'];
	$comment= $_POST['comment'];
	
	
	$update = "UPDATE event SET eventname ='$eventname', starting_point='$starting_point', destination_point='$destination_point', time ='$time', date ='$date', image ='$image' , comment ='$comment' 
	WHERE event_id = '$event_id'";
	
	$conn = mysqli_connect("localhost", "root", "", "php");
	
	mysqli_query($conn, $update); 
	
	echo "<script>alert('Data has been updated!')</script>";
	echo "<script>setTimeout(\"location.href = 'AddEvent.html';\",500);</script>";
	
	//echo "Saved!";
	//header("Location: Add Event.php");			
}

//mysqli_close($conn);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 

"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Edit Form</title>
</head>

<body>
<form method="post">
<table style="height: 280px; margin-left: auto; margin-right: auto; border-radius:45px; padding:5px;" width="500">
            <tbody>
                <tr>
                <td>
                <h3 style="text-align: center;"><strong>Route Name:</strong></h3>
                </td>
                <td style="text-align: center;"><input  name="eventname" type="text" value="<?php echo $eventname ?>" /></td>
                </tr>
                <tr style="text-align: center;">
                <td>
                <h3><strong>Starting Point: </strong></h3>
                </td>
                <td><input name="starting_point" type="text" value="<?php echo $starting_point ?>" /></td>
                </tr>
                <tr style="text-align: center;">
                <td>
                <h3><strong>Destination Point</strong></h3>
                </td>
                <td><input name="destination_point" type="text" value="<?php echo $destination_point ?>"/></td>
                </tr>
                <tr style="text-align: center;">
                <td>
                <h3><strong>Time</strong></h3>
                </td>
                <td><input name="time" type="time" value="<?php echo $time ?>" /></td>
                </tr>
                <tr style="text-align: center;">
                <td>
                <h3><strong>Date</strong></h3>
                </td>
                <td><input name="date" type="date" min="2016-01-01" max="2021-12-31" required="" oninvalid="this.setCustomValidity('Select Date')"  oninput="setCustomValidity('')" value="<?php echo $date ?>"/></td>
                </tr>
                <tr style="text-align: center;">
                	<td>&nbsp;</td>
                    <td><input name="image" type="file"  value="<?php echo $image ?>"/></td>

                	<!--<td><input type="submit" value="Upload" name="upload" /></p></td>-->
                </tr>
                <tr style="text-align: center;">
                <td>
                <h3><strong>Comment</strong></h3>
                </td>
                <td><input name="comment"  type="text" cols="50" rows="10" style="width:300px; text-wrap:normal; height:70px;" value="<?php echo $comment ?>" /></p></td>
                </tr>
                <tr style="text-align: center;">
                <td>&nbsp;</td>
                <td><input name="save" type="submit" value="Save" style="border-radius: 8px; border-width: medium;width: 100px;height: 45px;"/></td>
                </tr>
            </tbody>
        </table>
</form>
</body>
</html>
