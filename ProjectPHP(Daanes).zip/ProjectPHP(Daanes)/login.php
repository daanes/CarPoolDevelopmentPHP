<?php

if (isset($_POST['login'])) {

//Database Connection
include 'config.php';	

//$connection = mysql_connect("localhost", "root", "");
// Define $username and $password
$username=$_POST['username'];
$password=$_POST['password'];
//$password = sha1($password);

//Select statement used to check the username and password correct then will check whteher user is active '1'
$active = "SELECT * FROM login WHERE username='$username' AND password='$password' AND active='0' ";
$activeresult = $conn->query($active);

setcookie('username', $_POST['username'], time()+6600);

if ($row = $activeresult->fetch_assoc()) {
	//echo ("Please activate your account");
	echo "<script>alert('Please activate your account')</script>";
	echo "<script>setTimeout(\"location.href = 'activate.php';\",500);</script>";
}

else {



$sql = "SELECT * FROM login WHERE username='$username' AND password='$password' AND active='1' ";
$result = $conn->query($sql);

if (!$row = $result->fetch_assoc()) {
	
	echo "<script>alert('You username or password incorrect!')</script>";
	echo "<script>setTimeout(\"location.href = 'Login.html';\",500);</script>";
	//header('location:Register&Login.html');
	//echo ("Activate your account");
}
else {
	//echo ("You are logged in!");
	header('location:defaultUser.php');

}

}}
?>