<?php
include 'config.php';

if(isset($_POST['upload'])) {

	$image_name = $_FILES['image']['name'];
	$image_type = $_FILES['image']['type'];
	$image_size = $_FILES['image']['size'];
	$image_tmp_name = $_FILES['image']['tmp_name'];
	
	$folder="/xampp/htdocs/imageupload/";	

	if($image_type==NULL){
	 
	//header(location:"img.php");
	
	exit();
	
	}
	else  
	move_uploaded_file($image_tmp_name,"uploads/$image_name");
	echo "<script>alert('Image Succesfully Uploaded')</script>";
}
?>