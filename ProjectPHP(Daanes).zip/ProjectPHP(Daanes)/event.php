<?php


//if(isset($_POST['event'])) {
	
//Database connection from config.php file
include 'config.php';


// Escape user inputs for security
$event = mysqli_real_escape_string($conn, $_POST['eventname']);
$starting_point = mysqli_real_escape_string($conn, $_POST['starting_point']);
$destination_point = mysqli_real_escape_string($conn, $_POST['destination_point']);
$time = mysqli_real_escape_string($conn, $_POST['time']);
$date = mysqli_real_escape_string($conn, $_POST['date']);

$image = mysqli_real_escape_string($conn, $_FILES['image']['name']);

$comment = mysqli_real_escape_string($conn, $_POST['comment']);

//Image upload
	$image_name =$_FILES['image']['name'];
	//$img = file_get_contents ($image_name);
	
//$upload_image=$_FILES[" myimage "][ "name" ];
	$image_type = $_FILES['image']['type'];
	//$image_type =  mysqli_real_escape_string($conn, $_FILES['image']['type']);
	//$image_size = mysqli_real_escape_string($conn, $_FILES['image']['size']);
	$image_tmp_name =$_FILES['image']['tmp_name'];
	
	//$path="/xampp/htdocs/uploads/";	
	//$folder=$image_name;
	
	
	
	if($image_type==NULL){
	 
	 $image = NULL;
	//header(location:"img.php");
	//exit();
	
	}
	else  
	move_uploaded_file($image_tmp_name,"uploads/$image_name");
	echo "<script>alert('Image Succesfully Uploaded')</script>";
	
//$filepath=(("uploads/".$image_name));

// attempt insert query execution
$sql = "INSERT INTO event (eventname, starting_point, destination_point, time, date, image, comment) VALUES ('$event', '$starting_point', '$destination_point', '$time', '$date', '$image', '$comment')";
   
    //$stmt = mysqli_prepare($conn,$sql);
 
    //mysqli_stmt_bind_param($stmt, "s" , $img);
    //mysqli_stmt_execute($stmt);

if(mysqli_query($conn, $sql)){
    echo "<script>alert('Records added successfully')</script>";
	
	// http://www.w3schools.com/jsref/met_win_settimeout.asp
	
	echo "<script>setTimeout(\"location.href = 'defaultUser.php';\",500);</script>";
	//header("Location: defaultUser.php");
	 
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}
?>