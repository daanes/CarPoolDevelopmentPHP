<?php

 
$cookie = $_COOKIE['username'];
echo  "Welcome, ".$cookie;

?>

<?php

include 'config.php';


if (isset($_POST['search'])) {
	
	$valueSearch = $_POST['valueSearch'];
	$query = "SELECT * FROM `event` WHERE CONCAT (`event_id`, `eventname`, `starting_point`, `destination_point`, `time`, `date`) LIKE '%".$valueSearch."%'"; 
	$search_result = filterTable($query);
}
else {
	$query= "SELECT * FROM event";
	$search_result = filterTable($query); 	
}

function filterTable($query)
{	
	$connect = mysqli_connect("localhost", "root", "", "php");
	$filter_Result = mysqli_query($connect, $query);
	return $filter_Result;
}


?>
<!doctype html>

<head>
<meta charset="utf-8">
    <title>User Home</title>
    <link href="navigation.css" rel="stylesheet" type="text/css">
</head>

<!--<p align="right"><label>Not yet register?</label> &nbsp; <a href="default.html">Click Register</a></p>-->
<p align="right" style=" margin-right:150px; font-size:20px;" ><label>Logout</label> &nbsp; <a href="default.php">Sign Out</a></p>
<body>

<div align="center" id="container" >
	<ul style="align-content:center;">
    	<li><a href="defaultUser.php">Home</a></li>
        <li><a href="AddEvent.php">Add Route</a></li>
        <li><a href="Update.php">Update Route</a></li>
        <li><a href="Delete.php">Delete Route</a></li>
	</ul>
</div>


<form action="defaultUser.php" method="post" style="padding:100px;margin-top:0px; height:50px;">

           	 <h4 style="text-align: center; font-size:40px;"><strong>Car Pool Route&nbsp;</strong></h4>
            <br>
        
        <p style="font-size:24px;"> Search Route: <input name="valueSearch" type="text" name="search_box" value="" style=" border-radius:10px; width: 180px;"/>
        <input type="submit" name="search" value="Search" style=" border-radius:10px; background-color:#E9E9E9 border-width: medium;width: 100px;height: 25px;"> </p> <br>
        
        
        
        <table align ="center" width= " 100% " height=" 100% " border="1" border-radius="10px" cellpadding="1" cellspacing="1">
            <tr>
            	<th >Route No:</th>
                <th >Route Name:</th>
                <th >Starting Point:</th>
                <th>Destination Point:</th>
                <th>Time:(24H)</th>
                <th>Date:(YYYY-MM-DD)</th>
                <th>Image:</th>
                <<th>Comment:</th>
                <!--<th>Edit:</th>-->
            </tr>
        
        <?php
            while($event=mysqli_fetch_assoc($search_result)){
            $event_id = $event['event_id'];
			echo "<tr>";
			echo "<td align='center';>" .$event['event_id']."</td>";
            echo "<td align='center';>" .$event['eventname']."</td>";
            echo "<td align='center';>" .$event['starting_point']."</td>";
            echo "<td align='center';>" .$event['destination_point']."</td>";
            echo "<td align='center';>" .$event['time']."</td>";
            echo "<td align='center';>" .$event['date']."</td>";
			//echo '<img  src= "\xampp\htdocs\test\ProjectPHP(Daanes)\uploads'.$event['image'].'"/>';
			echo "<td align='center'; > <img height='100px' width='150px' src='uploads/".$event['image']."'>    </td>" ;
            echo "<td align='center';>" .$event['comment']."</td>";
			//echo"<td> <a href ='edit.php?event_id=$event_id'>Edit</a> </td>";
            echo "</tr>";
            }
        ?>
        
        </table>
        <br>
        
	</form>
</body>
</html>
