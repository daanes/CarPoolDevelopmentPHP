package com.ytlctest.corebase.reports;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Protocol;
import com.aventstack.extentreports.reporter.configuration.Theme;

import java.io.InputStream;

public class ExtentManager {
    private static final InputStream inputStream = ExtentManager.class.getClassLoader().getResourceAsStream("extentConfig.xml");
    private static ExtentReports extent;

    /**
     * Returns instance of extent reports
     *
     * @param fileName Enter the Report or file name
     * @return Returns the ExtentReports object
     */
    public static ExtentReports createInstance(String fileName) {
        ExtentSparkReporter extentSparkReporter = new ExtentSparkReporter(fileName);
        extentSparkReporter.config().setCSS("css-string");
        extentSparkReporter.config().setDocumentTitle("YTL Test Automation Report");
        extentSparkReporter.config().setEncoding("utf-8");
        extentSparkReporter.config().setJS("js-string");
        extentSparkReporter.config().setProtocol(Protocol.HTTPS);
        extentSparkReporter.config().setReportName("YTL Test Automation Report");
        extentSparkReporter.config().setTheme(Theme.DARK);
        extentSparkReporter.config().setTimeStampFormat("MMM dd, yyyy HH:mm:ss");
        extent = new ExtentReports();
        extent.attachReporter(extentSparkReporter);
        extent.setSystemInfo("Browser", System.getProperty("browser").toUpperCase());
        extent.setSystemInfo("Operating System", System.getProperty("os.name"));
        extent.setSystemInfo("Operating System Version", System.getProperty("os.version"));
        extent.setSystemInfo("Operating System Architecture", System.getProperty("os.arch"));
        extent.setSystemInfo("Java Version", System.getProperty("java.version"));
        extent.setSystemInfo("Java Runtime Version", System.getProperty("java.runtime.version"));
        return extent;
    }


    public static void main(String[] args) {
        ExtentManager.createInstance("html.html");
    }
}
