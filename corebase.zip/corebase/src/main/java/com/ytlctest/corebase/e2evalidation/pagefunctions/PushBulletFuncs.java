package com.ytlctest.corebase.e2evalidation.pagefunctions;

import com.ytlctest.corebase.e2evalidation.pageobjects.PushBulletPageObjects;
import com.ytlctest.corebase.lib.MainUtil;
import com.ytlctest.corebase.lib.PropertyHelper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;

public class PushBulletFuncs extends PushBulletPageObjects {

    private static Logger logger = LogManager.getLogger(PushBulletFuncs.class);
    private RemoteWebDriver driver;

    public PushBulletFuncs(RemoteWebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    /**
     * Method used to perform Reoad By CreditCard
     *
     * @throws Exception
     */
    public void getOTP() throws Exception {
        try {
            logger.info("Getting otp");
            MainUtil.launchURL("https://www.pushbullet.com/", driver);
            MainUtil.clickByXpath(getLoginWithGoogle(), "LOgin", driver);
            if (getLoginWIthAnotherAccount_visible())
                MainUtil.clickByXpath(getLoginWIthAnotherAccount(), "Login", driver);
            inputTextByXpath(getIdentifierId(), PropertyHelper.getTestDataValue("OBRM_EMAIL", "pdc"), "identifierId", "", driver);
            //clickByXpath(getIdentifierNext(), "identifierNext", driver);
            getIdentifierId().sendKeys(Keys.ENTER);
            inputTextByXpath(getPassword(), PropertyHelper.getTestDataValue("OBRM_PASSWORD", "pdc"), "password", "", driver);
            //clickByXpath(getPasswordNext(), "identifierNext", driver);
            getPassword().sendKeys(Keys.ENTER);
            MainUtil.clickByXpath(getSmsTexting(), "Texting", driver);
            String message = getOtpMessage().getText();
            String otp = message.split("0274 is")[1].split("for")[0].trim();
            System.out.println("OTP is" + otp);
            MainUtil.storeVariable.put("OTP", otp);
            MainUtil.clickByXpath(getProfileLogo(), "Profile Logo", driver);
            MainUtil.clickByXpath(getSignOut(), "Sign Out", driver);
            System.out.println(otp);
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD + " " + "doZohoLogin", e);
            throw e;
        }
    }
}
