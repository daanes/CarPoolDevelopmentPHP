package com.ytlctest.corebase.e2evalidation;

import com.ytlctest.corebase.e2evalidation.pagefunctions.DaoPageFuncs;
import com.ytlctest.corebase.lib.MainUtil;
import com.ytlctest.corebase.lib.PropertyHelper;
import com.ytlctest.corebase.listener.ExtentTestNGITestListener;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

public class WOMAutomation {
    static Properties prop = new Properties();
    static InputStream input = null;
    private static String womUrl = null;
    private static String womUsername = null;
    private static String womPassword = null;
    private static String womReport;
    private static String womDate = null;
    private static Logger logger = LogManager.getLogger(WOMAutomation.class);

    /**
     * This method is used to check the wom provisioning
     *
     * @param category Pass the category (For Ex: LTE Add on, BB Add on)
     * @param yesID    Pass the Yes ID
     * @param driver   Pass the driver instance
     * @throws Exception Throws exception
     */
    public static synchronized void runWomTest(String category, String yesID, RemoteWebDriver driver) throws Exception {
        try {
            ExtentTestNGITestListener.createNode("Wom Verification");
            if (category.equalsIgnoreCase("PLAN CONVERSION"))
                MainUtil.APPLICATION_NAME = "WOM";
            womUrl = PropertyHelper.getENVProperties("WOM_URL");
            if (System.getProperty("env").equalsIgnoreCase("PDC")) {
                if (!System.getProperty("location").equalsIgnoreCase("REMOTE")) {
                    womUrl = PropertyHelper.getENVProperties("WOM_URL_LOCAL");
                }
            }
            logger.info(System.getProperty("env") + " womUrl:" + womUrl);
            womUsername = PropertyHelper.getENVProperties("WOM_USERNAME").trim();
            logger.info(System.getProperty("env") + " womUsername:" + womUsername);
            womPassword = PropertyHelper.getENVProperties("WOM_PASSWORD").trim();
            logger.info(System.getProperty("env") + " womPassword:" + womPassword);
            logger.info(System.getProperty("env") + " womReport:" + womReport);
            womDate = PropertyHelper.getENVProperties("WOM_DATE").trim();
            logger.info(System.getProperty("env") + " womDate:" + womDate);
            DaoPageFuncs dao = new DaoPageFuncs(driver);
            dao.loginPage(womUrl, womUsername, womPassword);
            if (category.equalsIgnoreCase("LTE")) {
                dao.LTEDataservice(yesID, womDate);
            }
            System.out.println("");
            if (category.equalsIgnoreCase("LTE Data Voice SMS Roaming") | category.equalsIgnoreCase("LTE Data & Voice Service")) {
                dao.LTEDataAndVoice(yesID, womDate);
            }
            if (category.equalsIgnoreCase("LTE Data Service")) {
                dao.LTEData(yesID, womDate);
            }
            if (category.equalsIgnoreCase("WIMAX")) {
                dao.wimaxDataAndVoice(yesID, womDate);
            }
            if (category.equalsIgnoreCase("WIMAX DATA")) {
                dao.wimaxData(yesID, womDate);
            }
            if (category.equalsIgnoreCase("HYBRID")) {
                dao.hybrid(yesID, womDate);
            }
            if (category.equalsIgnoreCase("PLAN CONVERSION")) {
                dao.planConversionProcess(yesID, womDate);
            }
            if (category.equalsIgnoreCase("BB ADDON")) {
                dao.BB_Addon(yesID);
            }
            if (category.equalsIgnoreCase("LTE ADDON")) {
                dao.LTE_Addon(yesID);
            }
            if (category.equalsIgnoreCase("HYBRID ADDON")) {
                dao.Hybrid_Addon(yesID);
            }
            if (category.equalsIgnoreCase("HYBRID PASSWORD CHANGE")) {
                dao.Hybrid_Account_Password_Change(yesID);
            }
            if (category.equalsIgnoreCase("LTE PASSWORD CHANGE")) {
                dao.LTE_Account_Password_Change(yesID);
            }
            if (category.equalsIgnoreCase("LTE_PARTIAL_SUSPEND")) {
                dao.LTE_Partial_Suspend(yesID);
            }
            if (category.equalsIgnoreCase("LTE_FULL_SUSPEND")) {
                dao.LTE_Full_Suspend(yesID);
            }
            if (category.equalsIgnoreCase("LTE_FULL_DEACTIVATERESUME")) {
                dao.LTE_Full_DeactivateResume(yesID);
            }
            if (category.equalsIgnoreCase("LTE_FULL_SUSPENDRESUME")) {
                dao.LTE_Full_SuspendResume(yesID);
            }
            if (category.equalsIgnoreCase("LTE_DELETE_CUST")) {
                dao.LTE_Delete_Customer(yesID);
            }
            if (category.equalsIgnoreCase("SIM_REPLACEMENT")) {
                dao.LTESimReplacment(yesID, womDate);
            }
            dao.logout();
        } catch (Exception e) {
            logger.error(MainUtil.ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "runWomTest");
            throw e;
        }
    }

    public static String getDateTime() {
        logger.info("Getting system date and time");
        DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy_H_mm_ss");
        Date date = new Date();
        return dateFormat.format(date);
    }
}
