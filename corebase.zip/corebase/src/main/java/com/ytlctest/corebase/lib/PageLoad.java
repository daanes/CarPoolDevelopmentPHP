package com.ytlctest.corebase.lib;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.ytlctest.corebase.base.DriverFactory;
import com.ytlctest.corebase.pageprop.HarUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import static com.ytlctest.corebase.listener.ExtentTestNGITestListener.getTest;

public class PageLoad extends DriverFactory {

    public static boolean myElementIsClickable(WebDriver driver, By by) {
        try {
            new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(by));
        } catch (WebDriverException ex) {
            return false;
        }
        return true;
    }

    public static void captureNetwork(String pageName) {
        HarUtil hu = new HarUtil();
        hu.harParser(DriverFactory.getProxy().getHar());
        String pageData[][] = {{pageName, "<span style='color:" + ((hu.totalPageLoadTime_decimal < 10) ? "green" : "red") + ";font-weight:bold'>" + hu.totalPageLoadTime_decimal + " sec" + "</span>", "5 sec", hu.totalPageSize_decimal + " KB"}};
        ExtentColor colorPass = ExtentColor.GREEN;
        ExtentColor colorFail = ExtentColor.RED;
        getTest().get().log((hu.totalPageLoadTime_decimal < 10) ? Status.PASS : Status.FAIL, MarkupHelper.createTable(pageData));

    }


    public static void isjQueryLoaded(WebDriver driver) {
        System.out.println("Waiting for ready state complete");
        (new WebDriverWait(driver, 30)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                JavascriptExecutor js = (JavascriptExecutor) d;
                String readyState = js.executeScript("return document.readyState").toString();
                System.out.println("Ready State: " + readyState);
                return (Boolean) js.executeScript("return !!window.jQuery && window.jQuery.active == 0");
            }
        });
    }
}
