package com.ytlctest.corebase.lib.firebase4j.error;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class FirebaseException extends Throwable {

    protected static final Logger LOGGER = LogManager.getRootLogger();

    private static final long serialVersionUID = 1L;

    //	/**
//	 * Exception message
//	 *
//	 * @param message
//	 */
    public FirebaseException(String message) {
        super(message);
    }

    //	/**
//	 * Exception message with cause
//	 *
//	 * @param message
//	 * @param cause
//	 */
    public FirebaseException(String message, Throwable cause) {
        super(message, cause);
    }

}
