package com.ytlctest.corebase.lib;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import net.sf.expectit.Expect;
import net.sf.expectit.ExpectBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.util.Properties;

import static net.sf.expectit.matcher.Matchers.contains;
import static net.sf.expectit.matcher.Matchers.regexp;

public class MRMExtractor {

    private Logger logger = LogManager.getLogger(MRMExtractor.class);
    private JSch jSch;
    private Expect expect;
    private Channel channel;
    private Session session;

    public static void main(String[] args) {
        MRMExtractor mrmExtractor = new MRMExtractor();
        mrmExtractor.getJschConnection();
    }

    public Expect getJschConnection() {
        try {
            jSch = new JSch();
            if (System.getProperty("env").equalsIgnoreCase("iot"))
                session = jSch.getSession("hemanthkumar.koteeswaran", "10.26.64.102");
            else
                session = jSch.getSession("hemanthkumar.koteeswaran", "10.26.64.102");
            Properties config = new Properties();
            config.put("StrictHostKeyChecking", "no");
            session.setConfig(config);
            session.setPassword("Testmnp@123");
            session.connect();
            channel = session.openChannel("shell");
            channel.connect();
            logger.info("Establishing connection");
            expect = new ExpectBuilder()
                    .withOutput(channel.getOutputStream())
                    .withInputs(channel.getInputStream(), channel.getExtInputStream())
                    .withEchoOutput(System.out)
                    .withEchoInput(System.err)
                    .withExceptionOnFailure()
                    .build();
        } catch (JSchException | IOException e) {
            logger.error("Error during establishing JSCH Connection");
        }
        logger.info("Returning expect");
        return expect;
    }

    public void startSimulator() throws IOException {
        try {
            expect.expect(contains("$"));
            expect.sendLine("/usr/bin/sudo su -");
            expect.expect(contains("hemanthkumar.koteeswaran:"));
            expect.sendLine("Testmnp@123");
            expect.expect(contains("#"));
            expect.sendLine("sudo su - mrmadmin");
            //  expect.expect(contains("hemanthkumar.koteeswaran:"));
            //expect.sendLine("Testmnp@123");
            expect.expect(contains("$"));
            expect.sendLine("cd scripts/");
            expect.expect(contains("$"));
            expect.sendLine("./startCchSimulator.sh");
            expect.expect(contains("CCH>"));
        } catch (IOException io) {
            logger.info("Exception while starting simulator", io);
        }
    }

    public String getPortID(String ycmsNo) throws IOException, JSchException, InterruptedException {
        logger.info("Entering getPortID");
        logger.info("Sending NPR_ACK Command");
        expect.sendLine("NPR_ACK " + ycmsNo);
        String exxtract = expect.expect(regexp("</PortID>")).getBefore().trim();
        expect.expect(contains("Received: success"));
        Thread.sleep(5000);
        expect.expect(contains("CCH>"));
        logger.info("Returning PortID");
        return exxtract.substring((exxtract.length() - 19));
    }

    public void rejectPortIn(String ycmsNo, String msisdn, String reasonCode) {
        try {
            logger.info("Getting JSCH connection");
            getJschConnection();
            logger.info("Getting NPR reject");
            expect.sendLine("NPR_REJECT " + getPortID(ycmsNo) + " " + reasonCode);
        } catch (Exception e) {
            logger.error(e);
        } finally {
            try {
                expect.close();
            } catch (IOException e) {
                logger.error(e);
            }
            channel.disconnect();
            session.disconnect();
        }
    }

    public void acceptPortIn(String reasonCode) {
        try {
            logger.info("Getting PortID");
//            getPortID(MainUtil.storeVariable.get("PORT_IN_REFRENCE_NO"));
            logger.info("Sending NPR_ACK_ACC Command");
            expect.sendLine("NPR_ACCEPT " + MainUtil.storeVariable.get("PORT_IN_REFRENCE_NO") + " " + reasonCode + " " + "6" + MainUtil.storeVariable.get("WOM_YES_ID").split("@")[0] + " 2031");
            expect.expect(contains("Received: success"));
            Thread.sleep(5000);
            expect.expect(contains("CCH>"));
            logger.info("Waiting for 9 mins");
            Thread.sleep(540000);
            expect.sendLine("exit");
        } catch (Exception e) {
            logger.error(e);
        } finally {
            try {
                expect.close();
            } catch (IOException e) {
                logger.error(e);
            }
            channel.disconnect();
            session.disconnect();
        }
    }
}
