package com.ytlctest.corebase.e2evalidation.pageobjects;

import com.ytlctest.corebase.lib.AppWait;
import com.ytlctest.corebase.lib.MainUtil;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;


public class YosGmailNotificationPage extends MainUtil {

    private RemoteWebDriver driver;
    @FindBy(xpath = "//*[@id='identifierId']")
    private WebElement identifierId;
    //    @FindBy(xpath = "/html[1]/body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/span[1]/span[1]")
    @FindBy(xpath = "//span[contains(text(),'Next')]")
    private WebElement identifierNext;
    //  @FindBy(xpath = "//*[@id='identifierNext']/content/span")
    //   private WebElement identifierNext;
    @FindBy(name = "password")
    private WebElement password;
    @FindBy(xpath = "//span[contains(text(),'Next')]")
    private WebElement passwordNext;
    @FindBy(xpath = "//*[@id='yDmH0d']/div[2]/c-wiz/div/div/div[5]/div[2]/c-wiz/div/div[1]/div/div[1]/div[2]/a[2]")
    private WebElement welcomeHeader;
    //@FindBy(xpath = "//*[@id='passwordNext']/content/span")
    //private WebElement passwordNext;
    //    @FindBy(name = "q")
    @FindBy(xpath = "(//*[@aria-label='Search mail'])[1]")
    private WebElement orderid;
    //    @FindBy(xpath = "//*[@aria-label='Search Mail']")
    @FindBy(xpath = "(//*[@aria-label='Search mail'])[2]")
    private WebElement gmailSearch;
    @FindBy(xpath = "//tr[1]/td[5]/div/div/div[2]/div[1]/div/div/div[@class='av' and contains(text(),'Inbox')]")
    private WebElement inbox;
    @FindBy(xpath = "//*[@href=\"https://accounts.google.com/SignOutOptions?hl=en&continue=https://mail.google.com/mail&service=mail\"]")
    private WebElement mailService;
    @FindBy(xpath = "//div/a[contains(text(),'Sign out')]")
    private WebElement signOut;

    public YosGmailNotificationPage(RemoteWebDriver driver) {
        this.driver = driver;
    }

    public WebElement getIdentifierId() {
        return AppWait.waitForElementToBeClickable(driver, identifierId);
    }

    public WebElement getIdentifierNext() {
        return AppWait.waitForElementToBeClickable(driver, identifierNext);
    }

    public WebElement getPassword() {
        return AppWait.waitForElementToBeClickable(driver, password);
    }

    public WebElement getPasswordNext() {
        return AppWait.waitForElementToBeClickable(driver, passwordNext);
    }

    public WebElement getWelcomeHeader() {
        return AppWait.waitForElementToBeClickable(driver, welcomeHeader);
    }

    public WebElement getOrderid() {
        return AppWait.waitForElementToBeClickable(driver, orderid);
    }

    public WebElement getGmailSearch() {
        return AppWait.waitForElementToBeClickable(driver, gmailSearch);
    }

    public WebElement getInbox() {
        return AppWait.waitForElementToBeClickable(driver, inbox);
    }

    public WebElement getMailService() {
        return AppWait.waitForElementToBeClickable(driver, mailService);
    }

    public WebElement getSignOut() {
        return AppWait.waitForElementToBeClickable(driver, signOut);
    }

}
