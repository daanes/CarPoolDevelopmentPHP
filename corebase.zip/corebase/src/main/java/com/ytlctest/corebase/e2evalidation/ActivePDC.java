package com.ytlctest.corebase.e2evalidation;

import com.ytlctest.corebase.base.DriverFactory;
import com.ytlctest.corebase.lib.MainUtil;
import com.ytlctest.corebase.lib.MainUtil.ProjectConst;
import com.ytlctest.corebase.lib.SQLConnectionHelper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import static com.ytlctest.corebase.listener.ExtentTestNGITestListener.getTest;

public class ActivePDC extends DriverFactory {
    private static Logger logger = LogManager.getLogger(ActivePDC.class);

    /**
     * This will insert the created accounts details in Active PDC in STEP
     */
    public void insertIntoActivePDC(RemoteWebDriver driver) {
//        PreparedStatement preparedStatement = null;
        logger.info("Inside the method insertIntoActivePDC");
//        Connection con = null;
        String imagepath;
        String imageName;
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();
        String PLANNAME = MainUtil.storeVariable.get("PLAN_NAME");
        int planid = 0;
        String yesid = null;
        logger.info("CREATEACCOUNT_SUCCESS" + ProjectConst.VALUE.getMsg() + MainUtil.storeVariable.get("CREATEACCOUNT_SUCCESS"));
        logger.info("dateFormat.format(date)");
        try {
            if (MainUtil.storeVariable.get("CREATEACCOUNT_SUCCESS").toLowerCase().contains("successful") || MainUtil.storeVariable.get("CREATEACCOUNT_SUCCESS").toLowerCase().contains("congratulation") || MainUtil.storeVariable.get("CREATEACCOUNT_SUCCESS").toLowerCase().contains("Successfull")) {
//                try (Connection con = SQLConnectionHelper.getPMASDBConnectionStepnewSchema()) {
                try (Connection con = SQLConnectionHelper.getPMASDBConnectionStepnewSchema()) {
                    imagepath = MainUtil.storeVariable.get("IMAGE_TO_STORE");
                    logger.info("imagepath:" + imagepath);
                    String image[];
                    if (imagepath.contains("/")) {
                        image = imagepath.replace('/', ',').split(",");
                    } else {
                        image = imagepath.replace('\\', ',').split(",");
                    }
                    imageName = image[image.length - 1];
                    logger.info("ImageName" + ProjectConst.VALUE.getMsg() + imageName);
                    yesid = MainUtil.storeVariable.get("WOM_YES_ID");
                    logger.info("CONNECTION" + ProjectConst.VALUE.getMsg() + con);
                    logger.info("CONNECTION" + ProjectConst.VALUE.getMsg() + con);
//                    con = SQLConnectionHelper.getPMASDBConnectionStepnewSchema();
                    logger.info("CONNECTION" + ProjectConst.VALUE.getMsg() + con);
                    planid = checkPlanID(PLANNAME);
                    logger.info("CONNECTION" + ProjectConst.VALUE.getMsg() + con);
                    String query = "INSERT INTO active_pdc_accounts(`id`,`yes_id`,`created_at`,`updated_at`,`account_type`,`pdc_date`,`plan_name_id`,`plan_type_id`,`account_status_id`,`sim_serial_no`,`artifacts_file`,`project_name`,`transaction_date`) VALUES (UUID(),?,?,?,?,?,?,?,?,?,?,?,?)";
                    try (PreparedStatement preparedStatement = con.prepareStatement(query)) {
                        //                    preparedStatement = con.prepareStatement("INSERT INTO active_pdc_accounts(`id`,`yes_id`,`created_at`,`updated_at`,`account_type`,`pdc_date`,`plan_name_id`,`plan_type_id`,`account_status_id`,`sim_serial_no`,`artifacts_file`,`project_name`,`transaction_date`) VALUES (UUID(),?,?,?,?,?,?,?,?,?,?,?,?)");
                        preparedStatement.setString(1, yesid);
                        preparedStatement.setString(2, dateFormat.format(date));
                        preparedStatement.setString(3, dateFormat.format(date));
                        if (MainUtil.APPLICATION_NAME.equalsIgnoreCase("YOS")) {
                            preparedStatement.setInt(4, 2);
                        } else {
                            preparedStatement.setInt(4, 1);
                        }
                        preparedStatement.setString(5, dateFormat.format(date));
                        preparedStatement.setInt(6, planid);
                        preparedStatement.setInt(7, 2);
                        preparedStatement.setInt(8, 1);
                        preparedStatement.setString(9, (MainUtil.storeVariable.get("SIMNO_ID") == null ? "NA" : MainUtil.storeVariable.get("SIMNO_ID")));
                        preparedStatement.setString(10, "public/active_pdc_accounts/" + imageName);
                        preparedStatement.setString(11, MainUtil.APPLICATION_NAME);
                        preparedStatement.setString(12, dateFormat.format(date));
                        logger.info("Statement" + ProjectConst.VALUE.getMsg() + preparedStatement);
                        int affectedRows = preparedStatement.executeUpdate();
                        logger.info("###### PMAS DB ACTIVE_PDC_ACCOUNTS TABLE updated successfully:" + affectedRows);
                        getTest().get().pass("insertIntoActivePDC : YESID:" + yesid + "CREATED_DATE:" + dateFormat.format(date) + "PLAN NAME:" + PLANNAME + "BETA_GAMMA :Gamma" + "AVAILABLE_SIMNO:" + MainUtil.storeVariable.get("AVAILABLE_SIMNO") + "AVAILABLE_MSISDN:" + MainUtil.storeVariable.get("AVAILABLE_MSISDN") + "ACCOUNT_STATUS:NEW");
                        UploadFile.uploadfile(imagepath, driver);
                    }
                } catch (Exception e) {
                    logger.error(ProjectConst.EXCEPTIONTEXTMETHOD + " " + "insertIntoActivePDC", e);
                    getTest().get().fail("insertIntoActivePDC : some error occured in insertIntoActivePDC --- YESID:" + yesid + "CREATED_DATE:" + dateFormat.format(date) + "PLAN NAME:" + PLANNAME + "BETA_GAMMA :Gamma" + "AVAILABLE_SIMNO:" + MainUtil.storeVariable.get("AVAILABLE_SIMNO") + "AVAILABLE_MSISDN:" + MainUtil.storeVariable.get("AVAILABLE_MSISDN") + "ACCOUNT_STATUS:NEW");
                }
            }
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD + " " + "insertIntoActivePDC", e);
            getTest().get().fail("Please store the success text Label in CREATEACCOUNT_SUCCESS Store Variable ");
        }
    }

    /**
     * Returns the plan ID
     *
     * @param plan Pass the plan name
     * @return Returns the plan ID
     * @throws SQLException Throws SQL Exception
     */
    private int checkPlanID(String plan) {
        logger.info("Checking the plan id");
        int planID = 0;
        Connection con = null;
        String planName = plan;
        ResultSet rs1 = null;
        Statement stmt = null;
        PreparedStatement preparedStatement = null;
        try {
            con = SQLConnectionHelper.getPMASDBConnectionStepnewSchema();
            stmt = con.createStatement();
            String query = "SELECT  id FROM `active_pdc_acc_plan_name_lists` WHERE `plan_name`='" + planName + "'";
            rs1 = stmt.executeQuery(query);
            if (rs1.next()) {
                planID = rs1.getInt(1);
            } else {
                logger.info("No plan exist in the ACTIVE_PDC_ACCOUNT_PLAN_TYPES table ");
                preparedStatement = con.prepareStatement("INSERT INTO active_pdc_acc_plan_name_lists (plan_name) values(?)");
                preparedStatement.setString(1, planName);
                int affectedRows = preparedStatement.executeUpdate();
                logger.info("###### PMAS DB ACTIVE_PDC_ACCOUNT_PLAN_TYPES TABLE updated successfully:" + affectedRows);
                planID = checkPlanID(planName);
            }
        } catch (SQLException e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "checkPlanID", e);
        } finally {
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    logger.error(e);
                }
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    logger.error(e);
                }
            }
            if (rs1 != null) {
                try {
                    rs1.close();
                } catch (SQLException e) {
                    logger.error(e);
                }
            }
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException e) {
                    logger.error(e);
                }
            }
        }
        return planID;
    }
}
