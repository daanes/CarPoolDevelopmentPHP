package com.ytlctest.corebase.e2evalidation.pageobjects;

import com.ytlctest.corebase.lib.AppWait;
import com.ytlctest.corebase.lib.MainUtil;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PushBulletPageObjects extends MainUtil {

    private RemoteWebDriver driver;
    @FindBy(xpath = "//button[@class='btn google-button']//img[@class='store']")
    private WebElement loginWithGoogle;
    @FindBy(xpath = "//div[contains(text(),'Use another account')]")
    private WebElement loginWIthAnotherAccount;
    @FindBy(xpath = "//body/div[@id='onecup']/div[@id='sink']/div/div/div/div[5]")
    private WebElement smsTexting;
    @FindBy(xpath = "//*[@id='identifierId']")
    private WebElement identifierId;
    //    @FindBy(xpath = "/html[1]/body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/span[1]/span[1]")
    @FindBy(xpath = "//span[contains(text(),'Next')]")
    private WebElement identifierNext;
    @FindBy(name = "password")
    private WebElement password;
    //  @FindBy(xpath = "//*[@id='identifierNext']/content/span")
    //   private WebElement identifierNext;
    @FindBy(xpath = "//span[contains(text(),'Next')]")
    private WebElement passwordNext;
    @FindBy(xpath = " //div[@id='innerlist']/div[last()]/div/div/div[2]/div")
    private WebElement otpMessage;
    @FindBy(xpath = "//div[@id='account-btn']")
    private WebElement profileLogo;
    @FindBy(xpath = "//a[contains(text(),'Sign Out')]")
    private WebElement signout;

    public PushBulletPageObjects(RemoteWebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public WebElement getLoginWithGoogle() {
        return AppWait.waitForElementToBeClickable(driver, loginWithGoogle);
    }

    public WebElement getProfileLogo() {
        return AppWait.waitForElementToBeClickable(driver, profileLogo);
    }

    public WebElement getSignOut() {
        return AppWait.waitForElementToBeClickable(driver, signout);
    }

    public WebElement getLoginWIthAnotherAccount() {
        return AppWait.waitForElementToBeClickable(driver, loginWIthAnotherAccount);
    }

    public boolean getLoginWIthAnotherAccount_visible() {
        return AppWait.visibilityOfElementPresent(driver, loginWIthAnotherAccount, 5);
    }

    public WebElement getSmsTexting() {
        return AppWait.waitForElementToBeClickable(driver, smsTexting);
    }

    public WebElement getIdentifierId() {
        return AppWait.waitForElementToBeClickable(driver, identifierId);
    }

    public WebElement getIdentifierNext() {
        return AppWait.waitForElementToBeClickable(driver, identifierNext);
    }

    public WebElement getPassword() {
        return AppWait.waitForElementToBeClickable(driver, password);
    }

    public WebElement getPasswordNext() {
        return AppWait.waitForElementToBeClickable(driver, passwordNext);
    }

    public WebElement getOtpMessage() {
        return otpMessage;
    }

}