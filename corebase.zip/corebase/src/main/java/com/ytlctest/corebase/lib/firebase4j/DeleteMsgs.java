package com.ytlctest.corebase.lib.firebase4j;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;

public class DeleteMsgs {

    private static Logger logger = LogManager.getLogger(DeleteMsgs.class);

    /**
     * Method to delete OTP's in firebaseio url of otpsniffer app
     */
    public static void delMsgs() {
        try {
            Runtime.getRuntime().exec("curl -X DELETE https://otpsniffer.firebaseio.com/messages/.json");
            logger.info("Deleted OTP messages");
        } catch (IOException e) {
            logger.error("Error deleting OTP messages", e);
        }
    }

    public static void main(String[] args) {
        delMsgs();
    }
}
