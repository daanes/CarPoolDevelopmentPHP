package com.ytlctest.corebase.e2evalidation.pagefunctions;

import com.ytlctest.corebase.e2evalidation.pageobjects.YosGmailNotificationPage;
import com.ytlctest.corebase.lib.ExtentScreenCapture;
import com.ytlctest.corebase.lib.MainUtil;
import com.ytlctest.corebase.lib.PropertyHelper;
import com.ytlctest.corebase.listener.ExtentTestNGITestListener;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;

import static com.ytlctest.corebase.listener.ExtentTestNGITestListener.getTest;

public class YosGmailNotificationFuncs extends YosGmailNotificationPage {
    private static Logger logger = LogManager.getLogger(YosGmailNotificationFuncs.class);
    ExtentTestNGITestListener ex = new ExtentTestNGITestListener();
    private RemoteWebDriver driver;

    public YosGmailNotificationFuncs(RemoteWebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    /**
     * Perform gmail login
     *
     * @param driver Pass the remotedriver instance here
     * @throws Exception
     */
    public void doGmailLogin(RemoteWebDriver driver) throws Exception {
        logger.info("Login to gmail");
        try {
            logger.info("Logging into zoho mail");
            //MainUtil.launchURL("https://accounts.google.com/signin/v2/identifier?flowName=GlifWebSignIn&flowEntry=ServiceLogin", driver);
            //Changes for Email
            MainUtil.launchURL("https://accounts.google.com/signin/v2/sl/pwd?service=mail&passive=true&rm=false&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&ss=1&scc=1&ltmpl=default&ltmplcache=2&emr=1&osid=1&flowName=GlifWebSignIn&flowEntry=ServiceLogin", driver);
            inputTextByXpath(getIdentifierId(), PropertyHelper.getTestDataValue("OBRM_EMAIL", "pdc"), "identifierId", "", driver);
            //clickByXpath(getIdentifierNext(), "identifierNext", driver);
            getIdentifierId().sendKeys(Keys.ENTER);
            inputTextByXpath(getPassword(), PropertyHelper.getTestDataValue("OBRM_PASSWORD", "pdc"), "password", "", driver);
            //clickByXpath(getPasswordNext(), "identifierNext", driver);
            getPassword().sendKeys(Keys.ENTER);
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD + " " + "doZohoLogin", e);
            throw e;
        }
    }

    /**
     * This is to search email in gmail
     *
     * @param orderid Pass the order ID
     */
    public void searchEmail(String orderid) {
        try {
            logger.info("gmail search email");
            //	clickByXpath(getWelcomeHeader(), "welcomeHeader", driver);
            inputTextByXpath(getOrderid(), orderid, "orderid", "", driver);
            clickByXpath(getGmailSearch(), "gmailSearch", driver);
            clickByXpath(getInbox(), "inbox", driver);
            getTest().get().pass("Gmail1 Found", ExtentScreenCapture.captureSrceenPass("gmailNotification1", driver));
			/*clickByXpath(getGmailSearch(), "gmailSearch", driver);
			clickByXpath(getInbox(), "inbox", driver);
			getTest().get().pass("Gmail2 Found", ExtentScreenCapture.captureSrceenPass("gmailNotification2", driver));*/
            logout();
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD + " " + "searchEmail", e);
            throw e;
        }
    }

    /**
     * Do gmail logout
     */
    private void logout() {
        try {
            logger.info("Logout Gmail");
            clickByXpath(getMailService(), "mailService", driver);
            clickByXpath(getSignOut(), "signOut", driver);
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD + " " + "logout", e);
        }
    }
}
