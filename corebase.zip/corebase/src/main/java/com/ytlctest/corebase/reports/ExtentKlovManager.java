/*package com.ytlctest.corebase.reports;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentKlovReporter;
import com.ytlctest.corebase.lib.PropertyHelper;

public class ExtentKlovManager {
	private static ExtentReports extent;

	*//**
 * Returns instance of Extent Klov reports
 *
 * @return ExtentReports object
 *//*
	public static ExtentReports createInstance() {
		ExtentKlovReporter klovReporter = new ExtentKlovReporter();

		klovReporter.initMongoDbConnection("10.28.19.108", 27017);
		klovReporter.setProjectName("YTLC Projects");
		klovReporter.setReportName(PropertyHelper.getProperties("REPORTNAME"));
		klovReporter.initKlovServerConnection("http://10.28.19.108:8081");

		extent = new ExtentReports();
		extent.attachReporter(klovReporter);

		return extent;
	}

}*/
