package com.ytlctest.corebase.lib.openstf;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import okhttp3.*;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

/**
 * This class provides the capability to connect or disconnect device.
 */
public class DeviceApi {
    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    private static final Logger LOGGER = Logger.getLogger(Class.class.getName());
    private OkHttpClient client;
    private JsonParser jsonParser;
    private STFService stfService;

    public DeviceApi(STFService stfService) {
        this.client = new OkHttpClient();
        this.jsonParser = new JsonParser();
        this.stfService = stfService;
    }

    public static void main(String[] args) throws MalformedURLException, URISyntaxException {
        String STF_SERVICE_URL = "http://14.1.213.101:7100";
        String ACCESS_TOKEN = "232007b293234cf087a2a60927310ea50a2564ffcfd545b69db91499acbb91f0";
        STFService stfService = new STFService(STF_SERVICE_URL, ACCESS_TOKEN);
        DeviceApi deviceApi = new DeviceApi(stfService);
        deviceApi.addDeviceToUser("ce05160568592b2401");
        deviceApi.remoteConnect("ce05160568592b2401");
        deviceApi.releaseDevice("ce05160568592b2401");
    }

    public boolean connectDevice(String deviceSerial) {
        Request request = new Request.Builder()
                .addHeader("Authorization", "Bearer " + stfService.getAuthToken())
                .url(stfService.getStfUrl() + "devices/" + deviceSerial)
                .build();
        Response response;
        try {
            response = client.newCall(request).execute();
            JsonObject jsonObject = jsonParser.parse(response.body().string()).getAsJsonObject();
            if (!isDeviceFound(jsonObject)) {
                return false;
            }
            JsonObject deviceObject = jsonObject.getAsJsonObject("device");
            boolean present = deviceObject.get("present").getAsBoolean();
            boolean ready = deviceObject.get("ready").getAsBoolean();
            boolean using = deviceObject.get("using").getAsBoolean();
            JsonElement ownerElement = deviceObject.get("owner");
            boolean owner = !(ownerElement instanceof JsonNull);
            if (!present || !ready || using || owner) {
                LOGGER.severe("Device is in use");
                return false;
            } else {
                addDeviceToUser(deviceSerial);
                remoteConnect(deviceSerial);
            }
            return addDeviceToUser(deviceSerial);
        } catch (IOException e) {
            throw new IllegalArgumentException("STF service is unreachable", e);
        }
    }

    private boolean isDeviceFound(JsonObject jsonObject) {
        if (!jsonObject.get("success").getAsBoolean()) {
            LOGGER.severe("Device not found");
            return false;
        }
        return true;
    }

    private boolean addDeviceToUser(String deviceSerial) {
        RequestBody requestBody = RequestBody.create(JSON, "{\"serial\": \"" + deviceSerial + "\"}");
        Request request = new Request.Builder()
                .addHeader("Authorization", "Bearer " + stfService.getAuthToken())
                .url(stfService.getStfUrl() + "user/devices")
                .post(requestBody)
                .build();
        Response response;
        try {
            response = client.newCall(request).execute();
            JsonObject jsonObject = jsonParser.parse(response.body().string()).getAsJsonObject();
            if (!isDeviceFound(jsonObject)) {
                return false;
            }
            LOGGER.info("The device <" + deviceSerial + "> is locked successfully");
            return true;
        } catch (IOException e) {
            throw new IllegalArgumentException("STF service is unreachable", e);
        }
    }

    private void remoteConnect(String deviceSerial) {
        RequestBody requestBody = RequestBody.create(JSON, "{\"serial\": \"" + deviceSerial + "\"}");
        Request request = new Request.Builder()
                .addHeader("Authorization", "Bearer " + stfService.getAuthToken())
                .url(stfService.getStfUrl() + "user/devices/" + deviceSerial + "/remoteConnect")
                .post(requestBody)
                .build();
        Response response;
        try {
            response = client.newCall(request).execute();
            JsonObject jsonObject = jsonParser.parse(response.body().string()).getAsJsonObject();
            String remoteConnectUrl = String.valueOf(jsonObject.get("remoteConnectUrl"));
            ProcessBuilder pb = new ProcessBuilder("adb", "connect", remoteConnectUrl);
            Process pc = pb.start();
            pc.waitFor(10, TimeUnit.SECONDS);
            System.out.println("Done");
            LOGGER.info("The device <" + deviceSerial + "> is connected successfully");
        } catch (IOException e) {
            throw new IllegalArgumentException("STF service is unreachable", e);
        } catch (InterruptedException e) {
            LOGGER.info("Interrupted!" + e);
            Thread.currentThread().interrupt();
        }
    }

    public boolean releaseDevice(String deviceSerial) {
        Request request = new Request.Builder()
                .addHeader("Authorization", "Bearer " + stfService.getAuthToken())
                .url(stfService.getStfUrl() + "user/devices/" + deviceSerial)
                .delete()
                .build();
        Response response;
        try {
            response = client.newCall(request).execute();
            JsonObject jsonObject = jsonParser.parse(response.body().string()).getAsJsonObject();
            if (!isDeviceFound(jsonObject)) {
                return false;
            }
            LOGGER.info("The device <" + deviceSerial + "> is released successfully");
            return true;
        } catch (IOException e) {
            throw new IllegalArgumentException("STF service is unreachable", e);
        }
    }
}
