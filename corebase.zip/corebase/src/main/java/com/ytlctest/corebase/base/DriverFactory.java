package com.ytlctest.corebase.base;

import com.ytlctest.corebase.lib.PropertyHelper;
import com.ytlctest.corebase.lib.SQLConnectionHelper;
import com.ytlctest.corebase.listener.ExtentTestNGITestListener;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import net.lightbody.bmp.BrowserMobProxy;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import java.io.File;
import java.util.*;


public class DriverFactory {

    protected static Map<String, RemoteWebDriver> driverPool;
    private static List<WebDriverThread> webDriverThreadPool = Collections.synchronizedList(new ArrayList<WebDriverThread>());
    private static ThreadLocal<WebDriverThread> driverThread;
    private static Logger logger = LogManager.getLogger(DriverFactory.class);

    @BeforeSuite
    public static void instantiateDriverObject() {
        logger.info("Instantiating Driver Object");
        File dir = new File("extentreport");
        dir.mkdir();
        driverThread = ThreadLocal.withInitial(() -> {
            WebDriverThread webDriverThread = new WebDriverThread();
            webDriverThreadPool.add(webDriverThread);
            return webDriverThread;
        });
    }

    /**
     * Returns the remote web driver
     *
     * @param browserName  Provide the browser for storing in the driver pool (Ex: chrome1, chrome2)
     * @param designatedVM Pass the VM name on which this execution should happen
     * @return returns the remotewebdriver
     */


    public static RemoteWebDriver getDriver(String browserName, String designatedVM) {
        logger.info("Getting WebDriver");
        driverThread.get().getDriver(browserName, designatedVM);
        return getDriverPool().get(browserName);
    }

    /**
     * Returns the mobile driver from the driver pool
     *
     * @param appName     Provide the app name
     * @param appPackage  Provide the appPackage name
     * @param appActivity Provide appActivity
     * @return returns the driver from the driver pool
     */
    public static RemoteWebDriver getDriver(String appName, String appPackage, String appActivity, String deviceName) {
        driverThread.get().getDriver(appName, appPackage, appActivity, deviceName);
        return getDriverPool().get(appName);
    }

    public static RemoteWebDriver getDriver(String appName, String appPackage, String appActivity, String deviceName, String fileName) {
        driverThread.get().getDriver(appName, appPackage, appActivity, deviceName, fileName);
        return getDriverPool().get(appName);
    }


    public static RemoteWebDriver getDriver(String appName, String uuid, String bundleId, String xcodeOrgId, int timeout) {
        driverThread.get().getDriver(appName, uuid, bundleId, xcodeOrgId, timeout);
        return getDriverPool().get(appName);
    }


    public static RemoteWebDriver getDriver(String appName, String browsername, String platformversion) {
        driverThread.get().getDriver(appName, browsername, platformversion);
        return getDriverPool().get(appName);
    }

    /*public static RemoteWebDriver getMultiBrowserDriver(String browsername) {
        driverThread.get().getMultiBrowserDriver(browsername);
        return getDriverPool().get(browsername);
    }*/

    /**
     * Get driver from driver pool stored in Map
     *
     * @return driver pool
     */
    public static Map<String, RemoteWebDriver> getDriverPool() {
        if (driverPool == null) {
            driverPool = new HashMap<>();
        }
        return driverPool;
    }

    @AfterMethod
    public static void clearCookies() {
        try {
            if (!getDriverPool().entrySet().isEmpty()) {
                for (Map.Entry<String, RemoteWebDriver> driver : getDriverPool().entrySet()) {
                    if (!((driver.getValue() instanceof AndroidDriver) || ((driver.getValue() instanceof IOSDriver))))
                        driver.getValue().manage().deleteAllCookies();
                }
            }
        } catch (WebDriverException wde) {
            logger.error("No need of clearing the cookies");
        }

    }

    public static BrowserMobProxy getProxy() {
        return driverThread.get().getProxy();
    }

    @AfterSuite
    public static void closeDriverObjects() {
        logger.info("Close the Driver ***************");
        try {
            if (System.getProperty("reporttype").equalsIgnoreCase("localr")) {
                if (ExtentTestNGITestListener.USER_DIR.toUpperCase().contains("YCMS")) {
                    PropertyHelper.UpdateCompletionStatus("C", ExtentTestNGITestListener.table_id);
                } else if (ExtentTestNGITestListener.USER_DIR.toUpperCase().contains("YOS")) {
                    PropertyHelper.UpdateCompletionStatus("C", ExtentTestNGITestListener.table_id);
                } else if (ExtentTestNGITestListener.USER_DIR.toUpperCase().contains("MYYES4G")) {
                    PropertyHelper.UpdateCompletionStatus("C", ExtentTestNGITestListener.table_id);
                } else if (ExtentTestNGITestListener.USER_DIR.toUpperCase().contains("YESMY")) {
                    PropertyHelper.UpdateCompletionStatus("C", ExtentTestNGITestListener.table_id);
                } else if (ExtentTestNGITestListener.USER_DIR.toUpperCase().contains("YMCA")) {
                    PropertyHelper.UpdateCompletionStatus("C", ExtentTestNGITestListener.table_id);
                } else if (ExtentTestNGITestListener.USER_DIR.toUpperCase().contains("OPERATIONS")) {
                    PropertyHelper.UpdateCompletionStatus("C", ExtentTestNGITestListener.table_id);
                } else if (ExtentTestNGITestListener.USER_DIR.toUpperCase().contains("SCM")) {
                    PropertyHelper.UpdateCompletionStatus("C", ExtentTestNGITestListener.table_id);
                } else if (ExtentTestNGITestListener.USER_DIR.toUpperCase().contains("YCMS_ADMIN")) {
                    PropertyHelper.UpdateCompletionStatus("C", ExtentTestNGITestListener.table_id);
                } else if (ExtentTestNGITestListener.USER_DIR.toUpperCase().contains("YOS_ADMIN")) {
                    PropertyHelper.UpdateCompletionStatus("C", ExtentTestNGITestListener.table_id);
                } else if (ExtentTestNGITestListener.USER_DIR.toUpperCase().contains("OTRS")) {
                    PropertyHelper.UpdateCompletionStatus("C", ExtentTestNGITestListener.table_id);
                } else if (ExtentTestNGITestListener.USER_DIR.toUpperCase().contains("SUGARCRM")) {
                    PropertyHelper.UpdateCompletionStatus("C", ExtentTestNGITestListener.table_id);
                } else if (ExtentTestNGITestListener.USER_DIR.toUpperCase().contains("EPAY")) {
                    PropertyHelper.UpdateCompletionStatus("C", ExtentTestNGITestListener.table_id);
                } else if (ExtentTestNGITestListener.USER_DIR.toUpperCase().contains("CAL_PARTNER_SERVICE")) {
                    PropertyHelper.UpdateCompletionStatus("C", ExtentTestNGITestListener.table_id);
                } else if (ExtentTestNGITestListener.USER_DIR.toUpperCase().contains("YES_COVERAGE_MAPS")) {
                    PropertyHelper.UpdateCompletionStatus("C", ExtentTestNGITestListener.table_id);
                } else if (ExtentTestNGITestListener.USER_DIR.toUpperCase().contains("USSP_MOBILE_AUTOMATION")) {
                    PropertyHelper.UpdateCompletionStatus("C", ExtentTestNGITestListener.table_id);
                } else if (ExtentTestNGITestListener.USER_DIR.toUpperCase().contains("MNP")) {
                    PropertyHelper.UpdateCompletionStatus("C", ExtentTestNGITestListener.table_id);
                } else if (ExtentTestNGITestListener.USER_DIR.toUpperCase().contains("USSP_PRODUCTION")) {
                    PropertyHelper.UpdateCompletionStatus("C", ExtentTestNGITestListener.table_id);
                } else if (ExtentTestNGITestListener.USER_DIR.toUpperCase().contains("YOS_FREE_EDUCATION")) {
                    PropertyHelper.UpdateCompletionStatus("C", ExtentTestNGITestListener.table_id);
                } else if (ExtentTestNGITestListener.USER_DIR.toUpperCase().contains("ECMR")) {
                    PropertyHelper.UpdateCompletionStatus("C", ExtentTestNGITestListener.table_id);
                } else if (ExtentTestNGITestListener.USER_DIR.toUpperCase().contains("YOS_RNR")) {
                    PropertyHelper.UpdateCompletionStatus("C", ExtentTestNGITestListener.table_id);
                }
            }
            logger.info("Updating the RemoteWebdriver ***************");
            if (webDriverThreadPool != null) {
                for (WebDriverThread webDriverThread : webDriverThreadPool) {
                    webDriverThread.quitDriver();
                }
            } else {
                logger.info("Driver already closed");
            }

            /* Closes the PMAS DB Connection */
            logger.info("Closing DB Connection Pool");
            SQLConnectionHelper.closeDBConnPool();

            /* driverThread close */
            driverThread.remove();
        } catch (Exception e) {
            logger.error("Error in terminating the driver objects \n", e);
        }

    }
}