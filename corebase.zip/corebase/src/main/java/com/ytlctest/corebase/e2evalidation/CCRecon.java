package com.ytlctest.corebase.e2evalidation;

import com.ytlctest.corebase.lib.MainUtil;
import com.ytlctest.corebase.lib.MainUtil.ProjectConst;
import com.ytlctest.corebase.lib.PropertyHelper;
import com.ytlctest.corebase.lib.SQLConnectionHelper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

import static com.ytlctest.corebase.listener.ExtentTestNGITestListener.getTest;

public class CCRecon {
    private static Logger logger = LogManager.getLogger(CCRecon.class);

    /**
     * Format date
     *
     * @return
     */
    private static String[] dateFormat() {
        logger.info("DateFormat Method");
        String[] formats = {"yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm aa", "dd MMM yyyy HH:mm:ss a", "dd MMM yyyy hh:mm:ss"};
        logger.info(Arrays.toString(formats));
        return formats;
    }

    /**
     * Parse date
     *
     * @param d
     * @param formats
     * @return
     */
    private static Date parse(String d, String[] formats) {
        logger.info("Inside Dateparse Method");
        Date date = null;
        try {
            if (d != null) {
                for (String parse : formats) {
                    SimpleDateFormat sdf = new SimpleDateFormat(parse);
                    try {
                        date = sdf.parse(d);
                        logger.info(new StringBuilder("Printing the value of parse").append(ProjectConst.VALUE.getMsg()).append(parse));
                        logger.info(new StringBuilder("Printing the value of date").append(ProjectConst.VALUE.getMsg()).append(date));
                    } catch (ParseException e) {
                        logger.info(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "Dateparse", e);
                    }
                }
            }
        } catch (Exception e) {
            logger.error("error occured in pasring the date...\n {0}", e);
        }
        return date;
    }

    /**
     * This class helps in inserting the payment details in STEP
     *
     * @param tsid Pass the transaction ID
     * @throws SQLException Throws SQL Exception
     */
    public void insertIntoCCrecon(String tsid, RemoteWebDriver driver) throws SQLException {
        logger.info("Insert into CCrecon");
        Connection con = null;
        String shortTimeStr = null;
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();
        String yesid = null;
        String transTime;
        String imagepath;
        String imageName;
        int siNo = 0;
        String[] image;
        try {
            if (!(MainUtil.storeVariable.get("ORDER_ID").equalsIgnoreCase("") || MainUtil.storeVariable.get("ORDER_ID").equalsIgnoreCase(null) || MainUtil.storeVariable.get("ORDER_ID").equalsIgnoreCase("NA"))) {
                imagepath = MainUtil.storeVariable.get("IMAGE_TO_STORE");
                if (imagepath.contains("/")) {
                    image = imagepath.replace('/', ',').split(",");
                } else {
                    image = imagepath.replace('\\', ',').split(",");
                }
                imageName = image[image.length - 1];
                logger.info(new StringBuilder("ImageName").append(ProjectConst.VALUE.getMsg()).append(imageName));
                transTime = MainUtil.storeVariable.get("TRANSACTION_TIME");
                String[] formats = dateFormat();
                Date date1 = parse(transTime, formats);
                SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
                shortTimeStr = sdf.format(date1);
                logger.info(dateFormat.format(date));
                yesid = MainUtil.storeVariable.get("WOM_YES_ID");
                logger.info(new StringBuilder("CONNECTION IS").append(ProjectConst.VALUE.getMsg()).append(con));
//                SQLConnectionHelper.stepNewDBcloseConnection();
                con = SQLConnectionHelper.getPMASDBConnectionStepnewSchema();
                logger.info(new StringBuilder("CONNECTION IS").append(ProjectConst.VALUE.getMsg()).append(con));
                String query = "INSERT INTO active_pdc_accounts (`pdc_date`,`project_name`,`order_id`,`yes_id`,`amount`,`approval_code`,`transaction_date`,`card_number`,`card_holder`,`remarks`,`transaction_time`,`plan_type_id`,`bank_name`,`artifacts_file`,`id`,`created_at`,`updated_at`,`account_type`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,UUID(),?,?,?)";
                try (PreparedStatement preparedStatement = con.prepareStatement(query)) {
                    logger.info(new StringBuilder("CONNECTION").append(ProjectConst.VALUE.getMsg()).append(con));
                    preparedStatement.setString(1, dateFormat.format(date));
                    preparedStatement.setString(2, MainUtil.APPLICATION_NAME);
                    preparedStatement.setString(3, MainUtil.storeVariable.get("ORDER_ID"));
                    preparedStatement.setString(4, yesid);
                    preparedStatement.setString(5, MainUtil.storeVariable.get("AMOUNT_PAID").contains("RM") ? MainUtil.storeVariable.get("AMOUNT_PAID").replace("RM", "") : MainUtil.storeVariable.get("AMOUNT_PAID"));
                    preparedStatement.setString(6, MainUtil.storeVariable.get("APPROVAL_CODE"));
                    preparedStatement.setString(7, dateFormat.format(date));
                    preparedStatement.setString(8, PropertyHelper.getENVProperties("CARD_NUMBER"));
                    preparedStatement.setString(9, PropertyHelper.getENVProperties("CARD_HOLDER"));
                    preparedStatement.setString(10, tsid);
                    preparedStatement.setString(11, shortTimeStr + ":00");
                    preparedStatement.setInt(12, 2);
                    preparedStatement.setString(13, PropertyHelper.getENVProperties("BANK_DETAILS"));
                    preparedStatement.setString(14, "public/active_pdc_accounts/" + imageName);
                    preparedStatement.setString(15, dateFormat.format(date));
                    preparedStatement.setString(16, dateFormat.format(date));
                    if (tsid.equalsIgnoreCase("ADDON")) {
                        preparedStatement.setInt(17, 5);
                    } else if (tsid.equalsIgnoreCase("BILL PAYMENT")) {
                        preparedStatement.setInt(17, 4);
                    } else if (tsid.equalsIgnoreCase("RELOAD")) {
                        preparedStatement.setInt(17, 3);
                    }
                    logger.info(new StringBuilder("Statement: ").append(preparedStatement));
                    int affectedRows = preparedStatement.executeUpdate();
                    logger.info(new StringBuilder("###### PMAS DB CC_RECONCILATION TABLE updated successfully:").append(affectedRows));
                    getTest().get().pass("insertIntoCCRECON : APPLICATION_NAME:" + MainUtil.APPLICATION_NAME + " ORDER_ID:"
                            + MainUtil.storeVariable.get("ORDER_ID") + "YESID:" + yesid + "AMOUNT_PAID:"
                            + MainUtil.storeVariable.get("AMOUNT_PAID") + "APPROVAL_CODE:"
                            + MainUtil.storeVariable.get("APPROVAL_CODE") + "TRANSACTION_DATE:" + dateFormat.format(date)
                            + "CARD_NUMBER:" + PropertyHelper.getENVProperties("CARD_NUMBER") + "CARD_HOLDER:"
                            + PropertyHelper.getENVProperties("CARD_HOLDER") + "TRANSACTION DETAILS:" + tsid
                            + "TRANSACTION_TIME :" + shortTimeStr + "BETA_GAMMA :Gamma" + "BANK_DETAILS :"
                            + PropertyHelper.getENVProperties("BANK_DETAILS"));
                    UploadFile.uploadfile(imagepath, driver);
                }

            }
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "insertIntoCCrecon", e);
            getTest().get().fail("insertIntoCCRECON : Not Inserted into DB cc recon db" + e.getMessage());
        }
    }
}
