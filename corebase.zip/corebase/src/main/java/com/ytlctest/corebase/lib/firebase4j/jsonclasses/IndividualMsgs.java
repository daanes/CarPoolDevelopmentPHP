package com.ytlctest.corebase.lib.firebase4j.jsonclasses;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class IndividualMsgs {

    @SerializedName("amount")
    @Expose
    private String amount;
    @SerializedName("bank")
    @Expose
    private String bank;
    @SerializedName("date")
    @Expose
    private String date;
    @SerializedName("originalMessage")
    @Expose
    private String originalMessage;
    @SerializedName("otp")
    @Expose
    private String otp;
    @SerializedName("time")
    @Expose
    private String time;

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getBank() {
        return bank;
    }

    public void setBank(String bank) {
        this.bank = bank;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getOriginalMessage() {
        return originalMessage;
    }

    public void setOriginalMessage(String originalMessage) {
        this.originalMessage = originalMessage;
    }

    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

}
