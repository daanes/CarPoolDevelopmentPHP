package com.ytlctest.corebase.lib;

import com.ytlctest.calwebservice.CreateCustomerWsdl;
import com.ytlctest.corebase.listener.ExtentTestNGITestListener;
import com.ytlctest.querywebservices.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

import static com.ytlctest.corebase.listener.ExtentTestNGITestListener.getTest;

public class ApplicationUtil extends MainUtil {

    private static Logger logger = LogManager.getLogger(ApplicationUtil.class);

    /**
     * Method to fetch deviceType based on number input
     *
     * @param SimOrMsisdn Pass the Sim Serial No/MSISDN no for which need to fetch the
     *                    device type
     * @return returns device type
     * @throws JSONException Will throw JSONException
     */
    public static synchronized String FetchDeviceType(String SimOrMsisdn) throws JSONException {
        logger.info("In FetchDeviceType");
        String scmDeviceType = null;
        try {
            FetchDeviceType deviceType = new FetchDeviceType();
            JSONObject result = deviceType.getDeviceType(SimOrMsisdn);
            if (result != null && !result.get("Result").equals(null)) {
                JSONArray elements = result.getJSONArray("Result");
                JSONObject object = elements.getJSONObject(0);
                logger.info(result);
                logger.info("SCM_DEVICE_TYPE---> {}", object.get("BRAND_NAME").toString());
                scmDeviceType = object.get("BRAND_NAME").toString();
                storeVariable.put("SCM_DEVICE_TYPE", object.get("BRAND_NAME").toString());
                getTest().get().pass("SCM_DEVICE_TYPE:" + storeVariable.get("SCM_DEVICE_TYPE"));
            } else {
                logger.error("{} FetchDeviceType: {}", MainUtil.ProjectConst.EXCEPTIONTEXTMETHOD, result);
                getTest().get().fail("SCM_DEVICE_TYPE not found in db" + result);
            }
        } catch (Exception e) {
            logger.error(MainUtil.ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "FetchDeviceType", e);
            getTest().get().info("SCM_DEVICE_TYPE not found in db");
            throw e;
        }
        return scmDeviceType;
    }

    /**
     * Method to store session details into a table
     *
     * @param accountType Pass the accounttype(Postpaid/Prepaid)
     * @param scenarioId  Pass the scenario ID
     * @param appName     Pass the application name
     * @throws Exception
     */
    public static synchronized void insertStoreVariableIntoList(String accountType, String scenarioId, String appName)
            throws Exception {
        String env = null;
        try {
            logger.info("Insert store variable into list");
            try (Connection conn = SQLConnectionHelper.getPMASDBConnectionStepnewSchema()) {
                String sql = "insert into `auto_store_session_details` (`id`,`scenario_id`,`wom_yes_id`,`available_msisdn`,`account_type`,`crestel_idno`,`available_simno`,`plan_cost`,plan_name,current_sc_password,order_id,digit_sim_no_19,env,app_name,plan_type,customer_name,identification_type,created_at) "
                        + "values (UUID(),?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW())";
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setString(1, scenarioId);
                    ps.setString(2, storeVariable.get("WOM_YES_ID") == null ? "NA" : storeVariable.get("WOM_YES_ID"));
                    ps.setString(3, storeVariable.get("AVAILABLE_MSISDN") == null ? "NA"
                            : storeVariable.get("AVAILABLE_MSISDN"));
                    ps.setString(4, accountType);
                    ps.setString(5,
                            storeVariable.get("CRESTEL_IDNO") == null ? "NA" : storeVariable.get("CRESTEL_IDNO"));
                    ps.setString(6,
                            storeVariable.get("AVAILABLE_SIMNO") == null ? "NA" : storeVariable.get("AVAILABLE_SIMNO"));
                    ps.setString(7, storeVariable.get("PLAN_COST") == null ? "NA" : storeVariable.get("PLAN_COST"));
                    ps.setString(8, storeVariable.get("PLAN_NAME") == null ? "NA" : storeVariable.get("PLAN_NAME"));
                    ps.setString(9, storeVariable.get(storeVariable.get("WOM_YES_ID")) == null ? "NA"
                            : storeVariable.get(storeVariable.get("WOM_YES_ID")));
                    ps.setString(10, storeVariable.get("ORDER_ID") == null ? "NA" : storeVariable.get("ORDER_ID"));
                    ps.setString(11,
                            storeVariable.get("19DIGIT_SIM_NO") == null ? "NA" : storeVariable.get("19DIGIT_SIM_NO"));
                    if (MainUtil.ENVIRONMENT.equalsIgnoreCase("IOT")) {
                        env = "1";
                    } else if (MainUtil.ENVIRONMENT.equalsIgnoreCase("Preprod")) {
                        env = "2";
                    } else if (MainUtil.ENVIRONMENT.equalsIgnoreCase("PDC")) {
                        env = "3";
                    } else if (MainUtil.ENVIRONMENT.equalsIgnoreCase("TT")) {
                        env = "4";
                    }
                    ps.setString(12, env);
                    ps.setString(13, appName);
                    ps.setString(14, storeVariable.get("PLAN_TYPE") == null ? "NA" : storeVariable.get("PLAN_TYPE"));
                    ps.setString(15,
                            storeVariable.get("CUSTOMER_NAME") == null ? "NA" : storeVariable.get("CUSTOMER_NAME"));
                    ps.setString(16, storeVariable.get("IDENTIFICATION_TYPE") == null ? "NA"
                            : storeVariable.get("IDENTIFICATION_TYPE"));
                    logger.info(sql);
                    boolean rs = ps.execute();
                    if (rs) {
                        logger.info("insrtion Unsuccessful ...");
                    } else {
                        logger.info("insreted successfully ...");
                    }
                    getTest().get().pass("Inserted Store values into STORE_SESSION_DETAILS table");
                }
            }
        } catch (Exception ex) {
            logger.error("ERROR OCCURED WHILE INSERTING INTO THE STORE_SESSION_DETAILS TABLE");
            logger.error(MainUtil.ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "insertStoreVariableIntoList", ex);
            getTest().get().fail("ERROR OCCURED WHILE INSERTING INTO THE STORE_SESSION_DETAILS TABLE");
        }
    }

    /**
     * Method to fetch data from stored session details from table
     * auto_store_session_details based on appname,account type,plan type,env
     *
     * @param dependentAppName Pass the dependent app name
     * @param accountType      Pass which account type need to fetch
     * @throws Exception
     */
    public static synchronized void FetchStoredDataFromList(String dependentAppName, String accountType)
            throws Exception {
        String query = null;
        String plantype = storeVariable.get("PLAN_TYPE");
        String env = null;
        if (MainUtil.ENVIRONMENT.equalsIgnoreCase("IOT")) {
            env = "1";
        } else if (MainUtil.ENVIRONMENT.equalsIgnoreCase("Preprod")) {
            env = "2";
        } else if (MainUtil.ENVIRONMENT.equalsIgnoreCase("PDC")) {
            env = "3";
        } else if (MainUtil.ENVIRONMENT.equalsIgnoreCase("TT")) {
            env = "4";
        }
        try (Connection con1 = SQLConnectionHelper.getPMASDBConnectionStepnewSchema()) {
            try (Statement stmt1 = con1.createStatement()) {
                query = "SELECT wom_yes_id,available_msisdn,account_type,crestel_idno,available_simno,plan_cost,plan_name,current_sc_password,order_id,digit_sim_no_19"
                        + " FROM `auto_store_session_details` WHERE account_type='" + accountType + "' AND app_name='"
                        + dependentAppName + "'" + " AND `env`='" + env + "'" + " AND `plan_type`='" + plantype
                        + "' ORDER BY created_at DESC";
                logger.info(query);
                try (ResultSet rs1 = stmt1.executeQuery(query)) {
                    if (rs1.next()) {
                        storeVariable.put("WOM_YES_ID", rs1.getString("wom_yes_id"));
                        storeVariable.put("AVAILABLE_MSISDN", rs1.getString("available_msisdn"));
                        storeVariable.put("CRESTEL_IDNO", rs1.getString("crestel_idno"));
                        storeVariable.put("ACCOUNT_TYPE", rs1.getString("account_type"));
                        storeVariable.put("AVAILABLE_SIMNO", rs1.getString("available_simno"));
                        storeVariable.put("PLAN_NAME", rs1.getString("plan_name"));
                        storeVariable.put("PLAN_COST", rs1.getString("plan_cost"));
                        storeVariable.put("CURRENT_SC_PASSWORD", rs1.getString("current_sc_password"));
                        storeVariable.put("ORDER_ID", rs1.getString("order_id"));
                        getTest().get().pass("Data stored from DB to storevariable successfully");
                    } else {
                        logger.info("#### There is no record found in DB ");
                        getTest().get().fail("There is no record found");
                    }
                    logger.info(storeVariable.get("WOM_YES_ID"));
                    logger.info(storeVariable.get("AVAILABLE_MSISDN"));
                    logger.info(storeVariable.get("CRESTEL_IDNO"));
                    logger.info(storeVariable.get("ACCOUNT_TYPE"));
                    logger.info(storeVariable.get("AVAILABLE_SIMNO"));
                    logger.info(storeVariable.get("PLAN_NAME"));
                    logger.info(storeVariable.get("PLAN_COST"));
                    logger.info(storeVariable.get("CURRENT_SC_PASSWORD"));
                    logger.info(storeVariable.get("ORDER_ID"));
                }
            }
        } catch (Exception e) {
            logger.error("### Some error occured FetchStoredDataFromList");
            logger.error(MainUtil.ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "FetchStoredDataFromList", e);
            getTest().get().fail("Some error occured FetchStoredDataFromList");
            throw e;
        }
    }

    /**
     * Method to fetch data from stored session details from table
     * auto_store_session_details based on appname,account type,plan
     * type,env,plan name
     *
     * @param dependentAppName Pass the dependent app name
     * @param accountType      Pass the account type postpaid/prepaid
     * @param planName         Pass the plan name
     * @throws Exception
     */
    public static synchronized void FetchStoredDataFromListUsingPlanName(String dependentAppName, String accountType,
                                                                         String planName) throws Exception {
        String query = null;
        String plantype = storeVariable.get("PLAN_TYPE");
        String env = null;
        if (MainUtil.ENVIRONMENT.equalsIgnoreCase("IOT")) {
            env = "1";
        } else if (MainUtil.ENVIRONMENT.equalsIgnoreCase("Preprod")) {
            env = "2";
        } else if (MainUtil.ENVIRONMENT.equalsIgnoreCase("PDC")) {
            env = "3";
        } else if (MainUtil.ENVIRONMENT.equalsIgnoreCase("TT")) {
            env = "4";
        }
        try (Connection con1 = SQLConnectionHelper.getPMASDBConnectionStepnewSchema()) {
            try (Statement stmt1 = con1.createStatement()) {
                query = "SELECT wom_yes_id,available_msisdn,account_type,crestel_idno,available_simno,plan_cost,plan_name,current_sc_password,order_id,digit_sim_no_19"
                        + " FROM `auto_store_session_details` WHERE account_type='" + accountType + "' AND app_name='"
                        + dependentAppName + "'" + " AND `env`='" + env + "'" + " AND `plan_type`='" + plantype
                        + "' AND `plan_name` LIKE '%" + planName + "%' ORDER BY created_at DESC";
                logger.info(query);
                try (ResultSet rs1 = stmt1.executeQuery(query)) {
                    if (rs1.next()) {
                        storeVariable.put("WOM_YES_ID", rs1.getString("wom_yes_id"));
                        storeVariable.put("AVAILABLE_MSISDN", rs1.getString("available_msisdn"));
                        storeVariable.put("CRESTEL_IDNO", rs1.getString("crestel_idno"));
                        storeVariable.put("ACCOUNT_TYPE", rs1.getString("account_type"));
                        storeVariable.put("AVAILABLE_SIMNO", rs1.getString("available_simno"));
                        storeVariable.put("PLAN_NAME", rs1.getString("plan_name"));
                        storeVariable.put("PLAN_COST", rs1.getString("plan_cost"));
                        storeVariable.put("CURRENT_SC_PASSWORD", rs1.getString("current_sc_password"));
                        storeVariable.put("ORDER_ID", rs1.getString("order_id"));
                        getTest().get().pass("Data stored from DB to storevariable successfully");
                    } else {
                        logger.info("#### There is no record found in DB ");
                        getTest().get().fail("There is no record found");
                    }
                    logger.info(storeVariable.get("WOM_YES_ID"));
                    logger.info(storeVariable.get("AVAILABLE_MSISDN"));
                    logger.info(storeVariable.get("CRESTEL_IDNO"));
                    logger.info(storeVariable.get("ACCOUNT_TYPE"));
                    logger.info(storeVariable.get("AVAILABLE_SIMNO"));
                    logger.info(storeVariable.get("PLAN_NAME"));
                    logger.info(storeVariable.get("PLAN_COST"));
                    logger.info(storeVariable.get("CURRENT_SC_PASSWORD"));
                    logger.info(storeVariable.get("ORDER_ID"));
                }
            }

        } catch (Exception e) {
            logger.error("### Some error occured FetchStoredDataFromList");
            logger.error(MainUtil.ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "FetchStoredDataFromList", e);
            getTest().get().fail("Some error occured FetchStoredDataFromList");
            throw e;
        }
    }

    /**
     * Method to fetch data from stored session details from table
     * auto_store_session_details based on appname,account type,plan
     * type,env,plan name,ID type
     *
     * @param dependentAppName Pass the dependent app name
     * @param accountType      Pass which account type need to fetch
     * @param idType           Pass which identification type need to fetch
     * @throws Exception
     */
    public static synchronized void FetchStoredDataFromListUsingIDType(String dependentAppName, String accountType,
                                                                       String planName, String IDType) throws Exception {
        String query = null;
        String plantype = storeVariable.get("PLAN_TYPE");
        String env = null;
        if (MainUtil.ENVIRONMENT.equalsIgnoreCase("IOT")) {
            env = "1";
        } else if (MainUtil.ENVIRONMENT.equalsIgnoreCase("Preprod")) {
            env = "2";
        } else if (MainUtil.ENVIRONMENT.equalsIgnoreCase("PDC")) {
            env = "3";
        } else if (MainUtil.ENVIRONMENT.equalsIgnoreCase("TT")) {
            env = "4";
        }
        try (Connection con1 = SQLConnectionHelper.getPMASDBConnectionStepnewSchema()) {
            try (Statement stmt1 = con1.createStatement()) {
                if (planName.isEmpty() || planName.equals("")) {
                    query = "SELECT wom_yes_id,available_msisdn,account_type,crestel_idno,available_simno,plan_cost,plan_name,current_sc_password,order_id,digit_sim_no_19"
                            + " FROM `auto_store_session_details` WHERE account_type='" + accountType
                            + "' AND app_name='" + dependentAppName + "'" + " AND `env`='" + env + "'"
                            + " AND `plan_type`='" + plantype + "' AND `identification_type` = '" + IDType
                            + "' ORDER BY created_at DESC";

                } else {
                    query = "SELECT wom_yes_id,available_msisdn,account_type,crestel_idno,available_simno,plan_cost,plan_name,current_sc_password,order_id,digit_sim_no_19"
                            + " FROM `auto_store_session_details` WHERE account_type='" + accountType
                            + "' AND app_name='" + dependentAppName + "'" + " AND `env`='" + env + "'"
                            + " AND `plan_type`='" + plantype + "' AND `plan_name` LIKE '%" + planName
                            + "%' AND `identification_type` = '" + IDType + "' ORDER BY created_at DESC";
                }
                logger.info(query);
                try (ResultSet rs1 = stmt1.executeQuery(query)) {
                    if (rs1.next()) {
                        storeVariable.put("WOM_YES_ID", rs1.getString("wom_yes_id"));
                        storeVariable.put("AVAILABLE_MSISDN", rs1.getString("available_msisdn"));
                        storeVariable.put("CRESTEL_IDNO", rs1.getString("crestel_idno"));
                        storeVariable.put("ACCOUNT_TYPE", rs1.getString("account_type"));
                        storeVariable.put("AVAILABLE_SIMNO", rs1.getString("available_simno"));
                        storeVariable.put("PLAN_NAME", rs1.getString("plan_name"));
                        storeVariable.put("PLAN_COST", rs1.getString("plan_cost"));
                        storeVariable.put("CURRENT_SC_PASSWORD", rs1.getString("current_sc_password"));
                        storeVariable.put("ORDER_ID", rs1.getString("order_id"));
                        getTest().get().pass("Data stored from DB to storevariable successfully");
                    } else {
                        logger.info("#### There is no record found in DB ");
                        getTest().get().fail("There is no record found");
                    }
                    logger.info(storeVariable.get("WOM_YES_ID"));
                    logger.info(storeVariable.get("AVAILABLE_MSISDN"));
                    logger.info(storeVariable.get("CRESTEL_IDNO"));
                    logger.info(storeVariable.get("ACCOUNT_TYPE"));
                    logger.info(storeVariable.get("AVAILABLE_SIMNO"));
                    logger.info(storeVariable.get("PLAN_NAME"));
                    logger.info(storeVariable.get("PLAN_COST"));
                    logger.info(storeVariable.get("CURRENT_SC_PASSWORD"));
                    logger.info(storeVariable.get("ORDER_ID"));
                }
            }
        } catch (Exception e) {
            logger.error("### Some error occured FetchStoredDataFromList");
            logger.error(MainUtil.ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "FetchStoredDataFromList", e);
            getTest().get().fail("Some error occured FetchStoredDataFromList");
            throw e;
        }
    }

    /**
     * @param data pass the test data which contains (category,plan name)
     * @return Sim no and Msisdn as string
     * @throws Exception
     */
    public static synchronized String fetchTDfromDB(String data) throws Exception {
        logger.info("Fetch TD from DB");
        String query = null;
        String category;
        String planName;
        if (data.contains(",")) {
            category = data.split(",")[0];
            planName = data.split(",")[1];
            logger.info(new StringBuilder("Category: ").append(category).append("Planname: ").append(planName));
        } else {
            category = data;
            logger.info("Category {}", category);
        }
        String simno = "NA";
        String msisdn = "NA";
        String simnoid = "NA";
        try (Connection con1 = SQLConnectionHelper.getPMASDBConnectionStepnewSchema()) {
            try (Statement stmt1 = con1.createStatement()) {
                String env_type = "1";
                String sim_type;
                String sim_used_for;
                String sim_status;
                String sim_card_type = "1";
                String dealerId = "0";
                if (MainUtil.ENVIRONMENT.equalsIgnoreCase("PDC")) {
                    env_type = "3";
                    sim_card_type = "1";
                    if (category.equalsIgnoreCase("POSTPAID")) {
                        if (APPLICATION_NAME.equalsIgnoreCase("USSP"))
                            dealerId = "43214";
                        else
                            dealerId = "37721";
                    } else {
                        if (APPLICATION_NAME.equalsIgnoreCase("USSP"))
                            dealerId = "43215";
                        else
                            dealerId = "39374";
                    }
                } else if (MainUtil.ENVIRONMENT.equalsIgnoreCase("PREPROD")) {
                    env_type = "2";
                    sim_card_type = "2";
                    if (category.equalsIgnoreCase("POSTPAID")) {
                        if (APPLICATION_NAME.equalsIgnoreCase("USSP")) {
                            if (storeVariable.get("STORE_NAME").equalsIgnoreCase("KLSENTRAL")) {
                                dealerId = "16332";
                            } else if (storeVariable.get("STORE_NAME").equalsIgnoreCase("LOT10")) {
                                dealerId = "16327";
                            } else if (storeVariable.get("STORE_NAME").equalsIgnoreCase("PUBLIKA")) {
                                dealerId = "22638";
                            }
                        } else {
                            dealerId = "37721";
                        }
                    } else {
                        if (APPLICATION_NAME.equalsIgnoreCase("USSP")) {
                            if (storeVariable.get("STORE_NAME").equalsIgnoreCase("KLSENTRAL")) {
                                dealerId = "16798";
                            } else if (storeVariable.get("STORE_NAME").equalsIgnoreCase("LOT10")) {
                                dealerId = "16807";
                            } else if (storeVariable.get("STORE_NAME").equalsIgnoreCase("PUBLIKA")) {
                                dealerId = "22639";
                            }
                        } else {
                            dealerId = "39374";
                        }
                    }
                } else if (MainUtil.ENVIRONMENT.equalsIgnoreCase("TT")
                        || MainUtil.ENVIRONMENT.equalsIgnoreCase("IOT")) {
                    env_type = "1";
                    sim_card_type = "2";
                    if (category.equalsIgnoreCase("POSTPAID")) {
                        if (APPLICATION_NAME.equalsIgnoreCase("USSP")) {
                            if (storeVariable.get("STORE_NAME").equalsIgnoreCase("KLSENTRAL")) {
                                dealerId = "16332";
                            } else if (storeVariable.get("STORE_NAME").equalsIgnoreCase("LOT10")) {
                                dealerId = "16327";
                            } else if (storeVariable.get("STORE_NAME").equalsIgnoreCase("PUBLIKA")) {
                                dealerId = "22638";
                            }
                        } else {
                            dealerId = "37721";
                        }
                    } else {
                        if (APPLICATION_NAME.equalsIgnoreCase("USSP")) {
                            if (storeVariable.get("STORE_NAME").equalsIgnoreCase("KLSENTRAL")) {
                                dealerId = "16798";
                            } else if (storeVariable.get("STORE_NAME").equalsIgnoreCase("LOT10")) {
                                dealerId = "16807";
                            } else if (storeVariable.get("STORE_NAME").equalsIgnoreCase("PUBLIKA")) {
                                dealerId = "22639";
                            }
                        } else {
                            dealerId = "39374";
                        }
                    }
                }
                if (category.equalsIgnoreCase("POSTPAID"))
                    sim_type = "1";
                else
                    sim_type = "2";
                sim_status = "1";
                sim_used_for = "2";
                if (MainUtil.ENVIRONMENT.equalsIgnoreCase("PDC")) {
                    logger.info("Selecting the POSTPAID card from PDC list");
                    query = "SELECT sim_serial_no, msisdn_no, id FROM sim_management_sys_details WHERE env_type = '"
                            + env_type + "' AND sim_type = '" + sim_type + "' AND sim_used_for = '" + sim_used_for
                            + "' AND sim_status = '" + sim_status + "' AND sim_card_type = '" + sim_card_type
                            + "' and dealer_id='" + dealerId + "' ORDER BY sim_serial_no DESC LIMIT 1";

                } else if (MainUtil.ENVIRONMENT.equalsIgnoreCase("PREPROD")
                        || MainUtil.ENVIRONMENT.equalsIgnoreCase("TT")
                        || MainUtil.ENVIRONMENT.equalsIgnoreCase("IOT")) {
                    if (category.equalsIgnoreCase("POSTPAID")) {
                        if (MainUtil.storeVariable.get("PLAN_TYPE").equalsIgnoreCase("familyplan")
                                || MainUtil.storeVariable.get("PLAN_TYPE").equalsIgnoreCase("multiple")) {
                            query = "SELECT sim_serial_no, msisdn_no, id FROM sim_management_sys_details WHERE env_type = '"
                                    + env_type + "' AND sim_type = '" + sim_type + "' AND sim_used_for = '"
                                    + sim_used_for + "' AND sim_status = '" + sim_status + "' AND sim_card_type = '"
                                    + sim_card_type + "' and dealer_id='" + dealerId
                                    + "' ORDER BY sim_serial_no DESC LIMIT " + MainUtil.storeVariable.get("INSTANCE")
                                    + "";
                        } else {
                            logger.info("Selecting the POSTPAID card from PREPROD list");
                            query = "SELECT sim_serial_no, msisdn_no, id FROM sim_management_sys_details WHERE env_type = '"
                                    + env_type + "' AND sim_type = '" + sim_type + "' AND sim_used_for = '"
                                    + sim_used_for + "' AND sim_status = '" + sim_status + "' AND sim_card_type = '"
                                    + sim_card_type + "' and dealer_id='" + dealerId
                                    + "' ORDER BY sim_serial_no DESC LIMIT 1";
                        }
                    } else {
                        if (MainUtil.storeVariable.get("PLAN_TYPE").equalsIgnoreCase("multiple")) {
                            logger.info("Selecting the PREPAID card from IOT list");
                            query = "SELECT sim_serial_no, msisdn_no, id FROM sim_management_sys_details WHERE env_type = '"
                                    + env_type + "' AND sim_type = '" + sim_type + "' AND sim_used_for = '"
                                    + sim_used_for + "' AND sim_status = '" + sim_status + "' AND sim_card_type = '"
                                    + sim_card_type + "' and dealer_id='" + dealerId
                                    + "' ORDER BY sim_serial_no DESC LIMIT " + MainUtil.storeVariable.get("INSTANCE")
                                    + "";
                        } else {
                            logger.info("Selecting the PREPAID card from PREPROD list");
                            query = "SELECT sim_serial_no, msisdn_no, id FROM sim_management_sys_details WHERE env_type = '"
                                    + env_type + "' AND sim_type = '" + sim_type + "' AND sim_used_for = '"
                                    + sim_used_for + "' AND sim_status = '" + sim_status + "' AND sim_card_type = '"
                                    + sim_card_type + "' and dealer_id='" + dealerId
                                    + "' ORDER BY sim_serial_no DESC LIMIT 1";
                        }
                    }
                }
                logger.info(query);
                try (ResultSet rs1 = stmt1.executeQuery(query)) {
                    int i = 1;
                    boolean status = false;
                    while (rs1.next()) {
                        status = true;
                        if (MainUtil.storeVariable.get("PLAN_TYPE").equalsIgnoreCase("familyplan")) {
                            MainUtil.storeVariable.put("SIM" + i, rs1.getString("sim_serial_no"));
                            i++;
                        } else if (MainUtil.storeVariable.get("PLAN_TYPE").equalsIgnoreCase("multiple")) {
                            MainUtil.storeVariable.put("SIM" + i, rs1.getString("sim_serial_no"));
                            MainUtil.storeVariable.put("MSISDN" + i, rs1.getString("msisdn_no"));
                            i++;
                        } else {
                            logger.info("INSIDE RESULT");
                            simno = rs1.getString("sim_serial_no");
                            simnoid = rs1.getString("id");
                            if (rs1.getString("msisdn_no") == null || rs1.getString("msisdn_no").equalsIgnoreCase("")) {
                                logger.info("for postapid no msisdn");
                            } else {
                                msisdn = rs1.getString("msisdn_no");
                                storeVariable.put("AVAILABLE_MSISDN", msisdn);
                            }
                            getTest().get().pass(" Fecth TD from DB : Successful. Sim No :" + simno);
                            logger.info("simno" + simno);
                            storeVariable.put("AVAILABLE_SIMNO", simno);
                            storeVariable.put("SIMNO_ID", simnoid);
                        }
                    }
                    if (!status) {
                        logger.info("#### There is no record found in DB all are used ..");
                        getTest().get().fail(" There is no record found in DB all are used");
                    }
                }
            }
        } catch (Exception e) {
            logger.error("#### Some error occured FetchTDfromDB");
            logger.error(MainUtil.ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "fetchTDfromDB", e);
            getTest().get().fail("Some error occured FetchTDfromDB");
            throw new SQLException();
        }
        return simno + "," + msisdn;
    }

    /**
     * Method to calculate LhunChecksum for sim serial number
     *
     * @param data pass the 18 digit sim serial no
     * @return the 19 digit sim serial No as a String
     */
    public static synchronized String luhnchecksum(String data) {
        String serialNo = null;
        try {
            logger.info("LUHN check sum");
            serialNo = data;
            String digit;
            /* convert to array of int for simplicity */
            int[] digits = new int[serialNo.length()];
            for (int i = 0; i < serialNo.length(); i++) {
                digits[i] = Character.getNumericValue(serialNo.charAt(i));
            }
            /* double every other starting from right - jumping from 2 in 2 */
            for (int i = digits.length - 1; i >= 0; i -= 2) {
                digits[i] += digits[i];
                if (digits[i] >= 10) {
                    digits[i] = digits[i] - 9;
                }
            }
            int sum = 0;
            for (int i = 0; i < digits.length; i++) {
                sum += digits[i];
            }
            /* multiply by 9 */
            sum = sum * 9;
            /* convert to string to be easier to take the last digit */
            digit = sum + "";
            logger.info("digit is {}", digit.substring(digit.length() - 1));
            String checkDigit = digit.substring(digit.length() - 1);
            logger.info("SIM NO IS {} {}", MainUtil.ProjectConst.VALUE, serialNo.concat(checkDigit));
            // Concatenate the sim serial no with check digit
            serialNo = serialNo.concat(checkDigit);
            storeVariable.put("19DIGIT_SIM_NO", serialNo);
            logger.info("19DIGIT_SIM_NO {}", MainUtil.ProjectConst.VALUE + storeVariable.get("19DIGIT_SIM_NO"));
            getTest().get().pass("19DIGIT_SIM_NO" + MainUtil.ProjectConst.VALUE + storeVariable.get("19DIGIT_SIM_NO"));
        } catch (Exception e) {
            logger.error(MainUtil.ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "luhnchecksum", e);
            getTest().get().fail("Error occured in luhnchecksum");
        }
        return serialNo;
    }

    /**
     * Checking for sim status and device Status in SCM DB from the web service
     */
    public static synchronized void SCMSIMValidation() {
        String status;
        String simno;
        String yesid;
        try {
            logger.info("SCM sim validation");
            simno = storeVariable.get("AVAILABLE_SIMNO");
            logger.info(simno);
            SCMValidation simValid = new SCMValidation();
            JSONObject result = simValid.SCMSimValidation(simno);
            if (result != null && !result.get("Result").equals(null)) {
                JSONArray elements = result.getJSONArray("Result");
                JSONObject object = elements.getJSONObject(0);
                status = object.get("CODE").toString();
                storeVariable.put("SCM_SIM_STATUS", status);
                yesid = object.get("YES_ID").toString();
                if (status.equalsIgnoreCase("SOLD") && yesid.equalsIgnoreCase(storeVariable.get("WOM_YES_ID"))) {
                    getTest().get()
                            .pass("Successful Checked in SCM DB: " + "Sim No" + MainUtil.ProjectConst.VALUE + simno
                                    + "Yes ID" + MainUtil.ProjectConst.VALUE + yesid + "WOM Yes ID"
                                    + MainUtil.ProjectConst.VALUE + storeVariable.get("WOM_YES_ID") + " Status"
                                    + MainUtil.ProjectConst.VALUE + status);
                    logger.info("simno {} {}", MainUtil.ProjectConst.VALUE, simno);
                } else {
                    logger.info("#### Status is not Available... {}", status);
                    getTest().get()
                            .fail("Unsuccessful Checked in SCM DB: " + " Sim No : " + simno + " Yes ID : " + yesid
                                    + " WOM Yes ID : " + storeVariable.get("WOM_YES_ID") + " Status"
                                    + MainUtil.ProjectConst.VALUE + status);
                }
            } else {
                logger.info("#### There is no record found in SCM DB");
                getTest().get().fail("There is no record found in SCM DB");
            }
        } catch (Exception e) {
            logger.error(MainUtil.ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "SCMSIMValidation", e);
            getTest().get().fail("Some Error Occurred in SCMSIMValidation");
        }
    }

    /**
     * Checking for sim availability in SCM DB from the web service
     *
     * @param simNo           pass the 19 digit sim Serial No
     * @param accountCreation pass the value of account creation as
     *                        beforeAccountCreation/afterAccountCreation
     * @return a bollean value
     * @throws Exception
     */
    public static synchronized boolean checkSimStatusinSCM(String simNo, String accountCreation) throws Exception {
        boolean isSimAvailable = false;
        java.sql.Connection con1 = null;
        Statement stmt1 = null;
        ResultSet rs1 = null;
        String deviceStatus;
        try {
            logger.info("SCM sim validation");
            SCMValidation simValid = new SCMValidation();
            JSONObject result = simValid.SCMSimValidation(simNo);
            if (result != null && !result.get("Result").equals(null)) {
                if (result.get("Result").toString().equalsIgnoreCase("Session Null")) {
                    logger.info("#### Session is Null, Unable to connect to the server");
                    getTest().get().fail("Session is Null, Unable to connect to server");
                    throw new NullPointerException(result.get("Result").toString());
                } else {
                    JSONArray elements = result.getJSONArray("Result");
                    JSONObject object = elements.getJSONObject(0);
                    deviceStatus = object.get("DEVICE_STATUS_ID").toString();
                    if (accountCreation.equalsIgnoreCase("BeforeAccCreation")) {
                        if (deviceStatus.equalsIgnoreCase("1")) {
                            isSimAvailable = true;
                            logger.info("Successfully checked in SCM DB before account creation");
                            getTest().get()
                                    .pass("Successfully checked in SCM DB before account creation - sim available: "
                                            + "Sim No" + MainUtil.ProjectConst.VALUE + simNo + "WOM Yes ID"
                                            + MainUtil.ProjectConst.VALUE + storeVariable.get("WOM_YES_ID"));
                        }
                    } else {
                        if (deviceStatus.equalsIgnoreCase("2")) {
                            isSimAvailable = true;
                            logger.info("Successfully checked in SCM DB after account creation");
                            getTest().get()
                                    .pass("Successfully checked in SCM DB after account creation - sim validated : "
                                            + "Sim No" + MainUtil.ProjectConst.VALUE + simNo + "WOM Yes ID"
                                            + MainUtil.ProjectConst.VALUE + storeVariable.get("WOM_YES_ID"));
                        } else {
                            logger.info("Sim status check is fail in SCM DB after account creation");
                            getTest().get()
                                    .fail("Sim status check is fail in SCM DB after account creation : " + "Sim No"
                                            + MainUtil.ProjectConst.VALUE + simNo + "WOM Yes ID"
                                            + MainUtil.ProjectConst.VALUE + storeVariable.get("WOM_YES_ID"));
                        }
                    }
                }
            } else {
                logger.info("#### There is no record found in SCM DB");
                getTest().get().fail("There is no record found in SCM DB");
            }
        } catch (Exception e) {
            logger.error(MainUtil.ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "checkSimStatusinSCM", e);
            getTest().get().fail("Some Error Occurred in checkSimStatusinSCM");
            throw e;
        }
        return isSimAvailable;
    }

    /**
     * Method to mark sim serial number as used in STEP DB
     *
     * @throws Exception
     */
    public static synchronized void markUsed() throws Exception {
        java.sql.Connection con = null;
        String env = null;
        String status = "NA";
        String simno = storeVariable.get("AVAILABLE_SIMNO");
        if (simno == null || simno.equalsIgnoreCase("")) {
            logger.info("SIM is not used ...");
        } else {
            try {
                if (MainUtil.APPLICATION_NAME.equalsIgnoreCase("YOS")) {
                    status = "SOLD";
                } else {
                    status = storeVariable.get("SCM_SIM_STATUS");
                }
                if (status.equalsIgnoreCase("AVAILABLE")) {
                    logger.info("Status {} {}", MainUtil.ProjectConst.VALUE, status);
                    logger.info("simno {} {}", MainUtil.ProjectConst.VALUE, simno);
                    getTest().get().fail("SIM IS NOT USED AS SIM STATUS IN SCM TABLE IS AVAILABLE. ");
                } else {
                    logger.info("Status is {} {}", MainUtil.ProjectConst.VALUE, status);
                    // SQLConnectionHelper.stepNewDBcloseConnection();
                    con = SQLConnectionHelper.getPMASDBConnectionStepnewSchema();
                    String query;
                    if (MainUtil.ENVIRONMENT.equalsIgnoreCase("IOT")) {
                        env = "1";
                    } else if (MainUtil.ENVIRONMENT.equalsIgnoreCase("Preprod")) {
                        env = "2";
                    } else if (MainUtil.ENVIRONMENT.equalsIgnoreCase("PDC")) {
                        env = "3";
                    } else if (MainUtil.ENVIRONMENT.equalsIgnoreCase("TT")) {
                        env = "4";
                    }
                    if (MainUtil.ENVIRONMENT.equalsIgnoreCase("TT"))
                        query = "UPDATE sim_management_sys_details SET sim_status='2' WHERE `sim_used_for`='2' AND sim_serial_no='"
                                + simno + "' AND env_type='1'";
                    else
                        query = "UPDATE sim_management_sys_details SET sim_status='2' WHERE `sim_used_for`='2' AND sim_serial_no='"
                                + simno + "' AND env_type='" + env + "'";
                    logger.info(query);
                    try (PreparedStatement preparedStmt = con.prepareStatement(query)) {
                        preparedStmt.executeUpdate();
                    }
                    getTest().get().pass("SIM IS USED ");
                    logger.info("SMS db updated successfully ..");
                }
            } catch (Exception e1) {
                logger.error("#### Exception occured");
                logger.error(MainUtil.ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "markUsed", e1);
                getTest().get().fail("Some Error Occured");
                throw e1;
            }
        }
    }

    /**
     * Method to compare CVP amount
     *
     * @param tramount pass the transaction amount
     * @param driver   pass the driver
     */
    public static synchronized void compareCVP(String tramount, RemoteWebDriver driver) {
        String CVPAMOUNT;
        logger.info("inside compareCVP");
        try {
            CVPAMOUNT = tramount;// PropertyHelper.getPlanDetails("CVP_Amount");
            String cvpbef = storeVariable.get("CVP_BEFORE_TRANSACTION");
            String cvpaft = storeVariable.get("CVP_AFTER_TRANSACTION");
            double transactionAmount = 0.0;
            double cvpbefore = 0.0;
            double cvpafter = 0.0;
            if (CVPAMOUNT != null) {
                if (tramount.contains("RM"))
                    transactionAmount = Double.parseDouble(tramount.split("RM")[1].replaceAll(",", ""));
                else
                    transactionAmount = Double.parseDouble(tramount);
            }
            if (cvpbef != null) {
                cvpbefore = Double.parseDouble(cvpbef.split("RM")[1].replaceAll(",", ""));
            }
            if (cvpaft != null) {
                cvpafter = Double.parseDouble(cvpaft.split("RM")[1].replaceAll(",", ""));
            }
            logger.info("cvpbefore {}", cvpbefore);
            logger.info("cvpafter {}", cvpafter);
            double actualCVPDeduction = 0.0;
            actualCVPDeduction = Math.round((cvpbefore - cvpafter) * 100.0) / 100.0;
            if (actualCVPDeduction == transactionAmount) {
                logger.info("inside if 6441 - success");
                getTest().get().pass(
                        "Comparison Successful ,CVP_BEFORE_TRANSACTION=RM " + cvpbefore + "CVP_AFTER_TRANSACTION=RM "
                                + cvpafter + "TRANSACTION AMOUNT:RM " + actualCVPDeduction + " has been deducted",
                        ExtentScreenCapture.captureSrceenPass("compareCVP", driver));
            } else {
                logger.info("inside if 6445");
                getTest().get()
                        .fail("Comparison UnSuccessful ,CVP Deduction Mismatch" + "CVP_BEFORE_TRANSACTION=" + cvpbefore
                                        + "CVP_AFTER_TRANSACTION=RM " + cvpafter + " CVP_DIFFERENCE =RM " + actualCVPDeduction
                                        + "is mismatching with the actual TRANSACTION_AMOUNT=RM " + transactionAmount,
                                ExtentScreenCapture.captureSrceenFail("compareCVP", driver));
            }
        } catch (Exception e) {
            logger.error(MainUtil.ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "compareCVP", e);
            getTest().get().fail("Error occured ,Unable to compare CVP",
                    ExtentScreenCapture.captureSrceenFail("compareCVP", driver));
        }
    }

    /**
     * Method to get Message key value from QUEUE_NOTIFICATION_HISTORY table
     * through the
     *
     * @param accountType Pass the account type (Postpaid/Prepaid)
     * @param source      Pass the source (YOS/YCMS)
     * @throws SQLException Will throw SQLException
     */
    public static synchronized void getEmailMessage(String accountType, String source) throws SQLException {
        logger.info("Get email message");
        String tempPassword;
        String yesId = storeVariable.get("WOM_YES_ID");
        JSONObject result;
        try {
            GetEmailMessage message = new GetEmailMessage();
            if (accountType.equalsIgnoreCase("POSTPAID")) {
                if (source.equalsIgnoreCase("YOS")) {
                    result = message.getemailmessage(yesId, "EMAIL_POST_YOS_WELCOME", source);
                } else {
                    result = message.getemailmessage(yesId, "EMAIL_POST_YCMS_WELCOME", source);
                }
            } else {
                if (source.equalsIgnoreCase("YOS")) {
                    result = message.getemailmessage(yesId, "EMAIL_PRE_YOS_WELCOME", source);
                } else {
                    result = message.getemailmessage(yesId, "EMAIL_PRE_YCMS_WELCOME", source);
                }
            }
            if (result != null && !result.get("Result").equals(null)) {
                logger.info("inside if 1104");
                JSONArray elements = result.getJSONArray("Result");
                JSONObject object = elements.getJSONObject(0);
                tempPassword = object.get("MESSAGE_KEY_VALUE").toString().split("PASSWORD>")[1].replace("</", "");
                logger.info("tempPassword: {}", tempPassword);
                storeVariable.put(yesId, tempPassword);
                getTest().get().pass("Got Email Message Successfully");
            } else {
                logger.info("Checking in Email Notification History");
                if (accountType.equalsIgnoreCase("POSTPAID")) {
                    if (source.equalsIgnoreCase("YOS")) {
                        result = message.getemailmessage(yesId, "EMAIL_POST_YOS_WELCOME", source);
                    } else {
                        result = message.getemailmessagehistory(yesId, "EMAIL_POST_YCMS_WELCOME", source);
                    }
                } else {
                    if (source.equalsIgnoreCase("YOS")) {
                        result = message.getemailmessage(yesId, "EMAIL_PRE_YOS_WELCOME", source);
                    } else {
                        result = message.getemailmessagehistory(yesId, "EMAIL_PRE_YCMS_WELCOME", source);
                    }
                }
                if (result != null && !result.get("Result").equals(null)) {
                    JSONArray elements = result.getJSONArray("Result");
                    JSONObject object = elements.getJSONObject(0);
                    tempPassword = object.get("MESSAGE_KEY_VALUE").toString().split("PASSWORD>")[1].replace("</", "");
                    logger.info("tempPassword: {}", tempPassword);
                    storeVariable.put(yesId, tempPassword);
                    getTest().get().pass("Got Email Message Successfully In Notificaiton History");
                } else {
                    getTest().get().fail("Unbale to getEmailMessage");
                }
            }
        } catch (Exception e) {
            logger.error(MainUtil.ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "getEmailMessage", e);
            throw new SQLException();
        }
    }

    /**
     * Update a device serial no in TXN_DEALER_INVENTORY_ITEM_DETAILS DB and
     * fetch the device serial no from the same DB through the web service
     *
     * @param devieType Pass the device (Fix, Zoom or Huddle X)
     * @throws Exception Will throw Exception
     */
    public static synchronized void fetchDeviceSerialNo(String devieType) throws Exception {
        logger.info("In FetchDeviceType");
        String category = devieType;
        boolean result = false;
        JSONObject selectResult = null;
        try {
            InsertFetchDeviceSerialNo insertDevice = new InsertFetchDeviceSerialNo();
            SelectFetchDeviceSerialNo selectDevice = new SelectFetchDeviceSerialNo();
            if (category.equalsIgnoreCase("ZOOM")) {
                result = insertDevice.getDeviceSerialno("AUTZ" + RandomDataGenerator.randomChar("randomnumber#11"),
                        "20887");
                selectResult = selectDevice.getSelectFetchDeviceSerialNo("20887", "AUTZ");
            } else if (category.equalsIgnoreCase("HXS")) {
                result = insertDevice.getDeviceSerialno("AUTH" + RandomDataGenerator.randomChar("randomnumber#11"),
                        "19059");
                selectResult = selectDevice.getSelectFetchDeviceSerialNo("19059", "AUTH");
            } else if (category.equalsIgnoreCase("xiaomi")) {
                result = insertDevice.getDeviceSerialno("AUTX" + RandomDataGenerator.randomChar("randomnumber#11"),
                        "22826");
                selectResult = selectDevice.getSelectFetchDeviceSerialNo("22826", "AUTX");
            } else if (category.equalsIgnoreCase("Altitude 2")) {
                result = insertDevice.getDeviceSerialno("AUTA" + RandomDataGenerator.randomChar("randomnumber#11"),
                        "34769");
                selectResult = selectDevice.getSelectFetchDeviceSerialNo("34769", "AUTA");
            } else {
                if (ENVIRONMENT.equalsIgnoreCase("iot") || ENVIRONMENT.equalsIgnoreCase("tt")) {
                    if (APPLICATION_NAME.equalsIgnoreCase("YCMS") || APPLICATION_NAME.equalsIgnoreCase("YMCA")) {
                        if (category.equalsIgnoreCase("altitude 2")) {
                            result = insertDevice.getDeviceSerialno(
                                    "AUTA" + RandomDataGenerator.randomChar("randomnumber#11"), "34769");
                            selectResult = selectDevice.getSelectFetchDeviceSerialNo("34769", "AUTA");
                        } else if (category.equalsIgnoreCase("family")) {
                            result = insertDevice.getDeviceSerialno(
                                    "SMSG" + RandomDataGenerator.randomChar("randomnumber#11"), "40806");
                            selectResult = selectDevice.getSelectFetchDeviceSerialNo("40806", "SMSG");
                        } else if (category.equalsIgnoreCase("samsung")) {
                            result = insertDevice.getDeviceSerialno(
                                    "SMSG" + RandomDataGenerator.randomChar("randomnumber#11"), "40010");
                            selectResult = selectDevice.getSelectFetchDeviceSerialNo("40010", "SMSG");
                        } else if (category.equalsIgnoreCase("a10")) {
                            result = insertDevice.getDeviceSerialno(
                                    "SMSG" + RandomDataGenerator.randomChar("randomnumber#11"), "40797");
                            selectResult = selectDevice.getSelectFetchDeviceSerialNo("40797", "SMSG");
                        } else {
                            result = insertDevice.getDeviceSerialno(
                                    "AUTF" + RandomDataGenerator.randomChar("randomnumber#5"), "21205");
                            selectResult = selectDevice.getSelectFetchDeviceSerialNo("21205", "AUTF");
                        }
                    } else if (category.equalsIgnoreCase("FIZ")) {
                        result = insertDevice
                                .getDeviceSerialno("AUTF" + RandomDataGenerator.randomChar("randomnumber#5"), "21405");
                        selectResult = selectDevice.getSelectFetchDeviceSerialNo("21405", "AUTF");
                    } else if (category.equalsIgnoreCase("SAMSUNG")) {
                        result = insertDevice
                                .getDeviceSerialno("SMSG" + RandomDataGenerator.randomChar("randomnumber#5"), "40247");
                        selectResult = selectDevice.getSelectFetchDeviceSerialNo("40247", "SMSG");
                    } else if (category.equalsIgnoreCase("altitude")) {
                        result = insertDevice.getDeviceSerialno(
                                "862469030" + RandomDataGenerator.randomChar("randomnumber#6"), "34811");
                        selectResult = selectDevice.getSelectFetchDeviceSerialNo("34811", "862469030");
                    }
                } else if (ENVIRONMENT.equalsIgnoreCase("preprod")) {
                    if (category.equalsIgnoreCase("altitude 2")) {
                        result = insertDevice
                                .getDeviceSerialno("AUTA" + RandomDataGenerator.randomChar("randomnumber#11"), "34769");
                        selectResult = selectDevice.getSelectFetchDeviceSerialNo("34769", "AUTA");
                    } else if (category.equalsIgnoreCase("family")) {
                        result = insertDevice
                                .getDeviceSerialno("SMSG" + RandomDataGenerator.randomChar("randomnumber#11"), "47648");
                        selectResult = selectDevice.getSelectFetchDeviceSerialNo("47648", "SMSG");
                    } else if (category.equalsIgnoreCase("samsung")) {
                        result = insertDevice
                                .getDeviceSerialno("SMSG" + RandomDataGenerator.randomChar("randomnumber#11"), "40010");
                        selectResult = selectDevice.getSelectFetchDeviceSerialNo("40010", "SMSG");
                    } else if (category.equalsIgnoreCase("a10")) {
                        result = insertDevice
                                .getDeviceSerialno("SMSG" + RandomDataGenerator.randomChar("randomnumber#11"), "40797");
                        selectResult = selectDevice.getSelectFetchDeviceSerialNo("40797", "SMSG");
                    } else {
                        result = insertDevice
                                .getDeviceSerialno("AUTF" + RandomDataGenerator.randomChar("randomnumber#5"), "21205");
                        selectResult = selectDevice.getSelectFetchDeviceSerialNo("21205", "AUTF");
                    }

                }
            }
            if (result) {
                logger.info("### TXN_DEALER_INVENTORY_ITEM_DETAILS INSERTED successfully:");
            } else {
                logger.info("### TXN_DEALER_INVENTORY_ITEM_DETAILS INSERTED unsuccessful:");
            }
            if (selectResult != null && !selectResult.get("Result").equals(null)) {
                JSONArray elements = selectResult.getJSONArray("Result");
                JSONObject object = elements.getJSONObject(0);
                storeVariable.put("DEVICE_SINO", object.get("SERIAL_NO").toString());
                logger.info("DEVICE_SINO" + MainUtil.ProjectConst.VALUE + object.get("SERIAL_NO").toString());
                logger.info("DEVICE_SINO" + MainUtil.ProjectConst.VALUE + storeVariable.get("DEVICE_SINO"));
                getTest().get().pass("Device no fetched successfully from  TXN_DEALER_INVENTORY_ITEM_DETAILS table ");
            } else {
                getTest().get().fail("Device no fetched Unsuccessful from  TXN_DEALER_INVENTORY_ITEM_DETAILS table ");
            }
        } catch (Exception e) {
            logger.error(MainUtil.ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "fetchDeviceSerialNo", e);
            getTest().get().fail("error occured in fetchDeviceSerialNo");
            throw e;
        }
    }

    /**
     * Validate the device details in TXN_DEALER_INVENTORY_ITEM_DETAILS table in
     * SCM DB through the web service
     *
     * @throws Exception Will throw Exception
     */
    public static synchronized void ValidateDeviceDetails() throws Exception {
        // Action - isElementPresent
        logger.info("In ValidateDeviceDetails");
        String DeviceNo;
        String yesid = null;
        String startdate = null;
        String enddate = null;
        JSONObject result;
        try {
            DeviceNo = storeVariable.get("DEVICE_SINO");
            ValidateDeviceDetails device = new ValidateDeviceDetails();
            result = device.validateDevice(DeviceNo);
            if (result != null && !result.get("Result").equals(null)) {
                JSONArray elements = result.getJSONArray("Result");
                JSONObject object = elements.getJSONObject(0);
                yesid = object.get("YES_ID").toString();
                startdate = object.get("YES_WARRANTY_START").toString();
                enddate = object.get("YES_WARRANTY_END").toString();
                getTest().get()
                        .pass("Device details fetched successfully from  TXN_DEALER_INVENTORY_ITEM_DETAILS table YesID:"
                                + yesid + "\n Warranty start Date:" + startdate + "\n Warranty End Date :" + enddate);
                if (yesid.equalsIgnoreCase(storeVariable.get("WOM_YES_ID"))) {
                    getTest().get()
                            .pass("Yes ID is updated properly in the TXN_DEALER_INVENTORY_ITEM_DETAILS table for the serial no  "
                                    + DeviceNo);
                } else {
                    getTest().get()
                            .fail("Yes ID is not updated in the TXN_DEALER_INVENTORY_ITEM_DETAILS table for the serial no  "
                                    + DeviceNo);
                }
                SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
                long month = 0;
                logger.info(new StringBuilder("start and end date").append(startdate).append(" <--> ").append(enddate));
                long differnce = df.parse(enddate).getTime() - df.parse(startdate).getTime();
                month = (((differnce / (1000 * 60)) / 60) / 24) / 30;
                logger.info("the difference is {}", month);
                if (month == Long.parseLong(PropertyHelper.getPlanDetails("Plan_Contract_Period"))) {
                    getTest().get().pass(
                            PropertyHelper.getPlanDetails("Plan_Contract_Period") + "Contract Period is same " + month);
                } else {
                    getTest().get().fail(PropertyHelper.getPlanDetails("Plan_Contract_Period")
                            + "Contract Period is Not same " + month);
                }
            } else {
                getTest().get().fail("Device details not found from  TXN_DEALER_INVENTORY_ITEM_DETAILS table ");
            }
        } catch (Exception e) {
            logger.error(MainUtil.ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "ValidateDeviceDetails", e);
            getTest().get().fail("Some error occured in ValidateDeviceDetails");
            throw e;
        }
    }

    /**
     * get Password form the YCMS DB from QUEUE_NOTIFICATION_HISTORY based on
     * the yes id through the web service
     *
     * @throws JSONException Will throw JSONException
     */
    public static synchronized void getPasswordForCompany() throws JSONException {
        logger.info("Get Password For Company Created From Admin");
        String yesID = null;
        String fullData = null;
        String companyPassword = null;
        try {
            yesID = storeVariable.get("LOGIN_ID");
            GetCompanyPassword cpassword = new GetCompanyPassword();
            JSONObject result = cpassword.getPassword(yesID);
            if (result != null && !result.get("Result").equals(null)) {
                JSONArray elements = result.getJSONArray("Result");
                JSONObject object = elements.getJSONObject(0);
                fullData = object.get("MESSAGE_KEY_VALUE").toString();
                companyPassword = fullData.split("<TEMPORARY_PASSWORD>")[1].split("</TEMPORARY_PASSWORD>")[0];
                getTest().get().pass("Company password fetched successfully from  QUEUE_NOTIFICATION_HISTORY table");
                storeVariable.put("ADMIN_COMPANY_PASSWORD", companyPassword);
                logger.info("Company Password is" + companyPassword);
            } else {
                getTest().get().fail("Company Password not not found from  QUEUE_NOTIFICATION_HISTORY table ");
                storeVariable.put("ADMIN_COMPANY_PASSWORD", "NA");
            }
        } catch (Exception e) {
            logger.error(MainUtil.ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "getPasswordForCompany", e);
            getTest().get().fail("Some error occured in getPasswordForCompany");
            storeVariable.put("ADMIN_COMPANY_PASSWORD", "NA");
            throw e;
        }
    }

    /**
     * Method to get the time in format YYYY-MM-dd HH:mm:ss
     *
     * @return returns date as a string
     */
    public static String getTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss");
        Date date = new Date();
        logger.info(sdf.format(date));
        return sdf.format(date);
    }

    /**
     * Method to append result back to plan config schema for project apco
     *
     * @param dataId         Unique to identify the plan
     * @param startTime      time when execution started
     * @param JSONArrayIndex Index at which we update the json array in plan_steps column
     *                       in db
     * @param result         To write back the result to db either Pass or Fail
     * @param testmodule     To log which module is successful or unsuccessful.
     * @throws Exception throws Exception
     */
    public static synchronized void appendResult(String dataId, String startTime, int JSONArrayIndex, String result,
                                                 String testmodule) throws Exception {
        try (Connection con = SQLConnectionHelper.getPlanConfigDBConnection()) {
            String jsonResult = null;
            String query2 = "SELECT plan_steps FROM plan_result WHERE plan_id=?";
            try (PreparedStatement stmt1 = con.prepareStatement(query2)) {
                stmt1.setString(1, dataId);
                try (ResultSet rs3 = stmt1.executeQuery()) {
                    while (rs3.next()) {
                        jsonResult = rs3.getString(1);
                    }
                    logger.info("{} yes", jsonResult);
                    JSONArray jsary = new JSONArray(jsonResult);
                    logger.info(jsary.getJSONObject(3));
                    JSONObject jsobj = (JSONObject) jsary.get(JSONArrayIndex);
                    logger.info(jsobj.get("status"));
                    if (jsobj.get("status").toString().equalsIgnoreCase("I")) {
                        if (result.equalsIgnoreCase("P"))
                            jsobj.put("status", "P");
                        else
                            jsobj.put("status", "F");
                        logger.info(jsobj.get("status"));
                        jsobj.put("report_url", "");
                        if (result.equalsIgnoreCase("P"))
                            jsobj.put("remarks", testmodule + " is successful.");
                        else
                            jsobj.put("remarks", testmodule + " is unsuccessful.");
                        jsobj.put("end_time", ApplicationUtil.getTime());
                    }
                    logger.info(jsobj.get("status"));
                    String planSteps = jsary.toString();
                    logger.info(planSteps);
                    String query1 = "update plan_result set plan_steps = ? where plan_id=?";
                    try (PreparedStatement stmt2 = con.prepareStatement(query1)) {
                        stmt2.setString(1, planSteps);
                        stmt2.setString(2, dataId);
                        stmt2.execute();
                    }
                    String query3 = "update plan_result set plan_result = ? where plan_id=? and env_name=?";
                    try (PreparedStatement stmt3 = con.prepareStatement(query3)) {
                        stmt3.setString(1, result);
                        stmt3.setString(2, dataId);
                        stmt3.setString(3, ENVIRONMENT);
                        if (jsobj.get("step_no").toString().equalsIgnoreCase("9") || result.equalsIgnoreCase("F"))
                            stmt3.execute();
                    }
                }
            }
        } catch (Exception e) {
            logger.error(MainUtil.ProjectConst.EXCEPTIONTEXTMETHOD + " " + "appendResult", e);
            getTest().get().fail("appendResult to DB failed");
            throw e;
        }
    }

    /**
     * Method to get plan name from plan_config schema
     *
     * @return plan name returns as a String
     * @throws Exception will throw exception
     */
    public static synchronized String getPlanNamefromDB() throws Exception {
        String planName = null;
        try (Connection con = SQLConnectionHelper.getPlanConfigDBConnection()) {
            // String planId = "15b6a374-7ab7-11e8-bbb7-001a4a16018f";
            String query = "SELECT plan_name FROM plan_new WHERE id=?";
            try (PreparedStatement stmt1 = con.prepareStatement(query)) {
                // Fetching planName from plan_config schema
                stmt1.setString(1, dataId);
                try (ResultSet rs1 = stmt1.executeQuery()) {
                    while (rs1.next()) {
                        planName = rs1.getString(1);
                    }
                }
            }
        } catch (Exception e) {
            logger.error(MainUtil.ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "getPlanNamefromDB", e);
            getTest().get().fail("getPlanNamefromDB is failed");
            throw e;
        }
        return planName;
    }

    /**
     * Method to get plan details from plan config schema
     *
     * @param columnName To get certain column data from db
     * @param tableName  To get data from certain table
     * @return certain field in the db
     * @throws Exception throw exception
     */
    public static synchronized String getDetailsfromPlanConfigDB(String columnName, String tableName) throws
            Exception {
        String value = null;
        try (Connection con = SQLConnectionHelper.getPlanConfigDBConnection()) {
            String query = "SELECT " + columnName + " FROM " + tableName + " WHERE plan_id=?";
            try (PreparedStatement stmt1 = con.prepareStatement(query)) {
                // Fetching planName from plan_config schema
                stmt1.setString(1, dataId);
                try (ResultSet rs1 = stmt1.executeQuery()) {
                    while (rs1.next()) {
                        value = rs1.getString(1);
                    }
                }
            }
        } catch (SQLException e) {
            logger.error(MainUtil.ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "getDetailsfromPlanConfigDB", e);
            getTest().get().fail("getDetailsfromPlanConfigDB is failed");
            throw e;
        } catch (Exception e) {
            logger.error(MainUtil.ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "getDetailsfromPlanConfigDB", e);
            throw e;
        }
        return value;
    }

    /**
     * Update the SIM based on the ORDER number in SCM DB through the web
     * service
     */
    public static void updateInventoryInYOS() {
        logger.info("Update Inventory In YOS");
        String ORDERID = MainUtil.storeVariable.get("ORDER_ID").substring(9);
        String SIMNO = MainUtil.storeVariable.get("19DIGIT_SIM_NO");
        try {
            // ------------------------------ DB Connection
            // start-------------------------------
            YOSUpdate yos = new YOSUpdate();
            boolean result = yos.updateMacID(SIMNO, ORDERID);
            if (result) {
                getTest().get().pass("Inventory updated in YOS DB");
                logger.info("Inventory updated in YOS DB");
            } else {
                getTest().get().fail("Inventory updated in YOS DB failed");
                logger.info("Inventory updated in YOS DB failed ");
            }
        } catch (Exception e1) {
            logger.error(MainUtil.ProjectConst.EXCEPTIONTEXT);
            logger.error(MainUtil.ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " "
                    + "Inventory not updated properly in YOS DB", e1);
            getTest().get().fail("Some Error Occured");
        }
    }

    /**
     * Method to read barcode in mobile
     *
     * @param driver   Pass the driver
     * @param planName Pass the Plan name
     * @param plantype Pass the Plan type
     * @throws Exception
     */
    public synchronized static void readBarcode(RemoteWebDriver driver, String planName, String plantype)
            throws Exception {
        try {
            if (plantype.equalsIgnoreCase("PREPAID")) {
                ApplicationUtil.fetchTDfromDB(plantype + "," + planName);
            } else {
                ApplicationUtil.fetchTDfromDB(plantype);
            }
            ApplicationUtil.luhnchecksum(MainUtil.storeVariable.get("AVAILABLE_SIMNO"));
            MainUtil.launchURL("https://www.barcodesinc.com/generator/image.php?code="
                    + MainUtil.storeVariable.get("19DIGIT_SIM_NO")
                    + "&style=197&type=C128B&width=284&height=50&xres=1&font=3", driver);
        } catch (SQLException sq) {
            logger.error("Error in fetching from DB or reading from barcode");
            throw sq;
        }
    }

    /**
     * Method to fetch Prepaid sim card from PMAS DB
     *
     * @param planName
     * @param plantype
     * @throws Exception
     */
    public synchronized static void selectSimMsisdn(String planName, String plantype) throws Exception {
        try {
            if (plantype.equalsIgnoreCase("PREPAID")) {
                ApplicationUtil.fetchTDfromDB(plantype + "," + planName);
            } else {
                ApplicationUtil.fetchTDfromDB(plantype);
            }
        } catch (SQLException sq) {
            logger.error("Error in fetching from DB");
            throw sq;
        }
    }

    /**
     * Method to check payment details in XPAY_PAYMENT table with respect to
     * oder id
     *
     * @param orderID Pass the oderID
     */
    public static synchronized void verifyDataInXpayPayment(String orderID) throws Exception {
        ExtentTestNGITestListener.createNode("Xpay Payment Validation");
        String query = null;
        // SQLConnectionHelper.closeConnection();
        try (Connection con1 = SQLConnectionHelper.getDBConnection("YTLC_XPAY")) {
            try (Statement stmt1 = con1.createStatement()) {
                query = "SELECT PAYMENT_ID,AMOUNT_REQUESTED,BANK_REMARKS,PAYMENT_STATUS,PAYMENT_MODE_FK,PAYMENT_RESPONSE_REMARK,TXN_STATUS "
                        + "FROM TXN_XPAY_PAYMENT WHERE ORDER_ID = '" + orderID + "' AND DATE(CREATED_DATE)=CURDATE()";
                logger.info(query);
                try (ResultSet rs1 = stmt1.executeQuery(query)) {
                    if (rs1.next()) {
                        storeVariable.put("PAYMENT_ID", rs1.getString("PAYMENT_ID"));
                        storeVariable.put("AMOUNT_REQUESTED", rs1.getString("AMOUNT_REQUESTED"));
                        storeVariable.put("BANK_REMARKS", rs1.getString("BANK_REMARKS"));
                        storeVariable.put("PAYMENT_STATUS", rs1.getString("PAYMENT_STATUS"));
                        storeVariable.put("PAYMENT_MODE_FK", rs1.getString("PAYMENT_MODE_FK"));
                        storeVariable.put("PAYMENT_RESPONSE_REMARK", rs1.getString("PAYMENT_RESPONSE_REMARK"));
                        storeVariable.put("TXN_STATUS", rs1.getString("TXN_STATUS"));
                        getTest().get().pass("Data retrived successully from XPAY PAYMENT");
                    } else {
                        logger.info("#### There is no record found in DB ");
                        getTest().get().fail("There is no record found");
                    }
                    logger.info(storeVariable.get("PAYMENT_ID"));
                    logger.info(storeVariable.get("AMOUNT_REQUESTED"));
                    logger.info(storeVariable.get("BANK_REMARKS"));
                    logger.info(storeVariable.get("PAYMENT_STATUS"));
                    logger.info(storeVariable.get("PAYMENT_MODE_FK"));
                    logger.info(storeVariable.get("PAYMENT_RESPONSE_REMARK"));
                    logger.info(storeVariable.get("TXN_STATUS"));
                    if (!(storeVariable.get("PAYMENT_ID").isEmpty())) {
                        getTest().get().pass("Payment ID = " + storeVariable.get("PAYMENT_ID"));
                    } else {
                        getTest().get().fail("Payment ID is not found");
                    }
                    if (storeVariable.get("AMOUNT_REQUESTED").equalsIgnoreCase(storeVariable.get("AMOUNT_PAID"))) {
                        getTest().get().pass("Amount Requested = " + storeVariable.get("AMOUNT_REQUESTED")
                                + " matches Order Amount = " + storeVariable.get("AMOUNT_PAID"));
                    } else if (!(storeVariable.get("AMOUNT_REQUESTED")
                            .equalsIgnoreCase(storeVariable.get("AMOUNT_PAID")))) {
                        getTest().get().fail("Amount Requested = " + storeVariable.get("AMOUNT_REQUESTED")
                                + " does not Matches Order Amount = " + storeVariable.get("AMOUNT_PAID"));
                    } else {
                        getTest().get().fail("Amount Requested is not found");
                    }
                    if (!MainUtil.ENVIRONMENT.equalsIgnoreCase("pdc")) {
                        String PAYMENT_TYPE = storeVariable.get("PAYMENT_TYPE");
                        String BANK_REMARKS = storeVariable.get("BANK_REMARKS");
                        String PAYMENT_STATUS = storeVariable.get("PAYMENT_STATUS");
                        String PAYMENT_MODE_FK = storeVariable.get("PAYMENT_MODE_FK");
                        String TXN_STATUS = storeVariable.get("TXN_STATUS");
                        if (PAYMENT_TYPE.equalsIgnoreCase("creditcard") || PAYMENT_TYPE.equalsIgnoreCase("wirecard")) {
                            if (BANK_REMARKS.equalsIgnoreCase("APPROVED OR COMPLETED")) {
                                getTest().get().pass("Bank Remarks = " + BANK_REMARKS);
                            } else {
                                getTest().get().fail("Bank Remarks is not found or is incorrect");
                            }
                        }
                        if (PAYMENT_STATUS.equalsIgnoreCase("A")) {
                            getTest().get().pass("Approved! Payment Status = " + PAYMENT_STATUS);
                        } else if (PAYMENT_STATUS.equalsIgnoreCase("D")) {
                            getTest().get().fail("Declined! Payment Status = " + PAYMENT_STATUS);
                        } else {
                            getTest().get().fail("Payment Status is not found or is incorrect");
                        }
                        if (PAYMENT_TYPE.equalsIgnoreCase("creditcard")) {
                            if (PAYMENT_MODE_FK.equalsIgnoreCase("MBB_3D_NEW")) {
                                getTest().get().pass("PAYMENT MODE FK = " + PAYMENT_MODE_FK);
                            } else {
                                getTest().get().fail("PAYMENT MODE FK is not found or is incorrect");
                            }
                        } else if (PAYMENT_TYPE.equalsIgnoreCase("wirecard")) {
                            if (PAYMENT_MODE_FK.equalsIgnoreCase("WIRECARD_3D")) {
                                getTest().get().pass("PAYMENT MODE FK = " + PAYMENT_MODE_FK);
                            } else {
                                getTest().get().fail("PAYMENT MODE FK is not found or is incorrect");
                            }
                        } else if (PAYMENT_TYPE.equalsIgnoreCase("m2u")) {
                            if (PAYMENT_MODE_FK.equalsIgnoreCase("M2U")) {
                                getTest().get().pass("PAYMENT MODE FK = " + PAYMENT_MODE_FK);
                            } else {
                                getTest().get().fail("PAYMENT MODE FK is not found or is incorrect");
                            }
                        } else if (PAYMENT_TYPE.equalsIgnoreCase("fpx")) {
                            if (PAYMENT_MODE_FK.equalsIgnoreCase("MEPS_B2C_C")) {
                                getTest().get().pass("PAYMENT MODE FK = " + PAYMENT_MODE_FK);
                            } else {
                                getTest().get().fail("PAYMENT MODE FK is not found or is incorrect");
                            }
                        }
                        if (PAYMENT_TYPE.equalsIgnoreCase("creditcard")) {
                            if (TXN_STATUS.equalsIgnoreCase("C")) {
                                getTest().get().pass("Completed! Transaction Status = " + TXN_STATUS);
                            } else if (TXN_STATUS.equalsIgnoreCase("F")) {
                                getTest().get().fail("Failed! Transaction Status = " + TXN_STATUS);
                            } else {
                                getTest().get().fail("Transaction Status is not found or is incorrect");
                            }
                        } else if (PAYMENT_TYPE.equalsIgnoreCase("wirecard")) {
                            if (TXN_STATUS.equalsIgnoreCase("A")) {
                                getTest().get().pass("Approved! Transaction Status = " + TXN_STATUS);
                            } else if (TXN_STATUS.equalsIgnoreCase("D")) {
                                getTest().get().fail("Declined! Transaction Status = " + TXN_STATUS);
                            } else {
                                getTest().get().fail("Transaction Status is not found or is incorrect");
                            }
                        }
                    }
                }

            }
        } catch (Exception e) {
            logger.error("### Some error occured verifyDataInXpayPayment");
            logger.error(MainUtil.ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "verifyDataInXpayPayment", e);
            getTest().get().fail("Some error occured verifyDataInXpayPayment");
            throw e;
        }
    }

    /**
     * To validate the line item details in YES_ACCOUNT_LINEITEM table by
     * calling the partner web service
     *
     * @param driver pass the driver instance
     */
    public static synchronized void validateLineItemDetails(RemoteWebDriver driver) {
        try {
            logger.info("YES_ACCOUNT_LINEITEM validation");
            System.out.println(MainUtil.storeVariable.get("YES_ACCOUNT_ID"));
            YesAccountLineItem yesAccountLineItem = new YesAccountLineItem();
            JSONObject result = yesAccountLineItem.getYesAccountLineItems(MainUtil.storeVariable.get("YES_ACCOUNT_ID"));
            if (result != null && !result.get("Result").equals(null)) {
                JSONArray elements = result.getJSONArray("Result");
                JSONObject object;
                for (int i = 0; i < elements.length(); i++) {
                    object = elements.getJSONObject(i);
                    switch (object.get("LINEITEM_KEY").toString().trim()) {
                        case "Postpaid Device Price":
                            MainUtil.compareString(object.get("LINEITEM_VALUE").toString(),
                                    PropertyHelper.getPlanDetails("Plan_Device_Price").replace("RM", "").replace(".00", ""),
                                    driver, "Postpaid Device Price");
                            break;
                        case "Postpaid Activation Fee":
                            MainUtil.compareString(object.get("LINEITEM_VALUE").toString(),
                                    PropertyHelper.getPlanDetails("Plan_Act_Fee").replace("RM", "").replace(".00", ""),
                                    driver, "Postpaid Activation Fee");
                            MainUtil.compareString(object.get("TOTAL_GST_AMOUNT").toString(), "0.00", driver,
                                    "Postpaid Activation Fee");
                            break;
                        case "Plan Advanced Payment":
                            MainUtil.compareString(object.get("LINEITEM_VALUE").toString(),
                                    PropertyHelper.getPlanDetails("Plan_Adv_Pay").replace("RM", "").replace(".00", ".0"),
                                    driver, "Plan Advanced Payment");
                            MainUtil.compareString(object.get("TOTAL_GST_AMOUNT").toString(),
                                    PropertyHelper.getPlanDetails("Plan_GST").replace("RM", ""), driver,
                                    "Plan Advanced Payment");
                            break;
                        case "Postpaid Contract Period":
                            if (!object.get("LINEITEM_VALUE").toString().equalsIgnoreCase("0")) {
                                MainUtil.compareString(object.get("LINEITEM_VALUE").toString(),
                                        PropertyHelper.getPlanDetails("Plan_Contract_Period"), driver,
                                        "Postpaid Contract Period");
                            }
                            break;
                        case "Postpaid Upfront Payment":
                            MainUtil.compareString(
                                    object.get("LINEITEM_VALUE").toString(), PropertyHelper
                                            .getPlanDetails("Plan_Device_Upfront").replace("RM", "").replace(".00", ""),
                                    driver, "Postpaid Upfront Payment");
                            MainUtil.compareString(object.get("TOTAL_GST_AMOUNT").toString(), "0.00", driver,
                                    "Postpaid Upfront Payment");
                            break;
                        case "Postpaid Monthly Commitment":
                            MainUtil.compareString(object.get("LINEITEM_VALUE").toString(),
                                    PropertyHelper.getPlanDetails("Plan_Adv_Pay").replace("RM", "").replace(".00", ""),
                                    driver, "Postpaid Monthly Commitment");
                            break;
                        case "Postpaid Foreigner Deposit":
                            MainUtil.compareString(object.get("LINEITEM_VALUE").toString(),
                                    PropertyHelper.getPlanDetails("Foreigner_Depo").replace("RM", "").replace(".00", ""),
                                    driver, "Postpaid Foreigner Deposit");
                            break;
                    }
                }

            } else {
                logger.info("#### There is no record found in YES_ACCOUNT_LINEITEM DB");
                getTest().get().fail("There is no record found in YES_ACCOUNT_LINEITEM DB");
            }
        } catch (Exception e) {
            logger.error(MainUtil.ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "YES_ACCOUNT_LINEITEMValidation",
                    e);
            getTest().get().fail("Some Error Occurred in YES_ACCOUNT_LINEITEM DB Validation");
        }
    }

    /**
     * Checking for YES_ACCOUNT table in ycms DB from the web service
     *
     * @param yesId Pass the yes ID
     */
    public static synchronized void checkYesAccount(String yesId) {
        String planName;
        String yesAccountID;
        String source;
        try {
            logger.info("YES_ACCOUNT validation");
            logger.info("YesID: {}", yesId);
            GetYesAccount yesAccount = new GetYesAccount();
            JSONObject result = yesAccount.getYesAccount(yesId);
            if (result != null && !result.get("Result").equals(null)) {
                JSONArray elements = result.getJSONArray("Result");
                JSONObject object = elements.getJSONObject(0);
                planName = object.get("PLAN_NAME").toString();
                yesAccountID = object.get("YES_ACCOUNT_ID").toString();
                source = object.get("SOURCE").toString();
                MainUtil.storeVariable.put("YES_ACCOUNT_ID", yesAccountID);
                if (planName.equalsIgnoreCase(MainUtil.storeVariable.get("PLAN_NAME"))) {
                    getTest().get()
                            .pass("Successful Checked in SCM DB: " + "Plan Name" + MainUtil.ProjectConst.VALUE
                                    + planName + "Yes ID" + MainUtil.ProjectConst.VALUE + yesId + "WOM Yes ID"
                                    + MainUtil.ProjectConst.VALUE + source);
                    logger.info("yesId {} {}", MainUtil.ProjectConst.VALUE, yesId);
                } else {
                    logger.info("#### Yes ID is not available... {}", yesId);
                    getTest().get().fail("Unsuccessful Checked in Yes Account DB: " + " PlanName : " + planName
                            + " Yes ID : " + yesId + " WOM Yes ID : " + MainUtil.storeVariable.get("WOM_YES_ID"));
                }
            } else {
                logger.info("#### There is no record found in YES_ACCOUNT DB");
                getTest().get().fail("There is no record found in YES_ACCOUNT DB");
            }
        } catch (Exception e) {
            logger.error(MainUtil.ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "YESACCOUNTValidation", e);
            getTest().get().fail("Some Error Occurred in YES_ACCOUNT DB Validation");
        }
    }

    /**
     * Checking for rpt_account_new_registration_details_mv table in ycms DB
     * from the web service
     *
     * @param yesId pass yes id
     */
    public static synchronized void accountNewRegistration(String yesId) {
        String id;
        String name;
        String code;
        try {
            logger.info("rpt_account_new_registration_details_mv DB validation");
            logger.info(yesId);
            AccountNewRegistration accountNewReg = new AccountNewRegistration();
            JSONObject result = accountNewReg.accountNewRegistration(yesId);
            if (result != null && !result.get("Result").equals(null)) {
                JSONArray elements = result.getJSONArray("Result");
                JSONObject object = elements.getJSONObject(0);
                id = object.get("account_id").toString();
                name = object.get("account_name").toString();
                code = object.get("account_code").toString();
                if (id.equals("4491")) {
                    getTest().get()
                            .pass("Successful Checked in rpt_account_new_registration_details_mv DB: " + "Account ID"
                                    + MainUtil.ProjectConst.VALUE + id + "Yes ID" + MainUtil.ProjectConst.VALUE + yesId
                                    + "WOM Yes ID" + MainUtil.ProjectConst.VALUE
                                    + MainUtil.storeVariable.get("WOM_YES_ID") + MainUtil.ProjectConst.VALUE + name
                                    + MainUtil.ProjectConst.VALUE + code);
                    logger.info("Account ID {} {}", MainUtil.ProjectConst.VALUE, id);
                } else {
                    logger.info("#### Yes ID is not Available... {}", yesId);
                    getTest().get()
                            .fail("Unsuccessful Checked in rpt_account_new_registration_details_m DB: "
                                    + " Account ID : " + id + " Yes ID : " + yesId + " WOM Yes ID : "
                                    + MainUtil.storeVariable.get("WOM_YES_ID"));
                }
            } else {
                logger.info("#### There is no record found in rpt_account_new_registration_details_mv DB");
                getTest().get().fail("There is no record found in rpt_account_new_registration_details_mv DB");
            }
        } catch (Exception e) {
            logger.error(MainUtil.ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " "
                    + "rpt_account_new_registration_details_mv DB", e);
            getTest().get().fail("Some Error Occurred in rpt_account_new_registration_details_mv DB");
        }
    }

    /**
     * Checking for rpt_account_sales_tranx_details_mv table in ycms DB from the
     * web service
     *
     * @param yesId           pass yes id
     * @param transactionType pass transaction type
     */
    public static synchronized void accountSalesTransactionDetails(String yesId, String transactionType) {
        String rpt_transactionType;
        try {
            logger.info("rpt_account_sales_tranx_details_mv DB validation");
            logger.info(yesId);
            GetYesAccount yesAccount = new GetYesAccount();
            JSONObject result = yesAccount.getYesAccount(yesId);
            if (result != null && !result.get("Result").equals(null)) {
                JSONArray elements = result.getJSONArray("Result");
                JSONObject object = elements.getJSONObject(0);
                rpt_transactionType = object.get("transaction_type").toString();
                if (rpt_transactionType.equalsIgnoreCase(transactionType)) {
                    getTest().get()
                            .pass("Successful Checked in rpt_account_sales_tranx_details_mv  DB: " + "Transaction Type"
                                    + MainUtil.ProjectConst.VALUE + transactionType + "Yes ID"
                                    + MainUtil.ProjectConst.VALUE + yesId + "WOM Yes ID");
                    logger.info("yesId {} {}", MainUtil.ProjectConst.VALUE, yesId);
                } else {
                    logger.info("#### Yes ID is not available... {}", yesId);
                    getTest().get()
                            .fail("Unsuccessful Checked in rpt_account_sales_tranx_details_mv  DB: "
                                    + " Transaction Type : " + transactionType + " Yes ID : " + yesId + " WOM Yes ID : "
                                    + MainUtil.storeVariable.get("WOM_YES_ID"));
                }
            } else {
                logger.info("#### There is no record found in rpt_account_sales_tranx_details_mv  DB");
                getTest().get().fail("There is no record found in rpt_account_sales_tranx_details_mv  DB");
            }
        } catch (Exception e) {
            logger.error(
                    MainUtil.ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "rpt_account_sales_tranx_details_mv", e);
            getTest().get().fail("Some Error Occurred in rpt_account_sales_tranx_details_mv  DB Validation");
        }
    }

    public static String createCustomerCAL(String scenario, String simType, String securityType, String planName,
                                           String packageName, String accountType, String accountStatus) {
        String result = "NA";
        try {
            logger.info("Creating customer from cal service");
            CreateCustomerWsdl createcustomer = new CreateCustomerWsdl();
            result = createcustomer.CreateCustomer(scenario, simType, securityType, planName, packageName, accountType,
                    accountStatus);
            // System.out.println("0186561934@yes.my|password123|NRIC|990802784238|0186561934|896015216111397161|Yes
            // 4G LTE Postpaid 88|100261966|400164410|825144299");
            storeVariable.put("WOM_YES_ID", result.split("\\|")[0]);
            String yesid = storeVariable.get("WOM_YES_ID");
            // storeVariable.put("CURRENT_SC_PASSWORD", result.split("\\|")[1]);
            storeVariable.put(yesid, result.split("\\|")[1]);
            storeVariable.put("IDENTIFICAION_TYPE", result.split("\\|")[2]);
            storeVariable.put("CRESTEL_IDNO", result.split("\\|")[3]);
            storeVariable.put("AVAILABLE_MSISDN", result.split("\\|")[4]);
            storeVariable.put("AVAILABLE_SIMNO", result.split("\\|")[5]);
            storeVariable.put("PLAN_NAME", result.split("\\|")[6]);
            storeVariable.put("CUSTOMER_ACC_NUMBER", result.split("\\|")[7]);
            storeVariable.put("SERVICE_ACC_NUMBER", result.split("\\|")[8]);
            storeVariable.put("BILLING_AC_NUMBER", result.split("\\|")[9]);
            logger.info(storeVariable.get("WOM_YES_ID"));
            logger.info(result.split("\\|")[1]);
            logger.info("IDENTIFICAION_TYPE");
            logger.info("AVAILABLE_MSISDN");
            logger.info("AVAILABLE_SIMNO");
            logger.info("PLAN_NAME");
            logger.info("CUSTOMER_ACC_NUMBER");
            logger.info("SERVICE_ACC_NUMBER");
            logger.info("BILLING_AC_NUMBER");

        } catch (Exception e) {
            getTest().get().fail("Some Error Occurred while Creating Customer through CAL");
        }
        return result;
    }

    public static synchronized void scmUserUpdate(String isActive) {
        logger.info("In SCM User Update");
        JSONObject result = null;
        try {
            SCMUserActivation activation = new SCMUserActivation();
            result = activation.updateScmUser(isActive);
            if (result != null) {
                logger.info("### LOGISTIC and OPERATIONS User Activated Successfully :");
            } else {
                logger.info("### LOGISTIC and OPERATIONS User Activated Successfully :");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
