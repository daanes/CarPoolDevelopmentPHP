package com.ytlctest.corebase.lib;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;
import java.util.Properties;


public class PropertyHelper {
    private static Properties configprop = null;
    private static Properties envprop = null;
    private static Logger logger = LogManager.getLogger(PropertyHelper.class);
    private static HikariDataSource ycmsDs;

    static {
        ycmsDs = setMySqlConnDSForProp();
    }

    private static HikariDataSource setMySqlConnDSForProp() {
        logger.info("calling setMySqlConnDSForProp");
        HikariConfig config = new HikariConfig();
        HikariDataSource hikariDataSource;
        config.setJdbcUrl("jdbc:mysql://" + "10.28.19.110" + ":" + "3306" + "/" + "step_new" + "?autoReconnect=true&useSSL=false");
        config.setMinimumIdle(2);
        config.setMaximumPoolSize(50);
        config.setUsername("automation");
        config.setPassword("SsAvt0ck@Xme_AuT");
        config.addDataSourceProperty("cachePrepStmts", "true");
        config.addDataSourceProperty("prepStmtCacheSize", "250");
        config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
        hikariDataSource = new HikariDataSource(config);
        return hikariDataSource;
    }

    /**
     * This method is used to get the properties from config properties
     *
     * @param propertyName Pass the property name
     * @return String
     */
    public static String getProperties(String propertyName) {
        String propValue = null;
        try (Connection conn = ycmsDs.getConnection()) {
            PreparedStatement preparedStatement = conn.prepareStatement("SELECT property_value FROM config_property_lists WHERE property_name=? AND env_name is null");
            preparedStatement.setString(1, propertyName);
//			preparedStatement.setString(2, "null");
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                propValue = resultSet.getString("property_value");
            }
        } catch (SQLException e) {
            logger.error("Error while fetching the property", e);
        }
        return propValue;
    }

    /**
     * This method is used to get the properties from environment properties
     *
     * @param propertyName Pass the property name
     * @return propertyName
     */
    public static String getENVProperties(String propertyName) {
        String propValue = null;
        try (Connection conn = ycmsDs.getConnection()) {
            PreparedStatement preparedStatement = conn.prepareStatement("SELECT property_value FROM config_property_lists WHERE property_name=? AND env_name=?");
            preparedStatement.setString(1, propertyName);
            preparedStatement.setString(2, System.getProperty("env").toLowerCase());
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                propValue = resultSet.getString("property_value");
            }
        } catch (SQLException e) {
            logger.error("Error while fetching the property", e);
        }
        return propValue;
    }

    /**
     * This method is used to get the data from test data DB
     *
     * @param testDataName Pass the test data name
     * @param env          Pass the environment
     * @return a String
     * @throws Exception Will through exception
     */
    public static String getTestDataValue(String testDataName, String env) throws Exception {
        String dataValue = null;
        try (Connection con = SQLConnectionHelper.getPMASDBConnectionStepnewSchema()) {
            logger.info("Get the data from testdata DB");
            String query;
            if (env == null || env.equalsIgnoreCase("")) {
                query = "select testdata_value from auto_test_datas where testdata_property=? and deleted='0' limit 1";
            } else {
                query = "select testdata_value from auto_test_datas where testdata_property=? and deleted='0' and"
                        + " environment_type_id=(select id from auto_environment_types where env_type_name=?) limit 1 ";
            }
            try (PreparedStatement stmt1 = con.prepareStatement(query)) {
                stmt1.setString(1, testDataName);
                if (!(env == null || env.equalsIgnoreCase("")))
                    stmt1.setString(2, env);
                logger.info(query);
                try (ResultSet rs1 = stmt1.executeQuery()) {
                    if (rs1.next()) {
                        dataValue = rs1.getString("testdata_value");
                    } else {
                        logger.info("There is no value in DB with deleted status 0 ...");
                    }
                }
            }
        } catch (SQLException e) {
            logger.error("SQL Exception: ", e);
            throw new SQLException();
        }
        logger.info(new StringBuilder("testDataName").append(testDataName).append("---dataValue:").append(dataValue));
        return dataValue;
    }

    public static void updateTestDataValue(String testDataName, String testDataVlaue, String deletedValue, String env)
            throws Exception {
        try (Connection con = SQLConnectionHelper.getPMASDBConnectionStepnewSchema()) {
            logger.info("Get the data from testdata DB");
            String query;
            if (env == null || env.equalsIgnoreCase("")) {
                query = "update auto_test_datas set deleted=? where testdata_property=? and testdata_value=? ";
            } else {
                query = "update auto_test_datas set deleted=? where testdata_property=? and testdata_value=? and "
                        + "environment_type_id=(select id from auto_environment_types where env_type_name=?)";
            }
            logger.info(query);
            try (PreparedStatement preparedStmt = con.prepareStatement(query)) {
                preparedStmt.setString(1, deletedValue);
                preparedStmt.setString(2, testDataName);
                preparedStmt.setString(3, testDataVlaue);
                if (!(env == null || env.equalsIgnoreCase("")))
                    preparedStmt.setString(4, env);
                preparedStmt.executeUpdate();
            }
        } catch (SQLException e) {
            logger.error("SQL Exception: ", e);
            throw e;
        }
    }

    /**
     * This method is used to get the available hub url from the hub_details
     * table with status "0"
     *
     * @return a String
     * @throws Exception Will through exception
     */
    public static String getHubUrl() throws Exception {
        String dataValue = null;
        String id = null;
//		SQLConnectionHelper.stepNewDBcloseConnection();
        try (Connection con = SQLConnectionHelper.getPMASDBConnectionStepnewSchema()) {
            logger.info("Get the data from testdata DB");
            String query;
            query = "select id,hub_url from auto_hub_details where hub_status='0' limit 1";
            try (PreparedStatement stmt1 = con.prepareStatement(query)) {
                logger.info(query);
                try (ResultSet rs1 = stmt1.executeQuery()) {
                    while (rs1.next()) {
                        id = rs1.getString("id");
                        dataValue = rs1.getString("hub_url");
                    }
                }
            }
            MainUtil.storeVariable.put("HUB_URL_ID", id);
        } catch (SQLException e) {
            logger.error("SQL Exception: ", e);
            throw e;
        }
        return dataValue;

    }

    public static void updateReportPathToOperationSanityTrigger(String status, String reportPath, String tableid) {
        try (Connection con = SQLConnectionHelper.getPMASDBConnectionStepnewSchema()) {
            logger.info("Get the data from testdata DB");
            String query;
            if (status.equalsIgnoreCase("C")) {
                query = "UPDATE operations_sanity_triggers SET `trigger_status` =? WHERE report_path=? AND id=?";
                try (PreparedStatement preparedStmt = con.prepareStatement(query)) {
                    preparedStmt.setString(1, status);
                    preparedStmt.setString(2, reportPath);
                    preparedStmt.setString(3, tableid);
                    preparedStmt.executeUpdate();
                }
            } else {
                query = "UPDATE operations_sanity_triggers SET report_path=? where id=?";
                try (PreparedStatement preparedStmt = con.prepareStatement(query)) {
                    preparedStmt.setString(1, reportPath);
                    preparedStmt.setString(2, tableid);
                    preparedStmt.executeUpdate();
                }
            }
            logger.info(query);
        } catch (Exception e) {
            logger.error("SQL Exception: ", e);
        }
    }

    public static void UpdateCompletionStatus(String status, String tableid) {
        try (Connection con = SQLConnectionHelper.getPMASDBConnectionStepnewSchema();) {
            logger.info("Setting the completion status");
            String query;
            if (status.equalsIgnoreCase("C")) {
                query = "UPDATE operations_sanity_triggers SET `trigger_status` =? WHERE id=?";
                logger.info(query);
                try (PreparedStatement preparedStmt = con.prepareStatement(query)) {
                    preparedStmt.setString(1, status);
                    preparedStmt.setString(2, tableid);
                    preparedStmt.executeUpdate();
                }
            }
        } catch (SQLException e) {
            logger.error("SQL Exception: ", e);
        }
    }

    /**
     * This will update the status of the hub url in the DB to 0 /1
     *
     * @param id           send the stored id
     * @param deletedValue status of hub url 0/1
     * @throws Exception throws exception if any
     */
    public static void updateHubUrlStatus(String id, String deletedValue) throws SQLException {
        try (Connection con = SQLConnectionHelper.getPMASDBConnectionStepnewSchema()) {
            logger.info("Get the data from testdata DB");
            String query;
            query = "update auto_hub_details set hub_status='" + deletedValue + "' where id='" + id + "'";
            logger.info(query);
            try (PreparedStatement preparedStmt = con.prepareStatement(query)) {
                preparedStmt.executeUpdate();
            }
        } catch (SQLException e) {
            logger.error("SQL Exception: ", e);
            throw e;
        }
    }

    /**
     * This method is used to get the plan details from the DB
     *
     * @param parameterName Pass the plan parameter name
     * @return a string
     * @throws Exception Will throw exception
     */
    public static String getPlanDetails(String parameterName) throws Exception {
        String dataValue = null;
        try (Connection con = SQLConnectionHelper.getPMASDBConnectionStepnewSchema()) {
            logger.info("Get Plan Details from DB");
            String query;
            query = "select parameter_value from auto_plan_details where parameter_name=? and auto_plan_name_id=(select id from auto_plan_names where plan_name=?)";
            try (PreparedStatement stmt1 = con.prepareStatement(query)) {
                stmt1.setString(1, parameterName);
                if (MainUtil.APPLICATION_NAME.equalsIgnoreCase("YOS")) {
                    stmt1.setString(2, MainUtil.storeVariable.get("YOS_PRODUCT_NAME"));
                } else {
                    stmt1.setString(2, MainUtil.storeVariable.get("PLAN_NAME"));
                }
                logger.info(query);
                try (ResultSet rs1 = stmt1.executeQuery()) {
                    while (rs1.next()) {
                        dataValue = rs1.getString(1);
                    }
                }
            }
        } catch (SQLException e) {
            logger.error("SQL Exception: ", e);
        }
        logger.info("data value {} {}", MainUtil.ProjectConst.VALUE.getMsg(), dataValue);
        return dataValue;
    }

    /**
     * Method to get value from specific db on specific condition
     *
     * @param dbName
     * @param tableName
     * @param columnName
     * @param whereClause
     * @return
     * @throws Exception
     */
    public static String getDataFromDB(String dbName, String tableName, String columnName, String whereClause)
            throws Exception {
        String dataValue = null;
//		SQLConnectionHelper.closeConnection();
        try (Connection con = SQLConnectionHelper.getDBConnection(dbName)) {
            logger.info("Get Plan Details from DB");
            try (Statement stmt1 = con.createStatement()) {
                String query;
                query = "select " + columnName + " from " + tableName + " where " + whereClause + " ";
                logger.info(query);
                try (ResultSet rs1 = stmt1.executeQuery(query)) {
                    while (rs1.next()) {
                        dataValue = rs1.getString(1);
                    }
                }
            }
        } catch (SQLException e) {
            logger.error("SQL Exception: ", e);
        }
        logger.info("data value {} {}", MainUtil.ProjectConst.VALUE.getMsg(), dataValue);
        return dataValue;
    }
}
