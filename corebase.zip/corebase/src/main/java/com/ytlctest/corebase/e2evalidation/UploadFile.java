package com.ytlctest.corebase.e2evalidation;

import com.jcraft.jsch.*;
import com.ytlctest.corebase.lib.ExtentScreenCapture;
import com.ytlctest.corebase.lib.MainUtil.ProjectConst;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import static com.ytlctest.corebase.listener.ExtentTestNGITestListener.getTest;

public class UploadFile {
    private static Logger logger = LogManager.getLogger(UploadFile.class);

    public static void uploadFile(String Path, RemoteWebDriver driver) {
        try {
            System.out.println("PATH IS --->" + Path);
            Runtime.getRuntime().exec("cmd /c " + Path);
            getTest().get().pass("Upload Successful", ExtentScreenCapture.captureSrceenPass("uploadFile", driver));
        } catch (Exception e) {
            e.printStackTrace();
            getTest().get().fail("Upload Failed", ExtentScreenCapture.captureSrceenPass("uploadFile", driver));
        }
    }

    public static void uploadfile(String imagepath, RemoteWebDriver driver) {
        try {
            String location;
            location = "/active_pdc_accounts";
            System.out.println("location -----" + location);
            //String monitorFile = "C:\\Users\\subhra.subudhi\\Desktop\\BADMINTON\\19b.jpg";
            postFileIntoSFTP(imagepath, location);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * This method is used to upload file into SFTP
     *
     * @param monitorFile Pass the monitor file name
     * @param location    Pass the location/path in the server where the file has to be stored
     */
    private static void postFileIntoSFTP(String monitorFile, String location) {
        FileInputStream fileInputStream = null;
        try {
            JSch jsch = new JSch();
            Session session = jsch.getSession("automationteam", "10.28.19.110", 22);
            session.setPassword("pav6n3E7Wq2y");
            java.util.Properties config = new java.util.Properties();
            config.put("StrictHostKeyChecking", "no");
            session.setConfig(config);
            session.connect();
            Channel channel = session.openChannel("sftp");
            channel.connect();
            ChannelSftp channelSftp = (ChannelSftp) channel;
            try {
                channelSftp.cd(location);
            } catch (SftpException e) {
                channelSftp.mkdir(location);
                channelSftp.cd(location);
            }
            File f2 = new File(monitorFile);
            fileInputStream = new FileInputStream(f2);
            channelSftp.put(fileInputStream, f2.getName(), ChannelSftp.OVERWRITE);
            channelSftp.exit();
            session.disconnect();
        } catch (Exception ex) {
            logger.info("Unable to upload file");
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "uploadfile", ex);
        } finally {
            if (fileInputStream != null) {
                try {
                    fileInputStream.close();
                } catch (IOException e) {
                    logger.error("Error in closing fileinput stream", e);
                }
            }

        }
    }
}
