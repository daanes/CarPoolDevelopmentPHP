package com.ytlctest.corebase.e2evalidation.pageobjects;

import com.ytlctest.corebase.lib.AppWait;
import com.ytlctest.corebase.lib.MainUtil;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;


public class WomPageObjects extends MainUtil {

    private RemoteWebDriver driver;
    @FindBy(xpath = "//*[@name='txtUsername']")
    private WebElement userName;
    @FindBy(xpath = "//input[@name='txtPassword']")
    private WebElement passWord;
    @FindBy(xpath = "//td[contains(text(),'Login')]")
    private WebElement login;
    @FindBy(xpath = "//*[contains(text(),'Work Order')]")
    private WebElement workOrder;
    @FindBy(xpath = "//button[contains(.,'LTE Data & Voice Service')]")
    private WebElement lteDataAndVoiceServiceLnk;
    @FindBy(xpath = "//span[contains(.,'LTE Data Voice Service Subscription')]")
    private WebElement lteDataAndVoiceServiceSubLnk;
    @FindBy(xpath = "//td[2]/div/div/div[3]/table/tbody[2]/tr/td[2]/input")
    private WebElement enterYesID;
    @FindBy(xpath = "//button[contains(text(),'Search')]")
    private WebElement SearchButton;
    @FindBy(xpath = "//div[contains(text(),'Last Action Date')]")
    private WebElement lastActionDate;
    @FindBy(xpath = "//div[contains(text(),'Last Action Date')]/following::td[1]")
    private WebElement searchResult;
    @FindBy(xpath = "//span[contains(text(),'LDAP Response Message')]/following::td[1]")
    private WebElement LDAPResponseMessage;
    @FindBy(xpath = "//span[contains(text(),'UDC Response Message')]/following::td[1]")
    private WebElement UDCPResponseMessage;
    @FindBy(xpath = "//span[contains(text(),'UDC Response Message')]/following::td[1]")
    private WebElement OTAPResponseMessage;
    @FindBy(xpath = "//span[contains(text(),'OXMail Response Message')]/following::td[1]")
    private WebElement OXMAILResponseMessage;
    @FindBy(xpath = "//span[contains(text(),'UMS Response Message')]/following::td[1]")
    private WebElement UMSResponseMessage;
    @FindBy(xpath = "//span[contains(text(),'PCRF Response Message')]/following::td[1]")
    private WebElement PCRFResponseMessage;
    @FindBy(xpath = "//span[contains(text(),'SugarCRM Response Message')]/following::td[1]")
    private WebElement SugarCRMResponseMessage;
    @FindBy(xpath = "//span[contains(text(),'SugarCRM Response Message')]/following::td[1]")
    private WebElement AAAResponseMessage;
    @FindBy(xpath = "//span[contains(text(),'FS Response Message')]/following::td[1]")
    private WebElement FSResponseMessage;
    @FindBy(xpath = "//span[contains(text(),'NAB Response Message')]/following::td[1]")
    private WebElement NABResponseMessage;
    @FindBy(xpath = "//span[contains(text(),'IM Response Message')]/following::td[1]")
    private WebElement IMResponseMessage;
    @FindBy(xpath = "//button[contains(text(),'Hybrid')]")
    private WebElement hybridAccountLnk;
    @FindBy(xpath = "//a[contains(text(),'WiMAX and LTE Service Subscription')]")
    private WebElement hybridAccountSubLnk;
    @FindBy(xpath = "//button[contains(text(),'Wimax Data & Voice Service')]")
    private WebElement wimaxAccountLnk;
    @FindBy(xpath = " //a[contains(text(),'Voice and data Subscription')]")
    private WebElement wimaxAccountSubLnk;
    @FindBy(xpath = "//button[contains(text(),'WiMAX Other')]")
    private WebElement BBAddonLnk;
    @FindBy(xpath = "//a[contains(text(),'WiMax Add Supplementary Services')]")
    private WebElement BBAddonSubLnk;
    @FindBy(xpath = "//button[contains(text(),'LTE Other')]")
    private WebElement LTEAddonLnk;
    @FindBy(xpath = "//a[contains(text(),'LTE Add On Subscription')]")
    private WebElement LTEAddonSubLnk;
    @FindBy(xpath = "//button[contains(text(),'Hybrid')]")
    private WebElement hybridAddonLnk;
    @FindBy(xpath = "//a[contains(text(),'WIMAX AND LTE ADD ON SUBSCRIPTION')]")
    private WebElement hybridAddonSubLnk;
    @FindBy(xpath = "//*[contains(text(),'WiMAX and LTE Change Persona Password')]")
    private WebElement hybridAccountChangePasswordSubLnk;
    @FindBy(xpath = "//*[contains(text(),'WiMAX and LTE Change Persona Password')]")
    private WebElement LTEAccountChangePasswordSubLnk;

    public WomPageObjects(RemoteWebDriver driver) {
        this.driver = driver;
    }

    public WebElement getUserName() {
        return AppWait.waitForElementForVisibility(driver, userName);
    }

    public WebElement getPassWord() {
        return AppWait.waitForElementForVisibility(driver, passWord);
    }

    public WebElement getLogin() {
        return AppWait.waitForElementToBeClickable(driver, login);
    }

    public WebElement getWorkOrder() {
        return AppWait.waitForElementToBeClickable(driver, workOrder);
    }

    public WebElement getLteDataAndVoiceServiceLnk() {
        return AppWait.waitForElementToBeClickable(driver, lteDataAndVoiceServiceLnk);
    }

    public WebElement getLteDataAndVoiceServiceSubLnk() {
        return AppWait.waitForElementToBeClickable(driver, lteDataAndVoiceServiceSubLnk);
    }

    public WebElement getEnterYesID() {
        return AppWait.waitForElementForVisibility(driver, enterYesID);
    }

    public WebElement getSearchButton() {
        return AppWait.waitForElementToBeClickable(driver, SearchButton);
    }

    public WebElement getLastActionDate() {
        return AppWait.waitForElementToBeClickable(driver, lastActionDate);
    }

    public WebElement getSearchResult() {
        return AppWait.waitForElementToBeClickable(driver, searchResult);
    }

    public WebElement getLDAPResponseMessage() {
        return AppWait.waitForElementForVisibility(driver, LDAPResponseMessage);
    }

    public WebElement getUDCPResponseMessage() {
        return AppWait.waitForElementForVisibility(driver, UDCPResponseMessage);
    }

    public WebElement getOTAPResponseMessage() {
        return AppWait.waitForElementForVisibility(driver, OTAPResponseMessage);
    }

    public WebElement getOXMAILResponseMessage() {
        return AppWait.waitForElementForVisibility(driver, OXMAILResponseMessage);
    }

    public WebElement getUMSResponseMessage() {
        return AppWait.waitForElementForVisibility(driver, UMSResponseMessage);
    }

    public WebElement getPCRFResponseMessage() {
        return AppWait.waitForElementForVisibility(driver, PCRFResponseMessage);
    }

    public WebElement getSugarCRMResponseMessage() {
        return AppWait.waitForElementForVisibility(driver, SugarCRMResponseMessage);
    }

    public WebElement getAAAResponseMessage() {
        return AppWait.waitForElementForVisibility(driver, AAAResponseMessage);
    }

    public WebElement getFSResponseMessage() {
        return AppWait.waitForElementForVisibility(driver, FSResponseMessage);
    }

    public WebElement getNABResponseMessage() {
        return AppWait.waitForElementForVisibility(driver, NABResponseMessage);
    }

    public WebElement getIMResponseMessage() {
        return AppWait.waitForElementForVisibility(driver, IMResponseMessage);
    }


    public WebElement getHybridAccountLnk() {
        return AppWait.waitForElementToBeClickable(driver, hybridAccountLnk);
    }

    public WebElement getHybridAccountSubLnk() {
        return AppWait.waitForElementToBeClickable(driver, hybridAccountSubLnk);
    }

    public WebElement getWimaxAccountLnk() {
        return AppWait.waitForElementToBeClickable(driver, wimaxAccountLnk);
    }

    public WebElement getWimaxAccountSubLnk() {
        return AppWait.waitForElementToBeClickable(driver, wimaxAccountSubLnk);
    }

    public WebElement getBBAddonLnk() {
        return AppWait.waitForElementToBeClickable(driver, BBAddonLnk);
    }

    public WebElement getBBAddonSubLnk() {
        return AppWait.waitForElementToBeClickable(driver, BBAddonSubLnk);
    }

    public WebElement getLTEAddonLnk() {
        return AppWait.waitForElementToBeClickable(driver, LTEAddonLnk);
    }

    public WebElement getLTEAddonSubLnk() {
        return AppWait.waitForElementToBeClickable(driver, LTEAddonSubLnk);
    }

    public WebElement getHybridAddonLnk() {
        return AppWait.waitForElementToBeClickable(driver, hybridAddonLnk);
    }

    public WebElement getHybridAddonSubLnk() {
        return AppWait.waitForElementToBeClickable(driver, hybridAddonSubLnk);
    }

    public WebElement getHybridAccountChangePasswordSubLnk() {
        return AppWait.waitForElementToBeClickable(driver, hybridAccountChangePasswordSubLnk);
    }

    public WebElement getLTEAccountChangePasswordSubLnk() {
        return AppWait.waitForElementToBeClickable(driver, LTEAccountChangePasswordSubLnk);
    }

}
