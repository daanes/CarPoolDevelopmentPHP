package com.ytlctest.corebase.datasource;

import com.ytlctest.corebase.lib.ApplicationUtil;
import com.ytlctest.corebase.lib.SQLConnectionHelper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import static com.ytlctest.corebase.lib.ApplicationUtil.getTime;

public class GetTestData {

    // Test Data variables to be used as extentTest data to execute the crestal or plan configBasicPageFuncs automation
    public static String plan_name;
    public static String service_type;
    public static String ch_pattern;
    public static String plan_type;
    public static String pk_validity;
    public static String credit_class;
    public static String monthly_comm;
    public static String plan_tonnage;
    public static String cont_period;
    public static String fg_deposit;
    public static String cont_term_penalty;
    public static String activat_fee;
    public static String device_price;
    public static String upfront_pay;
    public static String plan_adv_pay;
    public static String usage_limit;
    public static String status_flag;
    public static String accesspoint;
    //    public static String device_group_id;
//    public static String device_name;
    public static String pcrf_access_point;
    public static String full_speed;
    public static String throttle_speed;
    public static String device_tac;
    public static String tac_rr_pcc;
    public static String ims_pcc;
    public static String sos_pcc;
    public static String roaming_pcc;
    public static String groups;
    public static String quota_profile_type;
    public static String qos_profile_name;
    public static String adv_condition;
    public static String download_speed;
    public static String download_speed_type;
    public static String upload_speed;
    public static String upload_speed_type;
    public static String created_by;
    public static String approved_by;
    public static String remarks;
    public static String created_date;
    public static String deleted;
    public static String last_updated;
    public static String ycms_service_type;
    public static String is_device_bundle;
    public static String plan_start_date;
    public static String device_name;
    public static String cc_session;
    public static String counter_name;
    public static String limit_value;
    public static String device_group;
    private static Logger logger = LogManager.getLogger(GetTestData.class);
    SQLConnectionHelper sql_helper = null;

    public static void _get_TestDataFromDB() throws Exception {
        String startTime = getTime();
        try (Connection connection = SQLConnectionHelper.getPlanConfigDBConnection()) {
            String getAllData = "SELECT * FROM `plan_new` WHERE id ='" + System.getProperty("dataId") + "'";
            logger.info(getAllData);
            try (PreparedStatement ps = connection.prepareStatement(getAllData)) {
                try (ResultSet rs = ps.executeQuery()) {
                    //Getting the data from the DB
                    while (rs.next()) {
                        plan_name = rs.getString("plan_name");
                        service_type = rs.getString("service_type");
                        ch_pattern = rs.getString("ch_pattern");
                        plan_type = rs.getString("plan_type");
                        pk_validity = rs.getString("pk_validity");
                        credit_class = rs.getString("credit_class");
                        monthly_comm = rs.getString("monthly_comm");
                        plan_tonnage = rs.getString("plan_tonnage");
                        cont_period = rs.getString("cont_period");
                        cont_term_penalty = rs.getString("cont_term_penalty");
                        fg_deposit = rs.getString("fg_deposit");
                        activat_fee = rs.getString("activat_fee");
                        device_price = rs.getString("device_price");
                        upfront_pay = rs.getString("upfront_pay");
                        plan_adv_pay = rs.getString("plan_adv_pay");
                        usage_limit = rs.getString("usage_limit");
                        status_flag = rs.getString("status_flag");
                        accesspoint = rs.getString("access_point");
                        pcrf_access_point = rs.getString("pcrf_access_point");
                        full_speed = rs.getString("full_speed");
                        throttle_speed = rs.getString("throttle_speed");
                        device_tac = rs.getString("device_tac");
                        tac_rr_pcc = rs.getString("tac_rr_pcc");
                        ims_pcc = rs.getString("ims_pcc");
                        sos_pcc = rs.getString("sos_pcc");
                        roaming_pcc = rs.getString("roaming_pcc");
                        groups = rs.getString("groups");
                        quota_profile_type = rs.getString("quota_profile_type");
                        qos_profile_name = rs.getString("qos_profile_name");
                        adv_condition = rs.getString("adv_condition");
                        download_speed = rs.getString("download_speed");
                        download_speed_type = rs.getString("download_speed_type");
                        upload_speed = rs.getString("upload_speed");
                        upload_speed_type = rs.getString("upload_speed_type");
                        created_by = rs.getString("created_by");
                        approved_by = rs.getString("approved_by");
                        remarks = rs.getString("remarks");
                        created_date = rs.getString("created_date");
                        deleted = rs.getString("deleted");
                        last_updated = rs.getString("last_updated");
                        ycms_service_type = rs.getString("ycms_service_type");
                        is_device_bundle = rs.getString("is_device_bundle");
                        plan_start_date = rs.getString("plan_start_date");
                        device_name = rs.getString("device_name");
                        cc_session = rs.getString("cc_session");
                        counter_name = rs.getString("counter_name");
                        limit_value = rs.getString("limit_value");
                        device_group = rs.getString("device_group");
                    }
                }
                logger.info(plan_name);
                logger.info("%n");
                logger.info(usage_limit);
                logger.info("%n");
                logger.info(plan_adv_pay);
                logger.info("%n");
                logger.info(upfront_pay);
                logger.info("%n");
                logger.info(device_price);
                logger.info("%n");
                logger.info(activat_fee);
                logger.info("%n");
                logger.info(fg_deposit);
                logger.info("%n");
                logger.info(cont_term_penalty);
                logger.info("%n");
                logger.info(cont_period);
                logger.info("%n");
                logger.info(plan_tonnage);
                logger.info("%n");
                logger.info(monthly_comm);
                logger.info("%n");
                logger.info(credit_class);
                logger.info("%n");
                logger.info(ch_pattern);
                logger.info("%n");
                logger.info(pk_validity);
                logger.info("%n");
                logger.info(accesspoint);
                logger.info("%n");
                logger.info(device_group);
                logger.info("%n");
                logger.info(limit_value);
                logger.info("%n");
                logger.info(counter_name);
                logger.info("%n");
                logger.info(cc_session);
                logger.info("%n");
            }
        } catch (Exception ex) {
            logger.error("Error reading from database. Exiting the process", ex);
            Assert.fail("Error reading from database");
            ApplicationUtil.appendResult(System.getProperty("dataId"), startTime, 5, "F", "Error reading from database");
        }
    }

    public static void _get_TestDataFromDsB() {
        plan_name = "LTE FIZ AUTO TEST 1";
        ch_pattern = "Postpaid";
        plan_type = "Basic";
        pk_validity = "";
        credit_class = "BETA";
        monthly_comm = "Postpaid Monthly Commitment RM48";
        plan_tonnage = "";
        cont_period = "Contract Based Charge 24 Months";
        fg_deposit = "";
        cont_term_penalty = "Penalty Charge RM48";
        activat_fee = "Postpaid Activation Fee RM100";
        device_price = "100";
        upfront_pay = "100";
        plan_adv_pay = "Plan Advanced Payment RM48";
        usage_limit = "0";
    }

    public static void main(String[] args) throws Exception {
        GetTestData._get_TestDataFromDB();
    }
}