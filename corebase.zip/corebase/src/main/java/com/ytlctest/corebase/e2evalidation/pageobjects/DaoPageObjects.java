package com.ytlctest.corebase.e2evalidation.pageobjects;

import com.ytlctest.corebase.lib.AppWait;
import com.ytlctest.corebase.lib.MainUtil;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

public class DaoPageObjects extends MainUtil {

    private RemoteWebDriver driver;
    @FindBy(xpath = "//*[@name='txtUsername']")
    private WebElement username;
    @FindBy(xpath = "//*[@name='txtPassword']")
    private WebElement password;
    @FindBy(xpath = "//td[contains(text(),'Login')]")
    private WebElement login;
    @FindBy(xpath = "//*[contains(text(),'Work Order')]")
    private WebElement workOrder;
    @FindBy(xpath = "//button[contains(text(),'LTE Data & Voice Service')]")
    private WebElement dataVoiceService;
    @FindBy(xpath = "//a[contains(text(),'LTE Data Voice Service Subscription')]")
    private WebElement dataVoiceSubscription;
    @FindBy(xpath = "//td[2]/div/div/div[3]/table/tbody[2]/tr/td[2]/input")
    private WebElement lteYesId;
    @FindBy(xpath = "//*[@class='z-datebox-inp']")
    private WebElement dateBox;
    @FindBy(xpath = "//button[contains(text(),'Search')]")
    private WebElement searchButton;
    @FindBy(xpath = "//*[@class='z-listcell-cnt z-overflow-hidden']")
    private WebElement listCell;
    @FindBy(xpath = "//div[16]/div/div/table/tbody/tr[1]/td[2]/div/table/tbody/tr/td[2]")
    private WebElement sugarCrmResponse_nab;
    @FindBy(xpath = "//div[16]/div/div/table/tbody/tr[2]/td[2]/div/table/tbody/tr/td[2]")
    private WebElement ldapResponseMessage_sugarCrm;
    @FindBy(xpath = "//div[16]/div/div/table/tbody/tr[3]/td[2]/div/table/tbody/tr/td[2]")
    private WebElement udcResponseMessage_pcrf;
    @FindBy(xpath = "//div[16]/div/div/table/tbody/tr[4]/td[2]/div/table/tbody/tr/td[2]")
    private WebElement otaResponseMessage_ldap;
    @FindBy(xpath = "//div[16]/div/div/table/tbody/tr[5]/td[2]/div/table/tbody/tr/td[2]")
    private WebElement oxmailResponseMessage_aaa;
    @FindBy(xpath = "//div[16]/div/div/table/tbody/tr[6]/td[2]/div/table/tbody/tr/td[2]")
    private WebElement umsResponseMessage_fsr;
    @FindBy(xpath = "//div[16]/div/div/table/tbody/tr[7]/td[2]/div/table/tbody/tr/td[2]")
    private WebElement pcrfResponseMessage_im;
    @FindBy(xpath = "/html[1]/body[1]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/div[12]/div[1]/div[1]/table[1]/tbody[1]/tr[1]/td[2]/div[1]/table[1]/tbody[1]/tr[1]/td[2]/span[1]")
    private WebElement sim_replacement_sugarCRM;
    @FindBy(xpath = "/html[1]/body[1]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/div[12]/div[1]/div[1]/table[1]/tbody[1]/tr[3]/td[2]/div[1]/table[1]/tbody[1]/tr[1]/td[2]/span[1]")
    private WebElement sim_replacement_ota;
    @FindBy(xpath = "/html[1]/body[1]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/div[12]/div[1]/div[1]/table[1]/tbody[1]/tr[2]/td[2]/div[1]/table[1]/tbody[1]/tr[1]/td[2]/span[1]")
    private WebElement sim_replacement_udc;
    @FindBy(xpath = "	/html[1]/body[1]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/div[12]/div[1]/div[1]/table[1]/tbody[1]/tr[4]/td[2]/div[1]/table[1]/tbody[1]/tr[1]/td[2]/span[1]")
    private WebElement sim_replacement_ums;
    @FindBy(xpath = "/html[1]/body[1]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/div[12]/div[1]/div[1]/table[1]/tbody[1]/tr[5]/td[2]/div[1]/table[1]/tbody[1]/tr[1]/td[2]/span[1]")
    private WebElement sim_replacement_pcrf;
    @FindBy(xpath = "//button[contains(text(),'Wimax Data & Voice Service')]")
    private WebElement wmaxDataAndVoiceService;
    @FindBy(xpath = " //a[contains(text(),'Voice and data Subscription')]")
    private WebElement voiceAndDataSubscription;
    @FindBy(xpath = "//table/tbody[2]/tr/td[2]/div/div/div[3]/table/tbody[2]/tr/td[2]/input")
    private WebElement wimaxHybridYesId;
    @FindBy(xpath = "//div[16]/div/div/table/tbody/tr[8]/td[2]/div/table/tbody/tr/td[2]")
    private WebElement wimax_UdcResponseMessage;
    @FindBy(xpath = "//div[16]/div/div/table/tbody/tr[9]/td[2]/div/table/tbody/tr/td[2]")
    private WebElement wimax_UmsResponseMessage;
    @FindBy(xpath = "//button[contains(text(),'Hybrid Convert Plan')]/preceding::button[1]/../preceding-sibling::button")
    private WebElement hybrid;
    @FindBy(xpath = "//button[contains(text(),'Hybrid Convert Plan')]")
    private WebElement hybrid_Convert_plan;
    @FindBy(xpath = "//a[contains(text(),'WiMAX and LTE Service Subscription')]")
    private WebElement wimaxAndLteSubscription;
    @FindBy(xpath = "//a[contains(text(),'WiMAX and LTE  to WiMAX and LTE')]")
    private WebElement wimaxLTECon;
    @FindBy(xpath = "//span[text()=\"SugarCRM Response Message\"]/../../td[2]/span")
    private WebElement hybrid_SugarCrmResponseMessage;
    @FindBy(xpath = "//span[text()=\"LDAP Response Message\"]/../../td[2]/span")
    private WebElement hybrid_LdapResponseMessage;
    @FindBy(xpath = "//span[text()=\"UDC Response Message\"]/../../td[2]/span")
    private WebElement hybrid_UdcResponseMessage;
    @FindBy(xpath = "//span[text()=\"OTA Response Message\"]/../../td[2]/span")
    private WebElement hybrid_OtaResponseMessage;
    @FindBy(xpath = "//span[text()=\"AAA Response Message\"]/../../td[2]/span")
    private WebElement hybrid_AAAResponseMessage;
    @FindBy(xpath = "//span[text()=\"PCRF Response Message\"]/../../td[2]/span")
    private WebElement hybrid_PcrfResponseMessage;
    @FindBy(xpath = "//button[contains(text(),'WiMAX Other')]")
    private WebElement wimaxOther;
    @FindBy(xpath = "(//span[contains(text(),'Sugar')])[3]/../../td[2]/span")
    private WebElement plan_Conversion_SugarCrmResponseMessage;
    @FindBy(xpath = "(//span[contains(text(),'AAA')])[3]/../../td[2]/span")
    private WebElement plan_Convesion_AAAResponseMessage;
    @FindBy(xpath = "(//span[contains(text(),'PCRF')])[3]/../../td[2]/span")
    private WebElement plan_Convesion_PcrfResponseMessage;
    @FindBy(xpath = "(//span[contains(text(),'Sugar')])[4]/../../td[2]/span")
    private WebElement DelCust_FullSuspnd_SugarCrmResMsg;
    @FindBy(xpath = "(//span[contains(text(),'AAA')])[4]/../../td[2]/span")
    private WebElement DelCust_FullSuspnd_AAAResMsg;
    @FindBy(xpath = "(//span[contains(text(),'PCRF')])[4]/../../td[2]/span")
    private WebElement DelCust_FullSuspnd_PcrfResMsg;
    @FindBy(xpath = "(//span[contains(text(),'LDAP')])[4]/../../td[2]/span")
    private WebElement DelCust_FullSuspnd_LDAPResMsg;
    @FindBy(xpath = "(//span[contains(text(),'UMS')])[4]/../../td[2]/span")
    private WebElement DelCust_FullSuspnd_UMSResMsg;
    @FindBy(xpath = "(//span[contains(text(),'UDC')])[4]/../../td[2]/span")
    private WebElement DelCust_FullSuspnd_UDCResMsg;
    @FindBy(xpath = "(//span[contains(text(),'UDC')])[3]/../../td[2]/span")
    private WebElement UDCResponseMessage;
    @FindBy(xpath = "//a[contains(text(),'WiMax Add Supplementary Services')]")
    private WebElement wimaxSupplementaryService;
    @FindBy(xpath = "//span[text()='Yes Id']/following::input[1]")
    private WebElement wimaxLteYesId;
    @FindBy(xpath = "//div[contains(text(),'Last Action Date')]")
    private WebElement lastActionDate;
    @FindBy(xpath = "//div[contains(text(),'Last Action Date')]/following::td[1]")
    private WebElement wimaxLastActionDate_AddOn;
    @FindBy(xpath = "//span[contains(text(),'PCRF Response Message')]/following::td[1]")
    private WebElement lte_PcrfResponseMessage_AddOn_Hybrid;
    @FindBy(xpath = "//span[contains(text(),'FS Response Message')]/following::td[1]")
    private WebElement lte_FsResponseMessage;
    @FindBy(xpath = "//span[contains(text(),'NAB Response Message')]/following::td[1]")
    private WebElement lte_NabResposeMessage;
    @FindBy(xpath = "//span[contains(text(),'UMS ResponseMessage')]/following::td[1]")
    private WebElement lte_UmsResponseMesage_AddOn;
    @FindBy(xpath = "//span[contains(text(),'UDC Response Message')]/following::td[1]")
    private WebElement lte_UdcResponseMessage_AddOn_Hybrid;
    @FindBy(xpath = "//span[contains(text(),'AAA Response Message')]/following::td[1]")
    private WebElement lte_AaaResponseMessage_HybridPassword;
    @FindBy(xpath = "//button[contains(text(),'LTE Other')]")
    private WebElement lteOther;
    @FindBy(xpath = "//a[contains(text(),'LTE Add On Subscription')]")
    private WebElement lteAddOnSubscription;
    @FindBy(xpath = "//a[contains(text(),'WIMAX AND LTE ADD ON SUBSCRIPTION')]")
    private WebElement wimaxLteAddOnSubscription;
    @FindBy(xpath = "//*[contains(text(),'WiMAX and LTE Change Persona Password')]")
    private WebElement wimaxLteChangePassword;
    @FindBy(xpath = "//span[contains(text(),'LDAP_ResponseMessage')]/following::td[1]")
    private WebElement LdapResponseMessage_ltePassword;
    @FindBy(xpath = "//span[contains(text(),'AAA_ResponseMessage')]/following::td[1]")
    private WebElement AaaResponseMessage_ltePassword;
    @FindBy(xpath = "//button[contains(text(),'LTE Data & Voice Service')]")
    private WebElement lteDataVoiceService;
    @FindBy(xpath = "//a[contains(text(),'LTE Data Voice Change Persona Password')]")
    private WebElement lteDataVoiceChangePassword;
    @FindBy(xpath = "//span[contains(text(),'LDAP Response Message')]/following::td[1]")
    private WebElement ldapResponseMessage;
    @FindBy(xpath = "//*[contains(text(),'Logout')]")
    private WebElement logout;
    @FindBy(xpath = "//button[contains(text(),'LTE Data Service')]")
    private WebElement lteDataService;
    @FindBy(xpath = "//a[contains(text(),'LTE Data Service Subscription')]")
    private WebElement lteDataServiceSubscription;
    @FindBy(xpath = "//span[text()='Yes Id']/../../td/input")
    private WebElement childId;
    @FindBy(xpath = "//div[12]/div/div/table/tbody/tr[1]/td[2]/div/table/tbody/tr/td[2]")
    private WebElement sugarCRMFiz;
    @FindBy(xpath = "//div[12]/div/div/table/tbody/tr[2]/td[2]/div/table/tbody/tr/td[2]")
    private WebElement ldapFiz;
    @FindBy(xpath = "//div[12]/div/div/table/tbody/tr[3]/td[2]/div/table/tbody/tr/td[2]")
    private WebElement udcFiz;
    @FindBy(xpath = "//div[12]/div/div/table/tbody/tr[4]/td[2]/div/table/tbody/tr/td[2]")
    private WebElement otpFiz;
    @FindBy(xpath = "//div[12]/div/div/table/tbody/tr[5]/td[2]/div/table/tbody/tr/td[2]")
    private WebElement pcrfFiz;
    @FindBy(xpath = "//a[contains(text(),'Data Subscription')]")
    private WebElement wimaxDataSubscription;
    @FindBy(xpath = "//button[contains(text(),'Wimax Data Service')]")
    private WebElement wimaxDataService;
    @FindBy(xpath = "//span[contains(text(),'SugarCRM Response Message')]/following::td[1]")
    private WebElement wimaxDataService_SugarCRM;
    @FindBy(xpath = "//button[contains(text(),'LTE Data & Voice Service')]")
    private WebElement LTEDataAndVoiceService;
    @FindBy(xpath = "//a[contains(text(),'LTE Data Voice Service Subscription')]")
    private WebElement LTEDataVoiceSubscription;
    @FindBy(xpath = "//a[contains(text(),'LTE Data Voice Change MSISDN')]")
    private WebElement LTEDataVoiceChangeMSISDN;
    @FindBy(xpath = "(//button[contains(text(),'Hybrid')])[1]")
    private WebElement hybrid2;
    @FindBy(xpath = "//a[contains(text(),'LTE Partial Service Suspend')]")
    private WebElement LTEPartialSuspend;
    @FindBy(xpath = "//a[contains(text(),'LTE Delete Customer Data & Voice')]")
    private WebElement LTEDeleteCustomer;
    @FindBy(xpath = "//a[contains(.,'WiMAX and LTE Full Service Suspend')]")
    private WebElement LTEFullSuspend;
    @FindBy(xpath = "//a[contains(.,'WiMAX and LTE Full Service Resume')]")
    private WebElement LTEFullResume;

    public DaoPageObjects(RemoteWebDriver driver) {
        this.driver = driver;
    }

    public WebElement getWimaxDataService_SugarCRM() {
        return AppWait.waitForElementForVisibility(driver, wimaxDataService_SugarCRM);
    }

    public WebElement getWimaxDataSubscription() {
        return AppWait.waitForElementToBeClickable(driver, wimaxDataSubscription);
    }


    public WebElement getWimaxDataService() {
        return AppWait.waitForElementToBeClickable(driver, wimaxDataService);
    }


    public WebElement getSugarCRMFiz() {
        return AppWait.waitForElementToBeClickable(driver, sugarCRMFiz);
    }


    public WebElement getLdapFiz() {
        return AppWait.waitForElementToBeClickable(driver, ldapFiz);
    }


    public WebElement getUdcFiz() {
        return AppWait.waitForElementToBeClickable(driver, udcFiz);
    }


    public WebElement getOtpFiz() {
        return AppWait.waitForElementToBeClickable(driver, otpFiz);
    }


    public WebElement getPcrfFiz() {
        return AppWait.waitForElementToBeClickable(driver, pcrfFiz);
    }


    public WebElement getLteDataService() {
        return AppWait.waitForElementToBeClickable(driver, lteDataService);
    }

    public WebElement getWimaxLTECon() {
        return AppWait.waitForElementToBeClickable(driver, wimaxLTECon);
    }


    public WebElement getLteDataServiceSubscription() {
        return AppWait.waitForElementToBeClickable(driver, lteDataServiceSubscription);
    }


    public WebElement getChildId() {
        return AppWait.waitForElementToBeClickable(driver, childId);
    }


    public WebElement getLogout() {
        return AppWait.waitForElementToBeClickable(driver, logout);
    }


    public WebElement getUsername() {
        return AppWait.waitForElementToBeClickable(driver, username);
    }

    public WebElement getPassword() {
        return AppWait.waitForElementToBeClickable(driver, password);
    }

    public WebElement getLogin() {
        return AppWait.waitForElementToBeClickable(driver, login);
    }

    public WebElement getWorkOrder() {
        return AppWait.waitForElementToBeClickable(driver, workOrder);
    }

    public WebElement getDataVoiceService() {
        return AppWait.waitForElementToBeClickable(driver, dataVoiceService);
    }

    public WebElement getDataVoiceSubscription() {
        return AppWait.waitForElementToBeClickable(driver, dataVoiceSubscription);
    }

    public WebElement getLteYesId() {
        return AppWait.waitForElementToBeClickable(driver, lteYesId);
    }

    public WebElement getDateBox() {
        return AppWait.waitForElementToBeClickable(driver, dateBox);
    }

    public WebElement getSearchButton() {
        return AppWait.waitForElementToBeClickable(driver, searchButton);
    }

    public WebElement getListCell() {
        return AppWait.waitForElementToBeClickable(driver, listCell);
    }

    public WebElement getSugarCrmResponse_nab() {
        return AppWait.waitForElementForVisibility(driver, sugarCrmResponse_nab);
    }

    public WebElement getLdapResponseMessage_sugarCrm() {
        return AppWait.waitForElementForVisibility(driver, ldapResponseMessage_sugarCrm);
    }

    public WebElement getUdcResponseMessage_pcrf() {
        return AppWait.waitForElementForVisibility(driver, udcResponseMessage_pcrf);
    }

    public WebElement getOtaResponseMessage_ldap() {
        return AppWait.waitForElementForVisibility(driver, otaResponseMessage_ldap);
    }

    public WebElement getOxmailResponseMessage_aaa() {
        return AppWait.waitForElementForVisibility(driver, oxmailResponseMessage_aaa);
    }

    public WebElement getUmsResponseMessage_fsr() {
        return AppWait.waitForElementForVisibility(driver, umsResponseMessage_fsr);
    }

    public WebElement getPcrfResponseMessage_im() {
        return AppWait.waitForElementForVisibility(driver, pcrfResponseMessage_im);
    }

    public WebElement getWmaxDataAndVoiceService() {
        return AppWait.waitForElementToBeClickable(driver, wmaxDataAndVoiceService);
    }

    public WebElement getVoiceAndDataSubscription() {
        return AppWait.waitForElementToBeClickable(driver, voiceAndDataSubscription);
    }

    public WebElement getWimaxHybridYesId() {
        return AppWait.waitForElementToBeClickable(driver, wimaxHybridYesId);
    }

    public WebElement getWimax_UdcResponseMessage() {
        return AppWait.waitForElementForVisibility(driver, wimax_UdcResponseMessage);
    }

    public WebElement getWimax_UmsResponseMessage() {
        return AppWait.waitForElementForVisibility(driver, wimax_UmsResponseMessage);
    }

    public WebElement getHybrid() {
        return AppWait.waitForElementToBeClickable(driver, hybrid);
    }

    public WebElement getHybrid_Convert_plan() {
        return AppWait.waitForElementToBeClickable(driver, hybrid_Convert_plan);
    }

    public WebElement getWimaxAndLteSubscription() {
        return AppWait.waitForElementToBeClickable(driver, wimaxAndLteSubscription);
    }

    public WebElement getHybrid_SugarCrmResponseMessage() {
        return AppWait.waitForElementForVisibility(driver, hybrid_SugarCrmResponseMessage);
    }

    public WebElement getHybrid_LdapResponseMessage() {
        return AppWait.waitForElementForVisibility(driver, hybrid_LdapResponseMessage);
    }

    public WebElement getHybrid_UdcResponseMessage() {
        return AppWait.waitForElementForVisibility(driver, hybrid_UdcResponseMessage);
    }

    public WebElement getPlan_Conversion_SugarCrmResponseMessage() {
        return AppWait.waitForElementForVisibility(driver, plan_Conversion_SugarCrmResponseMessage);
    }

    public WebElement getPlan_Convesion_AAAResponseMessage() {
        return AppWait.waitForElementForVisibility(driver, plan_Convesion_AAAResponseMessage);
    }

    public WebElement getPlan_Convesion_PcrfResponseMessage() {
        return AppWait.waitForElementForVisibility(driver, plan_Convesion_PcrfResponseMessage);
    }

    public WebElement getDelCust_FullSuspnd_SugarCrmResMsg() {
        return AppWait.waitForElementForVisibility(driver, DelCust_FullSuspnd_SugarCrmResMsg);
    }

    public WebElement getDelCust_FullSuspnd_LDAPResMsg() {
        return AppWait.waitForElementForVisibility(driver, DelCust_FullSuspnd_LDAPResMsg);
    }

    public WebElement getDelCust_FullSuspnd_AAAResMsg() {
        return AppWait.waitForElementForVisibility(driver, DelCust_FullSuspnd_AAAResMsg);
    }

    public WebElement getDelCust_FullSuspnd_PcrfResMsg() {
        return AppWait.waitForElementForVisibility(driver, DelCust_FullSuspnd_PcrfResMsg);
    }

    public WebElement getDelCust_FullSuspnd_UMSResMsg() {
        return AppWait.waitForElementForVisibility(driver, DelCust_FullSuspnd_UMSResMsg);
    }

    public WebElement getDelCust_FullSuspnd_UDCPResMsg() {
        return AppWait.waitForElementForVisibility(driver, DelCust_FullSuspnd_UDCResMsg);
    }

    public WebElement getUDCResponseMessage() {
        return AppWait.waitForElementForVisibility(driver, UDCResponseMessage);
    }

    public WebElement getHybrid_OtaResponseMessage() {
        return AppWait.waitForElementForVisibility(driver, hybrid_OtaResponseMessage);
    }

    public WebElement getHybrid_AAAResponseMessage() {
        return AppWait.waitForElementForVisibility(driver, hybrid_AAAResponseMessage);
    }

    public WebElement getHybrid_PcrfResponseMessage() {
        return AppWait.waitForElementForVisibility(driver, hybrid_PcrfResponseMessage);
    }

    public WebElement getWimaxOther() {
        return AppWait.waitForElementToBeClickable(driver, wimaxOther);
    }

    public WebElement getWimaxSupplementaryService() {
        return AppWait.waitForElementToBeClickable(driver, wimaxSupplementaryService);
    }

    public WebElement getWimaxLteYesId() {
        return AppWait.waitForElementForVisibility(driver, wimaxLteYesId);
    }

    public WebElement getLastActionDate() {
        return AppWait.waitForElementToBeClickable(driver, lastActionDate);
    }

    public WebElement getWimaxLastActionDate_AddOn() {
        return AppWait.waitForElementToBeClickable(driver, wimaxLastActionDate_AddOn);
    }

    public WebElement getLte_PcrfResponseMessage_AddOn_Hybrid() {
        return AppWait.waitForElementForVisibility(driver, lte_PcrfResponseMessage_AddOn_Hybrid);
    }

    public WebElement getLte_FsResponseMessage() {
        return AppWait.waitForElementForVisibility(driver, lte_FsResponseMessage);
    }

    public WebElement getLte_NabResposeMessage() {
        return AppWait.waitForElementForVisibility(driver, lte_NabResposeMessage);
    }

    public WebElement getLte_UmsResponseMesage_AddOn() {
        return AppWait.waitForElementForVisibility(driver, lte_UmsResponseMesage_AddOn);
    }

    public WebElement getLte_UdcResponseMessage_AddOn_Hybrid() {
        return AppWait.waitForElementForVisibility(driver, lte_UdcResponseMessage_AddOn_Hybrid);
    }

    public WebElement getLte_AaaResponseMessage_HybridPassword() {
        return AppWait.waitForElementForVisibility(driver, lte_AaaResponseMessage_HybridPassword);
    }

    public WebElement getLteOther() {
        return AppWait.waitForElementToBeClickable(driver, lteOther);
    }

    public WebElement getLteAddOnSubscription() {
        return AppWait.waitForElementForVisibility(driver, lteAddOnSubscription);
    }

    public WebElement getWimaxLteAddOnSubscription() {
        return AppWait.waitForElementForVisibility(driver, wimaxLteAddOnSubscription);
    }

    public WebElement getWimaxLteChangePassword() {
        return AppWait.waitForElementForVisibility(driver, wimaxLteChangePassword);
    }

    public WebElement getLdapResponseMessage_ltePassword() {
        return AppWait.waitForElementForVisibility(driver, LdapResponseMessage_ltePassword);
    }

    public WebElement getLteDataVoiceService() {
        return AppWait.waitForElementToBeClickable(driver, lteDataVoiceService);
    }

    public WebElement getLteDataVoiceChangePassword() {
        return AppWait.waitForElementToBeClickable(driver, lteDataVoiceChangePassword);
    }

    public WebElement getAaaResponseMessage_ltePassword() {
        return AppWait.waitForElementForVisibility(driver, AaaResponseMessage_ltePassword);
    }

    public WebElement getLdapResponseMessage() {
        return AppWait.waitForElementForVisibility(driver, ldapResponseMessage);
    }

    public WebElement getLTEDataAndVoiceService() {
        return AppWait.waitForElementToBeClickable(driver, LTEDataAndVoiceService);
    }

    public WebElement getLTEDataVoiceSubscription() {
        return AppWait.waitForElementToBeClickable(driver, LTEDataVoiceSubscription);
    }

    public WebElement getLTEDataVoiceChangeMSISDN() {
        return AppWait.waitForElementToBeClickable(driver, LTEDataVoiceChangeMSISDN);
    }

    public WebElement getLTEPartialSuspend() {
        return AppWait.waitForElementToBeClickable(driver, LTEPartialSuspend);
    }

    public WebElement getLTEDeleteCustomer() {
        return AppWait.waitForElementToBeClickable(driver, LTEDeleteCustomer);
    }

    public WebElement getLTEFullSuspend() {
        return AppWait.waitForElementToBeClickable(driver, LTEFullSuspend);
    }

    public WebElement getLTEFullResume() {
        return AppWait.waitForElementToBeClickable(driver, LTEFullResume);
    }

    public WebElement gethybrid2() {
        return AppWait.waitForElementToBeClickable(driver, hybrid2);
    }

    public WebElement getsim_replacement_sugarCRM() {
        return AppWait.waitForElementToBeClickable(driver, sim_replacement_sugarCRM);
    }

    public WebElement getsim_replacement_ota() {
        return AppWait.waitForElementToBeClickable(driver, sim_replacement_ota);
    }

    public WebElement getsim_replacement_ums() {
        return AppWait.waitForElementToBeClickable(driver, sim_replacement_ums);
    }

    public WebElement getsim_replacement_udc() {
        return AppWait.waitForElementToBeClickable(driver, sim_replacement_udc);
    }

    public WebElement getsim_replacement_pcrf() {
        return AppWait.waitForElementToBeClickable(driver, sim_replacement_pcrf);
    }

}
