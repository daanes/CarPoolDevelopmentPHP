package com.ytlctest.corebase.e2evalidation.pagefunctions;

import com.ytlctest.corebase.e2evalidation.pageobjects.DaoPageObjects;
import com.ytlctest.corebase.lib.ExtentScreenCapture;
import com.ytlctest.corebase.lib.MainUtil;
import com.ytlctest.corebase.listener.ExtentTestNGITestListener;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;

import static com.ytlctest.corebase.listener.ExtentTestNGITestListener.getTest;

public class DaoPageFuncs extends DaoPageObjects {
    private static Logger logger = LogManager.getLogger(DaoPageFuncs.class);
    ExtentTestNGITestListener ex = new ExtentTestNGITestListener();
    private RemoteWebDriver driver;

    public DaoPageFuncs(RemoteWebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    /**
     * DAO Login
     *
     * @param url      Pass the URL to be opened
     * @param username Pass the username
     * @param password Pass the password
     * @throws Exception Returns the exception
     */
    public void loginPage(String url, String username, String password) throws Exception {
        try {
            logger.info("Login to WOM");
            MainUtil.launchURL(url, driver);
            Thread.sleep(5000);
            inputTextByXpath(getUsername(), username, "Username", "", driver);
            inputTextByXpath(getPassword(), password, "Password", "", driver);
            clickByXpath(getLogin(), "Login Button", driver);
            Thread.sleep(5000);
            clickByXpath(getWorkOrder(), "Work Order Button", driver);
            Thread.sleep(5000);
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD + " " + "loginPage", e);
        }
    }

    /**
     * Verifying Data Voice Subscription
     *
     * @param lteyesid Pass the LTE Yes ID
     * @param date     Pass the date (From)
     */
    public void LTEDataservice(String lteyesid, String date) {
        try {
            logger.info("Verifying Data Voice Subscription");
            mouseHoveronElement(getLteDataVoiceService(), driver);
            clickByXpath(getDataVoiceSubscription(), "Data voice subscription", driver);
            inputTextByXpath(getLteYesId(), lteyesid, "getLteYesId", "", driver);
            clearData(getDateBox());
            inputTextByXpath(getDateBox(), date, "getDateBox", "", driver);
            clickByXpath(getSearchButton(), "Search Button", driver);
            doubleClickOnElement(getListCell(), driver);
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", getSugarCrmResponse_nab());
            checkForText("", getSugarCrmResponse_nab(), "HTTP command executed successfully.", "SugarCrmResonseMessage", driver);
            checkForText("", getLdapResponseMessage_sugarCrm(), "Email added successfully.", "LDAPResponseMessage", driver);
            checkForText("", getUdcResponseMessage_pcrf(), "HTTP command executed successfully.", "UDCResponseMessage", driver);
            checkForText("", getOtaResponseMessage_ldap(), "HTTP command executed successfully.", "OTAResponseMesage", driver);
            checkForText("", getOxmailResponseMessage_aaa(), "-", "OXMailResponseMessage", driver);
            checkForText("", getUmsResponseMessage_fsr(), "UMS Provisioning Not Required", "UMSResponseMessage", driver);
            checkForText("", getPcrfResponseMessage_im(), "HTTP command executed successfully.", "PCRFResponseMessage", driver);
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD + " " + "LTEDataservice", e);
        }
    }

    /**
     * Verifying Lte Data Service Subscription (FIZ)
     *
     * @param childId Pass the child ID for FIZ plans
     * @param date    Pass the date (From)
     */
    public void LTEData(String childId, String date) {
        try {
            logger.info("Verifying Lte Data Service Subscription");
            mouseHoveronElement(getLteDataService(), driver);
            clickByXpath(getLteDataServiceSubscription(), "Lte Data Service Subscription", driver);
            inputTextByXpath(getChildId(), childId, "Child YesId", "", driver);
            //getChildId().sendKeys(childId);
            Thread.sleep(3000l);
            getDateBox().clear();
            inputTextByXpath(getDateBox(), date, "Date", "", driver);
            //getDateBox().sendKeys(date);
            clickByXpath(getSearchButton(), "Search Box", driver);
            getSearchButton().click();
            Thread.sleep(3000);
            doubleClickOnElement(getListCell(), driver);
            Thread.sleep(10000);
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", getSugarCRMFiz());
            checkForText("", getSugarCRMFiz(), "HTTP command executed successfully.", "SugarCrmFizResonseMessage",
                    driver);
            checkForText("", getLdapFiz(), "Email added successfully.", "LDAPFizResponseMessage", driver);
            checkForText("", getUdcFiz(), "HTTP command executed successfully.", "UDCFizResponseMessage", driver);
            checkForText("", getOtpFiz(), "HTTP command executed successfully.", "OTAFizResponseMesage", driver);
            checkForText("", getPcrfFiz(), "HTTP command executed successfully.", "PCRFFizResponseMessage", driver);
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD + " " + "LTEData", e);
        }
    }

    /**
     * Verifying Voice and data subscription(Wimax)
     *
     * @param wimaxYesId Pass the wimax yes ID
     * @param date       Pass the date (From)
     */
    public void wimaxDataAndVoice(String wimaxYesId, String date) {
        try {
            logger.info("Verifying Voice and data subscription");
            mouseHoveronElement(getWmaxDataAndVoiceService(), driver);
            clickByXpath(getVoiceAndDataSubscription(), "Voice and data subscription", driver);
            inputTextByXpath(getWimaxLteYesId(), wimaxYesId, "Wimax YesId", "", driver);
            //getWimaxLteYesId().sendKeys(wimaxYesId);
            getDateBox().clear();
            inputTextByXpath(getDateBox(), date, "Date", "", driver);
            //getDateBox().sendKeys(date);
            clickByXpath(getSearchButton(), "Search", driver);
            //getSearchButton().click();
            doubleClickOnElement(getListCell(), driver);
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", getSugarCrmResponse_nab());
            checkForText("", getSugarCrmResponse_nab(), "NAB Provisioning Not Required", "NABResponseMessage", driver);
            checkForText("", getLdapResponseMessage_sugarCrm(), "HTTP command executed successfully.", "SugarCRMResponseMessage", driver);
            checkForText("", getUdcResponseMessage_pcrf(), "HTTP command executed successfully.", "PCRFResponseMessage", driver);
            checkForText("", getOtaResponseMessage_ldap(), "Email added successfully.", "LDAPResponseMessage", driver);
            checkForText("", getOxmailResponseMessage_aaa(), "HTTP command executed successfully.", "AAAResponseMessage", driver);
            checkForText("", getUmsResponseMessage_fsr(), "HTTP command executed successfully.", "FSResponseMessage", driver);
            checkForText("", getPcrfResponseMessage_im(), "HTTP command executed successfully.", "IMResponseMessage", driver);
            checkForText("", getWimax_UdcResponseMessage(), "HTTP command executed successfully.", "UDCResponseMessage", driver);
            checkForText("", getWimax_UmsResponseMessage(), "UMS Provisioning Not Required", "UMSResponseMessage", driver);
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD + " " + "wimaxDataAndVoice", e);
        }
    }

    /**
     * Verifying Wimax Lte Subscription
     *
     * @param hybridYesId Pass the Hybrid Yes ID
     * @param date        Pass the date (From)
     */
    public void hybrid(String hybridYesId, String date) {
        try {
            logger.info("Verifying Voice and data subscription");
            mouseHoveronElement(getHybrid(), driver);
            clickByXpath(getWimaxAndLteSubscription(), "Wimax Lte Subscription", driver);
            inputTextByXpath(getWimaxHybridYesId(), hybridYesId, "WimaxyesId", "", driver);
            // getWimaxHybridYesId().sendKeys(hybridYesId);
            getDateBox().clear();
            inputTextByXpath(getDateBox(), date, "Date", "", driver);
            // getDateBox().sendKeys(date);
            clickByXpath(getSearchButton(), "Search", driver);
            clickByXpath(getSearchButton(), "Search", driver);
            //getSearchButton().click();
            Thread.sleep(10000);
            doubleClickOnElement(getListCell(), driver);
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", getHybrid_SugarCrmResponseMessage());
            if (MainUtil.ENVIRONMENT.equalsIgnoreCase("PDC")) {
                if (getHybrid_SugarCrmResponseMessage().getText().equalsIgnoreCase("Provisioning Bypassed") || getHybrid_SugarCrmResponseMessage().getText().equalsIgnoreCase("HTTP command executed successfully.")) {
                    getTest().get().pass("SugarCRMResponsePage", ExtentScreenCapture.captureSrceenPass("SugarCRMResponse Successfull", driver));
                }
            } else {
                logger.info("No need verification in IOT and Preprod");
            }
            checkForText("", getHybrid_LdapResponseMessage(), "Email added successfully.", "LDAPResponseMessage", driver);
            checkForText("", getHybrid_UdcResponseMessage(), "HTTP command executed successfully.", "UDCResponseMessage", driver);
            if (MainUtil.ENVIRONMENT.equalsIgnoreCase("PDC")) {
                checkForText("", getHybrid_OtaResponseMessage(), "HTTP command executed successfully.", "OTAResponseMessage", driver);
            } else {
                logger.info("No need verification in IOT and Preprod");
            }
            checkForText("", getHybrid_AAAResponseMessage(), "HTTP command executed successfully.", "AAAResponseMessage", driver);
            checkForText("", getHybrid_PcrfResponseMessage(), "LTE PCRF Add Service Subscription Success.Wimax PCRF Service Subscription Success.", "PCRFResponseMessage", driver);
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD + " " + "hybrid", e);
        }
    }

    public void planConversionProcess(String hybridYesId, String date) {
        try {
            logger.info("Verifying Voice and data subscription");
            mouseHoveronElement(getHybrid_Convert_plan(), driver);
            clickByXpath(getWimaxLTECon(), "Wimax Lte Conversion", driver);
            inputTextByXpath(getWimaxHybridYesId(), hybridYesId, "WimaxyesId", "", driver);
            // getWimaxHybridYesId().sendKeys(hybridYesId);
            getDateBox().clear();
            inputTextByXpath(getDateBox(), date, "Date", "", driver);
            // getDateBox().sendKeys(date);
            clickByXpath(getSearchButton(), "Search", driver);
            //getSearchButton().click();
            Thread.sleep(10000);
            doubleClickOnElement(getListCell(), driver);
          /*  ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", getPlan_Conversion_SugarCrmResponseMessage());
            if (MainUtil.ENVIRONMENT.equalsIgnoreCase("PDC")) {
                if (getHybrid_SugarCrmResponseMessage().getText().equalsIgnoreCase("Provisioning Bypassed") || getHybrid_SugarCrmResponseMessage().getText().equalsIgnoreCase("HTTP command executed successfully.")) {
                    getTest().get().pass("SugarCRMResponsePage", ExtentScreenCapture.captureSrceenPass("SugarCRMResponse Successfull", driver));
                }
            } else {
                getTest().get().fail("SugarCRMResponsePage", ExtentScreenCapture.captureSrceenPass("SugarCRMResponse Failed", driver));
            }*/
            checkForText("", getPlan_Convesion_AAAResponseMessage(), "HTTP command executed successfully.", "AAAResponseMessage", driver);
            //checkForText("", getPlan_Convesion_PcrfResponseMessage(), "LTE PCRF Add Service Subscription Success.Wimax PCRF Service Subscription Success.", "PCRFResponseMessage", driver);
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD + " " + "hybrid", e);
        }
    }

    /**
     * Verifying BB Addon
     *
     * @param lteyesid Pass the LTE Yes ID
     */
    public void BB_Addon(String lteyesid) {
        try {
            logger.info("BB Addon verification");
            mouseHoveronElement(getWimaxOther(), driver);
            clickByXpath(getWimaxSupplementaryService(), "Wimax supplimenatary service", driver);
            inputTextByXpath(getWimaxLteYesId(), lteyesid, "LTE Yes Id", "", driver);
            //getWimaxLteYesId().sendKeys(lteyesid);
            clickByXpath(getSearchButton(), "Search", driver);
            //getSearchButton().click();
            clickByXpath(getLastActionDate(), "LastActionDate", driver);
            //getLastActionDate().click();
            clickByXpath(getLastActionDate(), "LastActionDate", driver);
            //getLastActionDate().click();
            doubleClickOnElement(getWimaxLastActionDate_AddOn(), driver);
            checkForText("", getLte_PcrfResponseMessage_AddOn_Hybrid(), "HTTP command executed successfully.", "PCRFResponseMessage", driver);
            checkForText("", getLte_FsResponseMessage(), "No provisioning required", "FSResponseMessage", driver);
            checkForText("", getLte_NabResposeMessage(), "NAB Provisioning Not Required", "NABResposeMessage", driver);
            checkForText("", getLte_UmsResponseMesage_AddOn(), "UMS Provisioning Not Required", "UMSResponseMesage", driver);
            checkForText("", getLte_UdcResponseMessage_AddOn_Hybrid(), "UDC Provisioning Not Required", "UDCResponseMessage", driver);
            checkForText("", getLte_AaaResponseMessage_HybridPassword(), "AAA Provisioning Not Required", "AAAResponseMessage", driver);
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD + " " + "BB_Addon", e);
        }
    }

    /**
     * Verifying LTE addon
     *
     * @param lteyesid Pass the LTE Yes ID
     */
    public void LTE_Addon(String lteyesid) {
        try {
            logger.info("Verifying LTE addon");
            mouseHoveronElement(getLteOther(), driver);
            clickByXpath(getLteAddOnSubscription(), "LTE AddOn Subscription", driver);
            inputTextByXpath(getWimaxLteYesId(), lteyesid, "LTE YesId", "", driver);
            //getWimaxLteYesId().sendKeys(lteyesid);
            clickByXpath(getSearchButton(), "Search", driver);
            // getSearchButton().click();
            clickByXpath(getLastActionDate(), "LastActionDate", driver);
            // getLastActionDate().click();
            clickByXpath(getLastActionDate(), "LastActionDate", driver);
            //getLastActionDate().click();
            /*
             * If click not happened for first
             * time un comment
             */
            doubleClickOnElement(getWimaxLastActionDate_AddOn(), driver);
            checkForText("", getLte_PcrfResponseMessage_AddOn_Hybrid(), "HTTP command executed successfully.",
                    "PCRFResponseMessage", driver);
            checkForText("", getLte_UmsResponseMesage_AddOn(), "UMS Provisioning Not Required", "UMSResponseMesage",
                    driver);
            checkForText("", getLte_UdcResponseMessage_AddOn_Hybrid(),
                    "All Profiles are disabled. Provisioning is not Required.", "UDCResponseMessage", driver);
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD + " " + "LTE_Addon", e);
        }
    }

    /**
     * Verifying Hybrid Addon
     *
     * @param lteyesid Pass the LTE Yes ID
     */
    public void Hybrid_Addon(String lteyesid) {
        try {
            logger.info("Verifying Hybrid addon");
            mouseHoveronElement(getHybrid(), driver);
            clickByXpath(getWimaxLteAddOnSubscription(), "Wimax Lte AddOn Subscription", driver);
            inputTextByXpath(getWimaxLteYesId(), lteyesid, "WimaxYesId", "", driver);
            //getWimaxLteYesId().sendKeys(lteyesid);
            clickByXpath(getSearchButton(), "Search", driver);
            //getSearchButton().click();
            clickByXpath(getLastActionDate(), "LastActionDate", driver);
            //getLastActionDate().click();
            clickByXpath(getLastActionDate(), "LastActionDate", driver);
            //getLastActionDate().click();
            doubleClickOnElement(getWimaxLastActionDate_AddOn(), driver);
            checkForText("", getLte_PcrfResponseMessage_AddOn_Hybrid(), "HTTP command executed successfully.",
                    "PCRFResponseMessage", driver);
            checkForText("", getLte_UdcResponseMessage_AddOn_Hybrid(),
                    "All Profiles are disabled. Provisioning is not Required.", "UDCResponseMessage", driver);
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD + " " + "Hybrid_Addon", e);
        }
    }

    /**
     * Hybrid Account Password Change
     *
     * @param lteyesid Pass the LTE Yes ID
     */
    public void Hybrid_Account_Password_Change(String lteyesid) {
        try {
            logger.info("Verifying Hybrid Account Password Change");
            mouseHoveronElement(getHybrid(), driver);
            clickByXpath(getWimaxLteChangePassword(), "Wimax Lte Change Password", driver);
            inputTextByXpath(getWimaxLteYesId(), lteyesid, "WimaxYesId", "", driver);
            // getWimaxLteYesId().sendKeys(lteyesid);
            clickByXpath(getSearchButton(), "Search", driver);
            //getSearchButton().click();
            clickByXpath(getLastActionDate(), "LastActionDate", driver);
            //getLastActionDate().click();
            doubleClickOnElement(getWimaxLastActionDate_AddOn(), driver);
            checkForText("", getLdapResponseMessage_ltePassword(), "Email account password changed successfully.",
                    "LDAPResponseMessage", driver);
            checkForText("", getAaaResponseMessage_ltePassword(), "HTTP command executed successfully.",
                    "AAAResponseMessage", driver);
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD + " " + "Hybrid_Account_Password_Change", e);
        }
    }

    /**
     * LTE Account Password Change
     *
     * @param lteyesid Pass the Yes ID
     */
    public void LTE_Account_Password_Change(String lteyesid) {
        try {
            logger.info("Verifying LTE Account Password Change");
            mouseHoveronElement(getLteDataVoiceService(), driver);
            clickByXpath(getLteDataVoiceChangePassword(), "Lte Data Voice Change Password", driver);
            inputTextByXpath(getWimaxLteYesId(), lteyesid, "WimaxYesId", "", driver);
            // getWimaxLteYesId().sendKeys(lteyesid);
            clickByXpath(getSearchButton(), "Search", driver);
            //getSearchButton().click();
            clickByXpath(getLastActionDate(), "LastActionDate", driver);
            //getLastActionDate().click();
            clickByXpath(getLastActionDate(), "LastActionDate", driver);
            // getLastActionDate().click();
            doubleClickOnElement(getWimaxLastActionDate_AddOn(), driver);
            checkForText("", getLdapResponseMessage(), "Email account password changed successfully.",
                    "LDAPResponseMessage", driver);
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD + " " + "LTE_Account_Password_Change", e);
        }
    }

    /**
     * Verifying Wimax data
     *
     * @param wimaxYesId Pass the WIMAX Yes ID
     * @param date       Pass the date (from)
     */
    public void wimaxData(String wimaxYesId, String date) {
        try {
            logger.info("Verifying Wimax data");
            mouseHoveronElement(getWimaxDataService(), driver);
            clickByXpath(getWimaxDataSubscription(), "Data subscription", driver);
            inputTextByXpath(getWimaxLteYesId(), wimaxYesId, "WimaxYesId", "", driver);
            //getWimaxLteYesId().sendKeys(wimaxYesId);
            getDateBox().clear();
            inputTextByXpath(getDateBox(), date, "Date", "", driver);
            //getDateBox().sendKeys(date);
            clickByXpath(getSearchButton(), "Search", driver);
            //getSearchButton().click();
            doubleClickOnElement(getListCell(), driver);
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", getWimaxDataService_SugarCRM());
            checkForText("", getWimaxDataService_SugarCRM(), "Provisioning Bypassed", "SugarCRMResponseMessage", driver);
            checkForText("", getLdapResponseMessage(), "	Email added successfully.", "LDAPResponseMessage", driver);
            checkForText("", getLte_AaaResponseMessage_HybridPassword(), "HTTP command executed successfully.", "AAAesponseMessage", driver);
            checkForText("", getLte_PcrfResponseMessage_AddOn_Hybrid(), "HTTP command executed successfully.", "PCRFResponseMessage", driver);
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD + " " + "wimaxData", e);
        }
    }

    public void LTEDataAndVoice(String wimaxYesId, String date) {
        try {
            mouseHoveronElement(getLTEDataAndVoiceService(), driver);
            clickByXpath(getLTEDataVoiceSubscription(), "LTE Voice and data subscription", driver);
            inputTextByXpath(getWimaxLteYesId(), wimaxYesId, "WimaxYesId", "", driver);
            //getWimaxLteYesId().sendKeys(wimaxYesId);
            getDateBox().clear();
            inputTextByXpath(getDateBox(), date, "Date", "", driver);
            //getDateBox().sendKeys(date);
            clickByXpath(getSearchButton(), "Search", driver);
            //getSearchButton().click();
            doubleClickOnElement(getListCell(), driver);
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", getSugarCrmResponse_nab());
            checkForText("", getSugarCrmResponse_nab(), "NAB Provisioning Not Required", "NABResponseMessage", driver);
            checkForText("", getLdapResponseMessage_sugarCrm(), "HTTP command executed successfully.", "SugarCRMResponseMessage", driver);
            checkForText("", getUdcResponseMessage_pcrf(), "HTTP command executed successfully.", "PCRFResponseMessage", driver);
            checkForText("", getOtaResponseMessage_ldap(), "Email added successfully.", "LDAPResponseMessage", driver);
            checkForText("", getOxmailResponseMessage_aaa(), "HTTP command executed successfully.", "AAAResponseMessage", driver);
            checkForText("", getUmsResponseMessage_fsr(), "HTTP command executed successfully.", "FSResponseMessage", driver);
            checkForText("", getPcrfResponseMessage_im(), "HTTP command executed successfully.", "IMResponseMessage", driver);
            //checkForText("", getWimax_UdcResponseMessage(), "HTTP command executed successfully.", "UDCResponseMessage", driver);
            //checkForText("", getWimax_UmsResponseMessage(), "UMS Provisioning Not Required", "UMSResponseMessage", driver);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void LTESimReplacment(String yesId, String date) {
        try {
            mouseHoveronElement(getLTEDataAndVoiceService(), driver);
            clickByXpath(getLTEDataVoiceChangeMSISDN(), "LTE Voice and data Change MSISDN", driver);
            inputTextByXpath(getWimaxLteYesId(), yesId, "WimaxYesId", "", driver);
            getDateBox().clear();
            inputTextByXpath(getDateBox(), date, "Date", "", driver);
            clickByXpath(getSearchButton(), "Search", driver);
            doubleClickOnElement(getListCell(), driver);
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", getsim_replacement_sugarCRM());
            checkForText("", getsim_replacement_sugarCRM(), "HTTP command executed successfully.", "SugarCRMResponseMessage", driver);
            checkForText("", getsim_replacement_pcrf(), "HTTP command executed successfully.", "PCRFResponseMessage", driver);
            //	checkForText("", getsim_replacement_ota(),"HTTP command executed successfully.", "OTAResponseMessage", driver);
            checkForText("", getsim_replacement_udc(), "HTTP command executed successfully.", "UDCResponseMessage", driver);
            //	checkForText("", getsim_replacement_ums(), "HTTP command executed successfully.", "UMSResponseMessage", driver);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void LTE_Partial_Suspend(String yesID) {
        try {
            mouseHoveronElement(getLTEDataAndVoiceService(), driver);
            clickByXpath(getLTEPartialSuspend(), "LTE Partial Suspend", driver);
            inputTextByXpath(getWimaxLteYesId(), yesID, "WimaxYesId", "", driver);
            //getWimaxLteYesId().sendKeys(wimaxYesId);
		/*	getDateBox().clear();
			inputTextByXpath(getDateBox(), date, "Date", driver);*/
            //getDateBox().sendKeys(date);
            clickByXpath(getSearchButton(), "Search", driver);
            //getSearchButton().click();
            doubleClickOnElement(getListCell(), driver);
            //	((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", getSugarCrmResponse_nab());
            checkForText("", getPlan_Conversion_SugarCrmResponseMessage(), "Provisioning Bypassed", "SugarCRMResponseMessage", driver);
            checkForText("", getUDCResponseMessage(), "HTTP command executed successfully.", "UDCResponseMessage", driver);
            checkForText("", getPlan_Convesion_PcrfResponseMessage(), "WiMax PCRF Provisioning Successful. LTE: PCRF Provisioning Not Required", "PCRFResponseMessage", driver);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void LTE_Full_Suspend(String yesID) {
        try {
            mouseHoveronElement(gethybrid2(), driver);
            clickByXpath(getLTEFullSuspend(), "LTE Full Suspend", driver);
            inputTextByXpath(getWimaxLteYesId(), yesID, "WimaxYesId", "", driver);
            //getWimaxLteYesId().sendKeys(wimaxYesId);
		/*	getDateBox().clear();
			inputTextByXpath(getDateBox(), date, "Date", driver);*/
            //getDateBox().sendKeys(date);
            clickByXpath(getSearchButton(), "Search", driver);
            //getSearchButton().click();
            doubleClickOnElement(getListCell(), driver);
            //	((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", getSugarCrmResponse_nab());
            checkForText("", getDelCust_FullSuspnd_SugarCrmResMsg(), "Provisioning Bypassed", "SugarCRMResponseMessage", driver);
            checkForText("", getUDCResponseMessage(), "HTTP command executed successfully.", "UDCResponseMessage", driver);
            checkForText("", getPlan_Convesion_AAAResponseMessage(), "HTTP command executed successfully.", "AAAResponseMessage", driver);
            checkForText("", getPlan_Convesion_PcrfResponseMessage(), "HTTP command executed successfully.", "PCRFResponseMessage", driver);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void LTE_Full_DeactivateResume(String yesID) {
        try {
            mouseHoveronElement(gethybrid2(), driver);
            clickByXpath(getLTEFullResume(), "LTE Full Resume", driver);
            inputTextByXpath(getWimaxLteYesId(), yesID, "WimaxYesId", "", driver);
            clickByXpath(getSearchButton(), "Search", driver);
            doubleClickOnElement(getListCell(), driver);
            checkForText("", getPlan_Conversion_SugarCrmResponseMessage(), "Provisioning Bypassed", "SugarCRMResponseMessage", driver);
            checkForText("", getUDCResponseMessage(), "HTTP command executed successfully.", "UDCResponseMessage", driver);
            checkForText("", getPlan_Convesion_AAAResponseMessage(), "AAA Provisioning Not Required", "AAAResponseMessage", driver);
            checkForText("", getPlan_Convesion_PcrfResponseMessage(), "WiMax PCRF Provisioning Successful. LTE: PCRF Provisioning Not Required", "PCRFResponseMessage", driver);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void LTE_Full_SuspendResume(String yesID) {
        try {
            mouseHoveronElement(gethybrid2(), driver);
            clickByXpath(getLTEFullResume(), "LTE Full Resume", driver);
            inputTextByXpath(getWimaxLteYesId(), yesID, "WimaxYesId", "", driver);
            clickByXpath(getSearchButton(), "Search", driver);
            doubleClickOnElement(getListCell(), driver);
            checkForText("", getPlan_Conversion_SugarCrmResponseMessage(), "Provisioning Bypassed", "SugarCRMResponseMessage", driver);
            checkForText("", getUDCResponseMessage(), "HTTP command executed successfully.", "UDCResponseMessage", driver);
            checkForText("", getPlan_Convesion_AAAResponseMessage(), "HTTP command executed successfully.", "AAAResponseMessage", driver);
            checkForText("", getPlan_Convesion_PcrfResponseMessage(), "HTTP command executed successfully.", "PCRFResponseMessage", driver);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void LTE_Delete_Customer(String yesID) {
        try {
            mouseHoveronElement(getLTEDataAndVoiceService(), driver);
            clickByXpath(getLTEDeleteCustomer(), "LTE Partial Suspend", driver);
            inputTextByXpath(getWimaxLteYesId(), yesID, "WimaxYesId", "", driver);
            clickByXpath(getSearchButton(), "Search", driver);
            doubleClickOnElement(getListCell(), driver);
            checkForText("", getDelCust_FullSuspnd_SugarCrmResMsg(), "Provisioning Bypassed", "SugarCRMResponseMessage", driver);
            checkForText("", getDelCust_FullSuspnd_LDAPResMsg(), "Email deleted successfully.", "LDAPResponseMessage", driver);
            checkForText("", getDelCust_FullSuspnd_UDCPResMsg(), "HTTP command executed successfully.", "UDCResponseMessage", driver);
            checkForText("", getDelCust_FullSuspnd_UMSResMsg(), "UMS Provisioning Not Required", "UMSResponseMessage", driver);
            checkForText("", getDelCust_FullSuspnd_PcrfResMsg(), "WiMax PCRF Provisioning Successful.LTE PCRF Provisioning Successful", "PCRFResponseMessage", driver);
            checkForText("", getDelCust_FullSuspnd_AAAResMsg(), "HTTP command executed successfully.", "AAAResponseMessage", driver);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Logout WOM
     */
    public void logout() {
        try {
            logger.info("Verifying Wimax data");
            getLogout().click();
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD + " " + "wimaxData", e);
        }
    }
}
