package com.ytlctest.corebase.e2evalidation;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class WriteIntoCSV {
    static String Status = "PASS";
    static String outputFile;
    private static Logger logger = LogManager.getLogger(WriteIntoCSV.class);

    public static String createIMSIOCSV(String imsi0, String imsi1) {
        FileWriter writer = null;
        if (System.getProperty("location").equalsIgnoreCase("local")) {
            outputFile = System.getProperty("user.dir") + "//src//test//resources//imsi0.csv";
        } else {
            outputFile = "C:/upload/imsi0.csv";

        }
        boolean alreadyExists = new File(outputFile).exists();
        try {
            // use FileWriter constructor that specifies open for appending
            File file = new File(outputFile);
            file.getParentFile().mkdirs();
            if (!file.exists()) {
                file.createNewFile();
            }
            writer = new FileWriter(outputFile);
            // if the file didn't already exist then we need to write out the header line
            if (!alreadyExists) {
                writer.flush();
            }
            // else assume that the file already has the correct header line
            writer.write("Sr.No.");
            writer.write(",");
            writer.write("IMSI1");
            writer.write(",");
            writer.write("IMSI0");
            writer.write("\n");
            // write out a few records
            writer.write("1");
            writer.write(",");
            writer.write(imsi0);
            writer.write(",");
            writer.write(imsi1);
            writer.write("\n");
            writer.close();
            //csvOutput.close();
        } catch (IOException e) {
            logger.error("Error in method createIMSIOCSV", e);
            Status = "FAIL";
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    logger.error("Error in closing writer", e);
                }
            }
        }
        return Status;

    }

    public static String createIMSI1CSV(String imsi0, String simNo) {
        FileWriter writer = null;
        if (System.getProperty("location").equalsIgnoreCase("local")) {
            outputFile = System.getProperty("user.dir") + "//src//test//resources//imsi1.csv";
        } else {
            outputFile = "C:/upload/imsi1.csv";

        }
        boolean alreadyExists = new File(outputFile).exists();
        try {
            File file = new File(outputFile);
            file.getParentFile().mkdirs();
            if (!file.exists()) {
                file.createNewFile();
            }
            // use FileWriter constructor that specifies open for appending
            writer = new FileWriter(outputFile);
            // if the file didn't already exist then we need to write out the header line
            if (!alreadyExists) {
                writer.flush();

            }
            // else assume that the file already has the correct header line
            writer.write("Sr.No.");
            writer.write(",");
            writer.write("IMSI0");
            writer.write(",");
            writer.write("LTE Logical ICCID");
            writer.write("\n");
            // write out a few records
            writer.write("1");
            writer.write(",");
            writer.write(imsi0);
            writer.write(",");
            writer.write(simNo);
            writer.write("\n");
            writer.close();

        } catch (IOException e) {
            logger.error("Error in closing createIMSI1CSV", e);
            Status = "FAIL";
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    logger.error("Error in closing writer", e);
                }
            }
        }
        return Status;

    }
}
