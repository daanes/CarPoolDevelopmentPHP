package com.ytlctest.corebase.e2evalidation;

import com.aventstack.extentreports.ExtentTest;
import com.ytlctest.corebase.lib.firebase4j.demo.Demo;
import com.ytlctest.corebase.lib.firebase4j.error.FirebaseException;
import com.ytlctest.corebase.lib.firebase4j.error.JacksonUtilityException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;

import java.io.IOException;

import static com.ytlctest.corebase.listener.ExtentTestNGITestListener.getTest;

public class OTP {
    static ExtentTest test1 = getTest().get().createNode("readMessage");
    private static Logger logger = LogManager.getLogger(OTP.class);

    /**
     * Get one time password OTP for PDC environment
     *
     * @param driver Not used, but pass the driver instance
     * @return otp returns the One Time Password
     */
    public static String runOTP(WebDriver driver) {
        try {
            Thread.sleep(20000);
        } catch (InterruptedException e) {
            logger.error("Error in getting OTP", e);
            Thread.currentThread().interrupt();
        }
        String otp = null;
        Demo demo = new Demo();
        try {
            otp = demo.getOTP();
            logger.info("The OTP is: " + otp);
        } catch (IOException | FirebaseException | JacksonUtilityException e) {
            logger.error("Error in getting OTP", e);
        }
        return otp;
    }

}