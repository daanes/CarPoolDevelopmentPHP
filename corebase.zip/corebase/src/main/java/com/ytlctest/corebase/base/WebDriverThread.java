package com.ytlctest.corebase.base;

import com.google.common.collect.ImmutableMap;
import com.ytlctest.corebase.lib.MainUtil;
import com.ytlctest.corebase.lib.PropertyHelper;
import com.ytlctest.corebase.lib.openstf.DeviceApi;
import com.ytlctest.corebase.lib.openstf.STFService;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.IOSMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;
import net.lightbody.bmp.BrowserMobProxy;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.client.ClientUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Paths;
import java.sql.Connection;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class WebDriverThread {

    private static final String CHROME_DRIVER_STR = "webdriver.chrome.driver";
    private static final String STF_SERVICE_URL = "http://14.1.213.101:7100";
    private static final String ACCESS_TOKEN = "77ae6869a6b146ba9aefcf0ed3394b18e453042cf75c49558a8108c64061271c";
    private static Connection dbconnection;
    private static String workspace = System.getProperty("user.dir");
    private static Logger logger = LogManager.getLogger(WebDriverThread.class);

    static {
        java.util.logging.Logger.getLogger("org.apache.http.wire").setLevel(java.util.logging.Level.FINEST);
        java.util.logging.Logger.getLogger("org.apache.http.headers").setLevel(java.util.logging.Level.FINEST);
        System.setProperty("org.apache.commons.logging.Log", "org.apache.commons.logging.impl.SimpleLog");
        System.setProperty("org.apache.commons.logging.simplelog.showdatetime", "true");
        System.setProperty("org.apache.commons.logging.simplelog.log.httpclient.wire", "ERROR");
        System.setProperty("org.apache.commons.logging.simplelog.log.org.apache.http", "ERROR");
        System.setProperty("org.apache.commons.logging.simplelog.log.org.apache.http.headers", "ERROR");
    }

    private BrowserMobProxy proxy;
    private RemoteWebDriver driver;
    private List<String> androidSessionIds = new LinkedList<>();
    private String deviceSerial;
    private DeviceApi deviceApi;

    /**
     * Driver instantiation module for WEB
     *
     * @param browserName Name of the driver ex: CHROME1,CHROME2,FIREFOX1
     * @return Return the initiated driver
     */
    RemoteWebDriver getDriver(String browserName, String designatedVM) {
        logger.info(System.getProperty("os.name"));
        try {
            if (DriverFactory.getDriverPool().get(browserName) == null) {
                if (System.getProperty("location").equalsIgnoreCase("local")) {
                    if ("firefox".equals(System.getProperty("browser"))) {
                        FirefoxOptions firefoxOptions = new FirefoxOptions().setProfile(new FirefoxProfile());
                        firefoxOptions.setAcceptInsecureCerts(true);
                        if (System.getProperty("pmas").equalsIgnoreCase("true"))
                            firefoxOptions.setProxy(startProxy());
                        System.setProperty("webdriver.gecko.driver",
                                Paths.get(workspace, "src", "main", "resources", "geckodriver").toString());
                        driver = new FirefoxDriver(firefoxOptions);
                        driver.manage().deleteAllCookies();
                        driver.manage().window().maximize();
                    } else if ("chrome".equals(System.getProperty("browser"))) {
                        System.setProperty(CHROME_DRIVER_STR, Paths.get(workspace, "src", "main", "resources", "chromedriver.exe").toString());
                        ChromeOptions chromeOptions = new ChromeOptions();
                        if ("headless".equals(System.getProperty("state")))
                            chromeOptions.addArguments("headless");
                        chromeOptions.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.ACCEPT);
                        chromeOptions.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
                        chromeOptions.setAcceptInsecureCerts(true);
                        chromeOptions.addArguments("ignore-certificate-errors");
                        chromeOptions.addArguments("disable-popup-blocking");
                        chromeOptions.addArguments("start-maximized");
                        if (designatedVM != null || !designatedVM.equalsIgnoreCase(""))
                            chromeOptions.setCapability("deviceName", designatedVM);
                        if (System.getProperty("pmas").equalsIgnoreCase("true"))
                            chromeOptions.setProxy(startProxy());
                        driver = new RemoteWebDriver(new URL("http://127.0.0.1:4651/wd/hub"), chromeOptions);
                        driver.manage().deleteAllCookies();
                    } else if ("ie".equals(System.getProperty("browser"))) {
                        InternetExplorerOptions internetexploreroptions = new InternetExplorerOptions();
                        internetexploreroptions.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
                        internetexploreroptions.setCapability("ignoreProtectedModeSettings", true);
                        internetexploreroptions.setCapability(CapabilityType.PLATFORM_NAME, "WINDOWS");
                        internetexploreroptions.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.ACCEPT);
                        internetexploreroptions.setCapability(CapabilityType.UNHANDLED_PROMPT_BEHAVIOUR, UnexpectedAlertBehaviour.ACCEPT);
                        internetexploreroptions.setCapability(CapabilityType.SUPPORTS_JAVASCRIPT, true);
                        driver = new RemoteWebDriver(new URL("http://127.0.0.1:4651/wd/hub"), internetexploreroptions);
                        driver.manage().deleteAllCookies();
                    }
                } else {
                    if ("firefox".equals(System.getProperty("browser"))) {
                        FirefoxOptions firefoxOptions = new FirefoxOptions().setProfile(new FirefoxProfile());
                        firefoxOptions.setAcceptInsecureCerts(true);
                        if (System.getProperty("pmas").equalsIgnoreCase("true"))
                            firefoxOptions.setProxy(startProxy());
                        System.setProperty("webdriver.gecko.driver",
                                Paths.get(workspace, "src", "main", "resources", "geckodriver.exe").toString());
                        driver = new RemoteWebDriver(new URL(PropertyHelper.getProperties("REMOTE_HUB_URL")),
                                firefoxOptions);
                        driver.manage().window().maximize();
                    } else if ("chrome".equals(System.getProperty("browser"))) {
                        System.setProperty(CHROME_DRIVER_STR,
                                Paths.get(workspace, "src", "main", "resources", "chromedriver.exe").toString());
                        ChromeOptions chromeOptions = new ChromeOptions();
                        if ("headless".equals(System.getProperty("state")))
                            chromeOptions.addArguments("headless");
                        chromeOptions.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.ACCEPT);
                        chromeOptions.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
                        chromeOptions.addArguments("ignore-certificate-errors");
                        chromeOptions.addArguments("disable-popup-blocking");
                        chromeOptions.addArguments("start-maximized");
                        if (designatedVM != null || !designatedVM.equalsIgnoreCase(""))
                            chromeOptions.setCapability("deviceName", designatedVM);
                        if (System.getProperty("pmas").equalsIgnoreCase("true"))
                            chromeOptions.setProxy(startProxy());
                        if (System.getProperty("dataId").toLowerCase().contains("_apco")) {
                            driver = new ChromeDriver(chromeOptions);
                        } else {
                            MainUtil.HubUrl = PropertyHelper.getHubUrl();
                            if (MainUtil.HubUrl.equalsIgnoreCase("") || MainUtil.HubUrl == null) {
                                logger.error("Please makesure the node is up and avaialble in DB.");
                            } else {
                                driver = new RemoteWebDriver(new URL(MainUtil.HubUrl), chromeOptions);
                                //PropertyHelper.updateHubUrlStatus(MainUtil.storeVariable.get("HUB_URL_ID"), "1");
                                logger.info("The Execution started in this " + MainUtil.HubUrl + "Machine.");
                            }
                        }
                    } else if ("ie".equals(System.getProperty("browser"))) {
                        InternetExplorerOptions internetexploreroptions = new InternetExplorerOptions();
                        internetexploreroptions.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
                        internetexploreroptions.setCapability("ignoreProtectedModeSettings", true);
                        internetexploreroptions.setCapability(CapabilityType.PLATFORM_NAME, "WINDOWS");
                        internetexploreroptions.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.ACCEPT);
                        internetexploreroptions.setCapability(CapabilityType.UNHANDLED_PROMPT_BEHAVIOUR, UnexpectedAlertBehaviour.ACCEPT);
                        internetexploreroptions.setCapability(CapabilityType.SUPPORTS_JAVASCRIPT, true);
                        internetexploreroptions.setCapability(InternetExplorerDriver.NATIVE_EVENTS, false);
                        if (System.getProperty("pmas").equalsIgnoreCase("true"))
                            internetexploreroptions.setProxy(startProxy());
                        MainUtil.HubUrl = PropertyHelper.getHubUrl();
                        if (MainUtil.HubUrl.equalsIgnoreCase("") || MainUtil.HubUrl == null) {
                            logger.error("Please makesure the node is up and avaialble in DB.");
                        } else {
                            driver = new RemoteWebDriver(new URL(MainUtil.HubUrl), internetexploreroptions);
                            logger.info("The Execution started in this " + MainUtil.HubUrl + "Machine.");
                        }
                    }
                }
                DriverFactory.getDriverPool().put(browserName, driver);
                driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
                driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
            }
        } catch (Exception e) {
            logger.error("Error creating the driver", e);
        }
        return driver;
    }

    /**
     * Driver instantiation module for mobile (Android)
     *
     * @param appName     Provide the mobile app name
     * @param appPackage  Provide the mobile app package name
     * @param appActivity Provide the app activity name
     * @param deviceName  Provide the node name where it is has to be run
     * @return Return the initiated driver
     */
    RemoteWebDriver getDriver(String appName, String appPackage, String appActivity, String deviceName) {
        DesiredCapabilities androidDcap = new DesiredCapabilities();
        androidDcap.setCapability(MobileCapabilityType.AUTOMATION_NAME, "UIAutomator2");
        androidDcap.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
        androidDcap.setCapability(AndroidMobileCapabilityType.AUTO_GRANT_PERMISSIONS, true);
        androidDcap.setCapability(MobileCapabilityType.NO_RESET, true);
        androidDcap.setCapability(MobileCapabilityType.FULL_RESET, false);
        androidDcap.setCapability(AndroidMobileCapabilityType.NO_SIGN, true);
        androidDcap.setCapability(AndroidMobileCapabilityType.APP_WAIT_DURATION, 120);
        androidDcap.setCapability("deviceName", deviceName);
        androidDcap.setCapability("browserName", "");
        androidDcap.setCapability("newCommandTimeout", 1500);
        androidDcap.setCapability("appPackage", appPackage);
        androidDcap.setCapability("appActivity", appActivity);
        try {
            if (System.getProperty("location").equalsIgnoreCase("local")) {
                driver = new AndroidDriver<>(new URL("http://127.0.0.1:4651/wd/hub"), androidDcap);
                logger.info("Session ID of Android: " + driver.getSessionId());
            } else if (System.getProperty("location").equalsIgnoreCase("remote")) {
                driver = new AndroidDriver<>(new URL(PropertyHelper.getProperties("REMOTE_HUB_URL")), androidDcap);
                logger.info("Session ID of Android: " + driver.getSessionId());
            } else if (System.getProperty("location").equalsIgnoreCase("stf")) {
                try {
                    this.deviceSerial = deviceName;
                    connectToStfDevice(deviceName);
                } catch (IllegalArgumentException ie) {
                    logger.error("************STF service is unreachable**************");
                }
                driver = new AndroidDriver<>(new URL("http://127.0.0.1:4651/wd/hub"), androidDcap);
                logger.info("Session ID of Android: " + driver.getSessionId());
            }
        } catch (WebDriverException e) {
            logger.error("Driver instantiating failed or app is not installed", e);
        } catch (MalformedURLException e) {
            logger.error(e);
        }
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        DriverFactory.getDriverPool().put(appName, driver);
        return driver;
    }

    /**
     * Driver instantiation module for mobile (Android)
     *
     * @param appName     Provide the mobile app name
     * @param appPackage  Provide the mobile app package name
     * @param appActivity Provide the app activity name
     * @param deviceName  Provide the node name where it is has to be run
     * @param fileName    Provide the device serial number
     * @return Return the initiated driver
     */
    RemoteWebDriver getDriver(String appName, String appPackage, String appActivity, String deviceName, String fileName) {
        DesiredCapabilities androidDcap = new DesiredCapabilities();
        androidDcap.setCapability(MobileCapabilityType.AUTOMATION_NAME, "UIAutomator2");
        androidDcap.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
        androidDcap.setCapability(AndroidMobileCapabilityType.AUTO_GRANT_PERMISSIONS, true);
        androidDcap.setCapability(MobileCapabilityType.NO_RESET, true);
        androidDcap.setCapability(MobileCapabilityType.FULL_RESET, false);
        androidDcap.setCapability(AndroidMobileCapabilityType.NO_SIGN, true);
        androidDcap.setCapability(AndroidMobileCapabilityType.APP_WAIT_DURATION, 1500);
        androidDcap.setCapability("deviceName", deviceName);
        androidDcap.setCapability("browserName", "");
        androidDcap.setCapability("newCommandTimeout", 1500);
        androidDcap.setCapability("appPackage", appPackage);
        androidDcap.setCapability("appActivity", appActivity);
        androidDcap.setCapability("autoAcceptAlerts", true);
        androidDcap.setCapability("autoDismissAlerts", true);
        androidDcap.setCapability("app", System.getProperty("user.dir") + "/src/main/resources" + fileName);
        try {
            if (System.getProperty("location").equalsIgnoreCase("local")) {
                driver = new AndroidDriver<>(new URL("http://127.0.0.1:4651/wd/hub"), androidDcap);
                logger.info("Session ID of Android: " + driver.getSessionId());
            } else if (System.getProperty("location").equalsIgnoreCase("remote")) {
                driver = new AndroidDriver<>(new URL(PropertyHelper.getProperties("REMOTE_HUB_URL")), androidDcap);
                logger.info("Session ID of Android: " + driver.getSessionId());
            } else if (System.getProperty("location").equalsIgnoreCase("stf")) {
                try {
                    this.deviceSerial = deviceName;
                    connectToStfDevice(deviceName);
                } catch (IllegalArgumentException ie) {
                    logger.error("************STF service is unreachable**************");
                }
                driver = new AndroidDriver<>(new URL("http://127.0.0.1:4651/wd/hub"), androidDcap);
                logger.info("Session ID of Android: " + driver.getSessionId());
            }
        } catch (WebDriverException e) {
            logger.error("Driver instantiating failed or app is not installed", e);
        } catch (MalformedURLException e) {
            logger.error(e);
        }
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        DriverFactory.getDriverPool().put(appName, driver);
        return driver;
    }


    /**
     * Driver instantiation module for mobile (iOS)
     *
     * @param appName    Provide the mobile app name
     * @param uuid       Provide the uuid
     * @param bundleId   Provide the bundle ID of the app
     * @param xcodeOrgId Provide the xcode org ID
     * @param timeout
     * @return returns an object iOS driver
     */
    RemoteWebDriver getDriver(String appName, String uuid, String bundleId, String xcodeOrgId, int timeout) {
        DesiredCapabilities ioscap = new DesiredCapabilities();
        ioscap.setCapability(IOSMobileCapabilityType.WDA_LOCAL_PORT, 8100);
        ioscap.setCapability(IOSMobileCapabilityType.BUNDLE_ID, bundleId);
        ioscap.setCapability(IOSMobileCapabilityType.XCODE_ORG_ID, xcodeOrgId);
        ioscap.setCapability(IOSMobileCapabilityType.XCODE_SIGNING_ID, "iPhone Developer");
        ioscap.setCapability("automationName", "XCUITest");
        ioscap.setCapability("platformName", "iOS");
        ioscap.setAcceptInsecureCerts(true);
        ioscap.acceptInsecureCerts();
        ioscap.setCapability(IOSMobileCapabilityType.LAUNCH_TIMEOUT, 60000);
        ioscap.setCapability(IOSMobileCapabilityType.COMMAND_TIMEOUTS, 60000);
        ioscap.setCapability(IOSMobileCapabilityType.WDA_LAUNCH_TIMEOUT, 1200000);
        ioscap.setCapability(IOSMobileCapabilityType.WDA_CONNECTION_TIMEOUT, 1200000);
        try {
            if (System.getProperty("location").equalsIgnoreCase("local")) {
                driver = new IOSDriver<>(new URL("http://127.0.0.1:4651/wd/hub"), ioscap);
            } else {
                driver = new IOSDriver<>(new URL(PropertyHelper.getProperties("REMOTE_HUB_URL")), ioscap);
            }
        } catch (Exception e) {
            logger.error("IOSDriver Driver instantiating failed", e);
        }
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        DriverFactory.getDriverPool().put(appName, driver);
        return driver;
    }

    private void connectToStfDevice(String deviceSerial) {
        try {
            STFService stfService = new STFService(STF_SERVICE_URL, ACCESS_TOKEN);
            this.deviceApi = new DeviceApi(stfService);
            this.deviceApi.connectDevice(deviceSerial);
        } catch (URISyntaxException ue) {
            logger.info(ue);
        } catch (MalformedURLException me) {
            logger.error(me);
        }
    }

    BrowserMobProxy getProxy() {
        return this.proxy;
    }

    private Proxy startProxy() {
        logger.info("Proxy configuration");
        logger.info("Starting the proxy");
        proxy = new BrowserMobProxyServer();
        proxy.setTrustAllServers(true);
        proxy.start(4444);
        logger.info("get the Selenium proxy object - org.openqa.selenium.Proxy");
        Proxy seleniumProxy = ClientUtil.createSeleniumProxy(proxy);
        return seleniumProxy;
    }

    /**
     * Quit driver
     */
    void quitDriver() {

        /*This lines of code is throwing null pointer exception for webdriver which prakash has implementedfor myyes4g execution*/
    	
       /* try {
            if (this.service.isRunning()) {
                service.stop();
                this.deviceApi.releaseDevice(this.deviceSerial);
            }
        try {
            this.deviceApi.releaseDevice(this.deviceSerial);
        } catch (Exception e) {
            logger.error("Error changing the status of the device", e);
        }*/
        try {
            logger.info("quitDriver");
            if (!DriverFactory.getDriverPool().entrySet().isEmpty()) {
                for (Map.Entry<String, RemoteWebDriver> driverInstance : DriverFactory.getDriverPool().entrySet()) {
                    if (driverInstance.getValue() != null || !driverInstance.getValue().equals("")) {
                        if ((driverInstance.getValue() instanceof AndroidDriver) || (driverInstance.getValue() instanceof IOSDriver))
                            try {
                                driverInstance.getValue().quit();
                            } catch (WebDriverException wb) {
                                logger.info("Session is already terminated");
                            }
                        else if (driverInstance.getValue() instanceof RemoteWebDriver) {
                            try {
                                driverInstance.getValue().quit();
                            } catch (WebDriverException wb) {
                                logger.info("Session is already terminated");
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            logger.error("Exception in closing the driver \n", e);
        }
    }


    /**
     * Browser instantiation module for android mobile web browser
     *
     * @param appName         Provide the appname
     * @param browsername     Provide the browser name (Chrome, Firefox)
     * @param platformversion Provide the android platform version
     * @return remotewebdriver
     */
    public RemoteWebDriver getDriver(String appName, String browsername, String platformversion) {
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability("platformName", "Android");
        capabilities.setCapability("deviceName", "lenovotab");
        capabilities.setCapability("automationName", "UIAutomator2");
        capabilities.setCapability("platformVersion", platformversion);
        capabilities.setCapability("browserName", browsername);
        capabilities.setCapability("newCommandTimeout", 60);
        capabilities.setCapability("appium:chromeOptions", ImmutableMap.of("w3c", true));
        try {
            if (System.getProperty("location").equalsIgnoreCase("local")) {
                driver = new AndroidDriver<>(new URL("http://127.0.0.1:4651/wd/hub"), capabilities);
                logger.info("Session ID of Android: " + driver.getSessionId());
            } else if (System.getProperty("location").equalsIgnoreCase("remote")) {
                driver = new AndroidDriver<>(new URL(PropertyHelper.getProperties("REMOTE_HUB_URL")), capabilities);
                logger.info("Session ID of Android: " + driver.getSessionId());
            }
        } catch (WebDriverException e) {
            logger.error("Driver instantiating failed or app is not installed", e);
        } catch (MalformedURLException e) {
            logger.error(e);
        }
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        DriverFactory.getDriverPool().put(appName, driver);
        return driver;
    }

    /*public RemoteWebDriver getMultiBrowserDriver(String browser) {
        String appName = null;
        if ("firefox".equals(System.getProperty("browser"))) {
            appName = "firefox";
            FirefoxOptions firefoxOptions = new FirefoxOptions().setProfile(new FirefoxProfile());
            firefoxOptions.setAcceptInsecureCerts(true);
            try {
                driver = new RemoteWebDriver(new URL(PropertyHelper.getProperties("REMOTE_HUB_URL")), firefoxOptions);
            } catch (Exception ex) {
                logger.error("Error instantiating the FIREFOX driver\n", ex);
            }
        } else if ("chrome".equals(System.getProperty("browser"))) {
            appName = "chrome";
            ChromeOptions chromeOptions = new ChromeOptions();
            if ("headless".equals(System.getProperty("state")))
                chromeOptions.addArguments("headless");
            chromeOptions.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.ACCEPT);
            chromeOptions.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
            chromeOptions.addArguments("ignore-certificate-errors");
            chromeOptions.addArguments("disable-popup-blocking");
            chromeOptions.addArguments("start-maximized");
            try {
                MainUtil.HubUrl = PropertyHelper.getHubUrl();
                if (MainUtil.HubUrl.equalsIgnoreCase("") || MainUtil.HubUrl == null) {
                    logger.error("Please make sure the node is up and available in DB.");
                } else {
                    driver = new RemoteWebDriver(new URL(MainUtil.HubUrl), chromeOptions);
                    logger.info("The Execution started in this " + MainUtil.HubUrl + "Machine.");
                }
            } catch (Exception ex) {
                logger.error("Error instantiating the CHROME browser\n", ex);
            }
        } else if ("ie".equals(System.getProperty("browser"))) {
            appName = "ie";
            InternetExplorerOptions internetexploreroptions = new InternetExplorerOptions();
            internetexploreroptions.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
            internetexploreroptions.setCapability("ignoreProtectedModeSettings", true);
            internetexploreroptions.setCapability(CapabilityType.PLATFORM_NAME, "WINDOWS");
            internetexploreroptions.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.ACCEPT);
            internetexploreroptions.setCapability(CapabilityType.UNHANDLED_PROMPT_BEHAVIOUR, UnexpectedAlertBehaviour.ACCEPT);
            internetexploreroptions.setCapability(CapabilityType.SUPPORTS_JAVASCRIPT, true);
            internetexploreroptions.setCapability(InternetExplorerDriver.NATIVE_EVENTS, false);
            try {
                MainUtil.HubUrl = PropertyHelper.getHubUrl();
                if (MainUtil.HubUrl.equalsIgnoreCase("") || MainUtil.HubUrl == null) {
                    logger.error("Please make sure the node is up and available in DB.");
                } else {
                    driver = new RemoteWebDriver(new URL(MainUtil.HubUrl), internetexploreroptions);
                    logger.info("The Execution started in this " + MainUtil.HubUrl + "Machine.");
                }
            } catch (Exception ex) {
                logger.error("Error instantiating the Internet Explorer browser\n", ex);
            }
        }
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        DriverFactory.getDriverPool().put(appName, driver);
        return driver;
    }*/
}
