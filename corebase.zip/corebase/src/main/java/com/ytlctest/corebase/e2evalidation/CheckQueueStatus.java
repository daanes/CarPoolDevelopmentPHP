package com.ytlctest.corebase.e2evalidation;

import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.ytlctest.corebase.lib.MainUtil;
import com.ytlctest.corebase.listener.ExtentTestNGITestListener;
import com.ytlctest.querywebservices.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map.Entry;

import static com.ytlctest.corebase.listener.ExtentTestNGITestListener.getTest;

public class CheckQueueStatus {

    private static Logger logger = LogManager.getLogger(CheckQueueStatus.class);

    /**
     * This will check queue status in YCMS and YOS DB.
     *
     * @param yesId  Pass the Yes ID
     * @param source Pass the source (For ex: ycms, SELFCARE, XPORTAL)
     * @return status of the queue data table
     * @throws Exception Throws Exception
     */
    public String checkQueueStatus(String yesId, String source) throws Exception {
        String result = "FAIL";
        JSONObject webresult = null;
        try {
            ExtentTestNGITestListener.createNode("Queue Validation");
            CheckQueueYCMS1 queueYCMS1 = new CheckQueueYCMS1();
            CheckQueueYCMS2 queueYCMS2 = new CheckQueueYCMS2();
            CheckQueueYOS1 queueYOS1 = new CheckQueueYOS1();
            CheckQueueYOS2 queueYOS2 = new CheckQueueYOS2();
            logger.info(new StringBuilder("yesId").append(MainUtil.ProjectConst.VALUE.getMsg()).append(yesId));
            String status = null;
            String remarks = "";
            String groupId = "";
            int j = 0;
            int flag = 0;
            String sequence = "";
            ArrayList<String> list = new ArrayList<>();
            ArrayList<String> listapca = new ArrayList<>();
            ArrayList<String> list1 = new ArrayList<>();
            LinkedHashMap<String, String> queueData = new LinkedHashMap<>();
            String processName = null;
            String url = null;
            try {
                if (source.equalsIgnoreCase("ycms") || source.equalsIgnoreCase("YMCA") || source.equalsIgnoreCase("SELFACTIVATION") || source.equalsIgnoreCase("USSP")) {
                    webresult = queueYCMS1.getQueueStatusYCMS1(yesId, source);
                } else if (source.equalsIgnoreCase("YOS") || source.equalsIgnoreCase("SELFCARE") || source.equalsIgnoreCase("XPORTAL") || source.equalsIgnoreCase("MOBILESELFCARE")) {
                    webresult = queueYOS1.getQueueStatusYOS1(yesId, source);
                    logger.info(new StringBuilder("url").append(MainUtil.ProjectConst.VALUE.getMsg()).append(url));
                }
                long thresholdTime = 240000;
                long incrTime = 60000;
                long startTime = 60000;
                long sum = 0;
                Thread.sleep(startTime);
                /* INCLUDE NO.OF PROCESS CHECKS BASED ON TRANSACTION TYPE (ACCOUNT CREATION / BILL PAMENT/ ETC) */
                logger.info(new StringBuilder("yesId").append(MainUtil.ProjectConst.VALUE.getMsg()).append(yesId));
                if (webresult != null && !webresult.get("Result").equals(null)) {
                    JSONArray elements = webresult.getJSONArray("Result");
                    JSONObject object;
                    for (int i = 0; i < elements.length(); i++) {
                        object = elements.getJSONObject(i);
                        queueData.put(object.get("QUEUE_ID").toString(), object.get("PROCESS_NAME").toString());
                        logger.info("{}, {}", object.get("QUEUE_ID").toString(), object.get("PROCESS_NAME").toString());
                    }
                }
                if (queueData.size() >= 1) {
                    for (Entry<String, String> m : queueData.entrySet()) {
                        status = "N";
                        sum = 0;
                        startTime = 60000;
                        while (!(status.equalsIgnoreCase("E") || status.equalsIgnoreCase("Y"))) {
                            JSONObject rs1;
                            if (source.equalsIgnoreCase("ycms") || source.equalsIgnoreCase("YMCA") || source.equalsIgnoreCase("SELFACTIVATION") || source.equalsIgnoreCase("USSP")) {
                                rs1 = queueYCMS2.getQueueStatusYCMS2(m.getKey(), m.getValue());
                            } else {
                                rs1 = queueYOS2.getQueueStatusYOS2(m.getKey(), m.getValue());
                            }
                            if (rs1 != null && !rs1.get("Result").equals(null)) {
                                JSONArray elements = rs1.getJSONArray("Result");
                                JSONObject object = elements.getJSONObject(0);
                                status = object.get("PROCESS_STATUS").toString();
                                remarks = "1.Process Name:" + object.get("PROCESS_NAME").toString() + "\n2.Process Status:" + object.get("PROCESS_STATUS").toString() + "\n3.Remarks:" + object.get("REMARKS").toString() + "\n4.Created Date:" + object.get("CREATED_DATE").toString();
                                processName = object.get("PROCESS_NAME").toString();
                                groupId = object.get("GROUP_ID").toString();
                                sequence = object.get("SEQUENCE").toString();
                                logger.info(new StringBuilder("status").append(MainUtil.ProjectConst.VALUE.getMsg()).append(status));
                                logger.info(new StringBuilder("remarks").append(MainUtil.ProjectConst.VALUE.getMsg()).append(remarks));
                                logger.info(new StringBuilder("processName").append(MainUtil.ProjectConst.VALUE.getMsg()).append(processName));
                                logger.info(new StringBuilder("groupId").append(MainUtil.ProjectConst.VALUE.getMsg()).append(groupId));
                                logger.info(new StringBuilder("CREATED_DATE").append(MainUtil.ProjectConst.VALUE.getMsg()).append(object.get("CREATED_DATE").toString()));

                            } else {
                                logger.info(new StringBuilder("Process Name").append(MainUtil.ProjectConst.VALUE.getMsg()).append(m.getValue()));
                                remarks = "1.Process Name:" + m.getValue() + ":";
                                logger.info(new StringBuilder("processName: ").append(processName).append("> status").append(MainUtil.ProjectConst.VALUE.getMsg()).append(status));
                                logger.info(new StringBuilder("Reason/Remarks").append(MainUtil.ProjectConst.VALUE.getMsg()).append(remarks));
                                result = checkQueueHistoryTable(status, yesId, source);
                                flag = 1;
                                list1.add(status);
                                break;

                            }
                            Thread.sleep(incrTime);
                            sum = sum + startTime;
                            if (sum == thresholdTime) {
                                logger.info("Time out======> {}", sum);
                                break;
                            }
                            logger.info("status======> {}", status);
                        }
                        if (flag == 0) {
                            if (status.equals("E")) {
                                getTest().get().fail(MarkupHelper.createLabel("Error occured in Queue Processing, Process Name:" + processName + "> and status =" + status, ExtentColor.RED));
                                logger.info("{} status {} {}", processName, MainUtil.ProjectConst.VALUE.getMsg(), status);
                                logger.info("Reason/Remarks {} {}", MainUtil.ProjectConst.VALUE.getMsg(), remarks);
                                if (!sequence.equals("6")) {
                                    list.add(status);
                                }
                                break;
                            } else if (status.equals("Y")) {
                                logger.info("{} > status {} {}", processName, MainUtil.ProjectConst.VALUE.getMsg(), status);
                                logger.info("Reason {}", remarks);
                                if (sequence.equals("1") || sequence.equals("2")) {
                                    listapca.add(status);
                                }
                            } else {
                                getTest().get()
                                        .fail(MarkupHelper.createLabel(
                                                "Queue Data are not processed yet. Process Name: " + processName + "> status======>" + status + "," + remarks + " 1.Status with in maximum time limit 2.It will check,whether it is available in QUEUE_DATA_HISTORY table",
                                                ExtentColor.RED));
                                logger.info("{} > status = {}", processName, status);
                                logger.info("Reason {}", remarks);
                                if (sequence.equals("1") || sequence.equals("2")) {
                                    list1.add(status);
                                }
                                break;
                            }
                        } else {
                            j = 1;
                            break;
                        }

                    }
                    /* checking and storing the status and storing the yes id if success */
                    if (!list.isEmpty()) {
                        j = 1;
                    }
                    if (j == 0) {
                        result = "SUCCESS";
                    }
                    logger.info("Result {} {}", MainUtil.ProjectConst.VALUE.getMsg(), result);
                    if (!status.equalsIgnoreCase("E")) {
                        if (!list1.isEmpty()) {
                            logger.info("list1 is empty");

                        } else {
                            logger.info("list1 is not empty");
                            result = checkQueueHistoryTable(status, yesId, source);
                        }
                    }
                } else {
                    status = "Y";
                    logger.info(new StringBuilder("status").append(MainUtil.ProjectConst.VALUE.getMsg()).append(status));
                    logger.info("Reason: Record is not available in QUEUE_DATA in the first attempt itself, Need to check in Queue History Table");
                    getTest().get().pass(MarkupHelper.createLabel("Record is not available in QUEUE_DATA in the first attempt itself, Need to check in Queue History Table", ExtentColor.GREEN));
                    result = checkQueueHistoryTable(status, yesId, source);
                }

            } catch (Exception e) {
                logger.info("Error: ", e);
                getTest().get().fail(MarkupHelper.createLabel("Catch1 Error Occured while verifying QUEUE DATA table: " + e.getMessage(), ExtentColor.RED));

            }
        } catch (Exception e) {
            logger.info("#### Error occured while checking the queue", e);
            getTest().get().fail(MarkupHelper.createLabel("Catch2 Error Occured while verifying QUEUE DATA table: " + e.getMessage(), ExtentColor.RED));
        }
        return result;

    }

    /**
     * This will check queue history table in YCMS and YOS DB.
     *
     * @param status Ignore. Pass empty string
     * @param yesId  Pass Yes ID
     * @param source Pass source (For ex: YCMS, YOS)
     * @return status of the queue history table
     */
    public String checkQueueHistoryTable(String status, String yesId, String source) {
        CheckQueueHistoryYCMS queueYCMS = new CheckQueueHistoryYCMS();
        CheckQueueHistoryYOS queueYOS = new CheckQueueHistoryYOS();
        String result = "FAIL";
        JSONObject webresult = null;
        try {
            logger.info("enter into pdc ycms db--");
            if (source.equalsIgnoreCase("ycms") || source.equalsIgnoreCase("YMCA")
                    || source.equalsIgnoreCase("SELFACTIVATION") || source.equalsIgnoreCase("USSP")) {
                webresult = queueYCMS.getQueueHistoryYCMS(yesId, source);
            } else if (source.equalsIgnoreCase("YOS") || source.equalsIgnoreCase("SELFCARE")
                    || source.equalsIgnoreCase("XPORTAL") || source.equalsIgnoreCase("MOBILESELFCARE")) {
                logger.info("enter into pdc yos db--");
                webresult = queueYOS.getQueueHistoryYOS(yesId, source);
            }
            logger.info(new StringBuilder("yesId").append(MainUtil.ProjectConst.VALUE.getMsg()).append(yesId));
            if (webresult != null && !webresult.get("Result").equals(null)) {
                JSONArray elements = webresult.getJSONArray("Result");
                JSONObject object;
                int i = 0;
                do {
                    object = elements.getJSONObject(i);
                    if (object.get("PROCESS_STATUS").toString().equalsIgnoreCase("Y")) {
                        logger.info("{}, {}, {}", object.get("QUEUE_ID").toString(), object.get("PROCESS_STATUS").toString(), object.get("REMARKS").toString());
                        getTest().get().pass(MarkupHelper.createLabel(
                                "Success : 1.Process Name:" + object.get("PROCESS_NAME").toString()
                                        + "2.Process Status:" + object.get("PROCESS_STATUS").toString()
                                        + "3.Remarks:" + object.get("REMARKS").toString()
                                        + "4.Created Date:" + object.get("CREATED_DATE").toString(),
                                ExtentColor.GREEN));

                    } else {
                        logger.info("{}, {}, {}, {}", object.get("QUEUE_ID").toString(), object.get("PROCESS_NAME").toString(), object.get("PROCESS_STATUS").toString(), object.get("REMARKS").toString());
                        getTest().get().fail(MarkupHelper.createLabel("Failed : 1.Process Name:" + object.get("PROCESS_NAME").toString()
                                        + "2.Process Status:" + object.get("PROCESS_STATUS").toString()
                                        + "3.Remarks:" + object.get("REMARKS").toString()
                                        + "4.Created Date:" + object.get("CREATED_DATE").toString(),
                                ExtentColor.RED));
                        break;
                    }
                    i++;
                } while (i < elements.length());
                result = "SUCCESS";

            } else {
                logger.info("there is no data ");
                getTest().get().fail(MarkupHelper.createLabel("No record in QUEUE_DATA_HISTORY Table", ExtentColor.RED));

            }

        } catch (Exception e) {
            logger.info("Error: \n", e);
            getTest().get().fail(MarkupHelper.createLabel("Error while verifying queue history table: " + e.getMessage(), ExtentColor.RED));

        }
        return result;

    }

    /**
     * This will check queue history table for payment in YCMS and YOS DB.
     *
     * @param yesId  Pass Yes ID
     * @param source Pass source (For Ex: YCMS, YOS)
     * @return status of the queue history table for payment
     */
    public String checkQueueHistoryTableForPayment(String yesId, String source) {
        CheckQueuePaymentYCMS paymentYCMS = new CheckQueuePaymentYCMS();
        CheckQueuePaymentYOS paymentYOS = new CheckQueuePaymentYOS();
        String bankreceipt = null;
        JSONObject webResult = null;
        try {
            if (source.equalsIgnoreCase("ycms") || source.equalsIgnoreCase("YMCA")
                    || source.equalsIgnoreCase("SELFACTIVATION") || source.equalsIgnoreCase("USSP")) {
                webResult = paymentYCMS.getQueuePaymentYCMS(yesId, source);
            } else if (source.equalsIgnoreCase("YOS") || source.equalsIgnoreCase("SELFCARE")
                    || source.equalsIgnoreCase("XPORTAL")) {
                webResult = paymentYOS.getQueuePaymentYOS(yesId, source);
            }
            logger.info(new StringBuilder("yesId").append(MainUtil.ProjectConst.VALUE.getMsg()).append(yesId));
            if (webResult != null) {
                JSONArray elements = webResult.getJSONArray("Result");
                JSONObject object;
                object = elements.getJSONObject(0);
                bankreceipt = object.get("BANK_RECEIPT_NO").toString();
                logger.info(new StringBuilder("bank receipt").append(MainUtil.ProjectConst.VALUE.getMsg()).append(bankreceipt));

            } else {
                logger.info("there is no data ");
            }

        } catch (Exception e) {
            logger.info("Error: \n", e);
        }
        return bankreceipt;

    }

}
