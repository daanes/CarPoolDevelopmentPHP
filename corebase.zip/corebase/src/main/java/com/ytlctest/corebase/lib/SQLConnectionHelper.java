package com.ytlctest.corebase.lib;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.Connection;
import java.sql.SQLException;

public class SQLConnectionHelper {
    private static Logger logger = LogManager.getLogger(SQLConnectionHelper.class);
    private static String pmasDbIp;
    private static String pmasDbPort;
    private static String pmasDbStepnewSchema;
    private static String pmasDbUsername;
    private static String pmasDbPassword;
    private static String pmasDbDstSchema;
    private static String pmasDbPlanConfigSchema;
    private static String yosDbIp;
    private static String yosDbPort;
    private static String yosDbSchema;
    private static String yosDbUsername;
    private static String yosDbPassword;

    private static String scmDbIp;
    private static String scmDbPort;
    private static String scmDbSchema;
    private static String scmDbUsername;
    private static String scmDbPassword;

    private static String ycmsDbIp;
    private static String ycmsDbPort;
    private static String ycmsDbSchema;
    private static String ycmsDbUsername;
    private static String ycmsDbPassword;

    private static String ycmsQueueDbIp;
    private static String ycmsQueueDbPort;
    private static String ycmsQueueDbSchema;
    private static String ycmsQueueDbUsername;
    private static String ycmsQueueDbPassword;

    private static String ytlcXpayDbIp;
    private static String ytlcXpayDbPort;
    private static String ytlcXpayDbSchema;
    private static String ytlcXpayDbUsername;
    private static String ytlcXpayDbPassword;

    private static String ytlcRnRDbIp;
    private static String ytlcRnRDbPort;
    private static String ytlcRnRDbUsername;
    private static String ytlcRnRDbPassword;
    private static String ytlcRnRDbSchema;

    private static String ytlcMNPDbIp;
    private static String ytlcMNPDbPort;
    private static String ytlcMNPDbUsername;
    private static String ytlcMNPDbPassword;
    private static String ytlcMNPDbSchema;


    private static String ytlMasterDbIp;
    private static String ytlMasterDbPort;
    private static String ytlMasterDbSchema;
    private static String ytlMasterDbUsername;
    private static String ytlMasterDbPassword;

    private static String yosQueueDbIp;
    private static String yosQueueDbPort;
    private static String yosQueueDbSchema;
    private static String yosQueueDbUsername;
    private static String yosQueueDbPassword;

    private static HikariDataSource pmasDataSource;
    private static HikariDataSource pmasDstDataSource;
    private static HikariDataSource yosDBDataSource;
    private static HikariDataSource scmDBDataSource;
    private static HikariDataSource ycmsDBDataSource;
    private static HikariDataSource ycmsQueueDBDataSource;
    private static HikariDataSource ytlcXpayDBDataSource;
    private static HikariDataSource ytlcRnRDataSource;
    private static HikariDataSource ytlcMasterDBDataSource;
    private static HikariDataSource yosQueueDBDataSource;
    private static HikariDataSource ycmsPlanConfigDBDataSource;
    private static HikariDataSource crestelDBDataSource;
    private static HikariDataSource ytlcMNPDBDataSource;

    static {
        pmasDbIp = PropertyHelper.getENVProperties("PMAS_DB_IP");
        pmasDbPort = PropertyHelper.getENVProperties("PMAS_DB_PORT");
        pmasDbStepnewSchema = PropertyHelper.getENVProperties("PMAS_DB_STEPNEW_SCHEMA");
        pmasDbUsername = PropertyHelper.getENVProperties("PMAS_DB_USERNAME");
        pmasDbPassword = PropertyHelper.getENVProperties("PMAS_DB_PASSWORD");
        pmasDbDstSchema = PropertyHelper.getENVProperties("PMAS_DB_DST_SCHEMA");
        pmasDbPlanConfigSchema = PropertyHelper.getENVProperties("PMAS_DB_PLAN_CONFIG_SCHEMA");
        yosDbIp = PropertyHelper.getENVProperties("YOS_DB_IP");
        yosDbPort = PropertyHelper.getENVProperties("YOS_DB_PORT");
        yosDbSchema = PropertyHelper.getENVProperties("YOS_DB_SCHEMA");
        yosDbUsername = PropertyHelper.getENVProperties("YOS_DB_USERNAME");
        yosDbPassword = PropertyHelper.getENVProperties("YOS_DB_PASSWORD");
        scmDbIp = PropertyHelper.getENVProperties("SCM_DB_IP");
        scmDbPort = PropertyHelper.getENVProperties("SCM_DB_PORT");
        scmDbSchema = PropertyHelper.getENVProperties("SCM_DB_SCHEMA");
        scmDbUsername = PropertyHelper.getENVProperties("SCM_DB_USERNAME");
        scmDbPassword = PropertyHelper.getENVProperties("SCM_DB_PASSWORD");
        ycmsDbIp = PropertyHelper.getENVProperties("YCMS_DB_IP");
        ycmsDbPort = PropertyHelper.getENVProperties("YCMS_DB_PORT");
        ycmsDbSchema = PropertyHelper.getENVProperties("YCMS_DB_SCHEMA");
        ycmsDbUsername = PropertyHelper.getENVProperties("YCMS_DB_USERNAME");
        ycmsDbPassword = PropertyHelper.getENVProperties("YCMS_DB_PASSWORD");
        ycmsQueueDbIp = PropertyHelper.getENVProperties("YCMS_QUEUE_DB_IP");
        ycmsQueueDbPort = PropertyHelper.getENVProperties("YCMS_QUEUE_DB_PORT");
        ycmsQueueDbSchema = PropertyHelper.getENVProperties("YCMS_QUEUE_DB_SCHEMA");
        ycmsQueueDbUsername = PropertyHelper.getENVProperties("YCMS_QUEUE_DB_USERNAME");
        ycmsQueueDbPassword = PropertyHelper.getENVProperties("YCMS_QUEUE_DB_PASSWORD");
        if (System.getProperty("env").equalsIgnoreCase("pdc")) {
            if (System.getProperty("location").equalsIgnoreCase("local"))
                ytlcXpayDbIp = PropertyHelper.getENVProperties("YTLC_XPAY_DB_IP_LOCAL");
            else
                ytlcXpayDbIp = PropertyHelper.getENVProperties("YTLC_XPAY_DB_IP");
        } else {
            ytlcXpayDbIp = PropertyHelper.getENVProperties("YTLC_XPAY_DB_IP");
        }
        ytlcXpayDbPort = PropertyHelper.getENVProperties("YTLC_XPAY_DB_PORT");
        ytlcXpayDbSchema = PropertyHelper.getENVProperties("YTLC_XPAY_DB_SCHEMA");
        ytlcXpayDbUsername = PropertyHelper.getENVProperties("YTLC_XPAY_DB_USERNAME");
        ytlcXpayDbPassword = PropertyHelper.getENVProperties("YTLC_XPAY_DB_PASSWORD");
        ytlMasterDbIp = PropertyHelper.getENVProperties("YTL_MASTER_DB_IP");
        ytlMasterDbPort = PropertyHelper.getENVProperties("YTL_MASTER_DB_PORT");
        ytlMasterDbSchema = PropertyHelper.getENVProperties("YTL_MASTER_DB_SCHEMA");
        ytlMasterDbUsername = PropertyHelper.getENVProperties("YTL_MASTER_DB_USERNAME");
        ytlMasterDbPassword = PropertyHelper.getENVProperties("YTL_MASTER_DB_PASSWORD");
        yosQueueDbIp = PropertyHelper.getENVProperties("YOS_QUEUE_DB_IP");
        yosQueueDbPort = PropertyHelper.getENVProperties("YOS_QUEUE_DB_PORT");
        yosQueueDbSchema = PropertyHelper.getENVProperties("YOS_QUEUE_DB_SCHEMA");
        yosQueueDbUsername = PropertyHelper.getENVProperties("YOS_QUEUE_DB_USERNAME");
        yosQueueDbPassword = PropertyHelper.getENVProperties("YOS_QUEUE_DB_PASSWORD");
        ytlcRnRDbIp = PropertyHelper.getENVProperties("YTLC_RNR_DB_IP");
        ytlcRnRDbPort = PropertyHelper.getENVProperties("YTLC_RNR_DB_PORT");
        ytlcRnRDbUsername = PropertyHelper.getENVProperties("YTLC_RNR_DB_USERNAME");
        ytlcRnRDbPassword = PropertyHelper.getENVProperties("YTLC_RNR_DB_PASSWORD");
        ytlcRnRDbSchema = PropertyHelper.getENVProperties("YTLC_RNR_DB_SCHEMA");
        ytlcMNPDbIp = PropertyHelper.getENVProperties("YTLC_MNP_DB_IP");
        ytlcMNPDbPort = PropertyHelper.getENVProperties("YTLC_MNP_DB_PORT");
        ytlcMNPDbUsername = PropertyHelper.getENVProperties("YTLC_MNP_DB_USERNAME");
        ytlcMNPDbPassword = PropertyHelper.getENVProperties("YTLC_MNP_DB_PASSWORD");
        ytlcMNPDbSchema = PropertyHelper.getENVProperties("YTLC_MNP_DB_SCHEMA");
    }

    static {
        String mySqlDriver = "com.mysql.jdbc.Driver";
        logger.info("Setting pmasDataSource");
        pmasDataSource = setMySqlConnDS(pmasDbIp, pmasDbPort, pmasDbStepnewSchema, pmasDbUsername, pmasDbPassword, 8, 40);
        logger.info("Setting pmasDstDataSource");
        pmasDstDataSource = setMySqlConnDS(pmasDbIp, pmasDbPort, pmasDbDstSchema, pmasDbUsername, pmasDbPassword, 2, 4);
        logger.info("Setting ycmsPlanConfigDBDataSource");
        ycmsPlanConfigDBDataSource = setMySqlConnDS(pmasDbIp, pmasDbPort, pmasDbPlanConfigSchema, pmasDbUsername, pmasDbPassword, 2, 2);
        logger.info("Setting ytlcXpayDBDataSource");
        ytlcXpayDBDataSource = setMySqlConnDS(ytlcXpayDbIp, ytlcXpayDbPort, ytlcXpayDbSchema, ytlcXpayDbUsername, ytlcXpayDbPassword, 2, 2);
        logger.info("Setting yosDBDataSource");
        yosDBDataSource = setMySqlConnDS(yosDbIp, yosDbPort, yosDbSchema, yosDbUsername, yosDbPassword, 2, 2);
        if (System.getProperty("env").equalsIgnoreCase("iot")) {
            logger.info("Setting ytlcRNRDBDataSource");
            ytlcRnRDataSource = setMySqlConnDS(ytlcRnRDbIp, ytlcRnRDbPort, ytlcRnRDbSchema, ytlcRnRDbUsername, ytlcRnRDbPassword, 2, 2);
            logger.info("Setting ytlcMNPDBDataSource");
            ytlcMNPDBDataSource = setMySqlConnDS(ytlcMNPDbIp, ytlcMNPDbPort, ytlcMNPDbSchema, ytlcMNPDbUsername, ytlcMNPDbPassword, 2, 2);
        }
        if (!System.getProperty("location").equalsIgnoreCase("remote")) {
            if (!System.getProperty("env").equalsIgnoreCase("pdc")) {
                logger.info("Setting scmDBDataSource");
                scmDBDataSource = setMySqlConnDS(scmDbIp, scmDbPort, scmDbSchema, scmDbUsername, scmDbPassword, 4, 8);
                logger.info("Setting ycmsQueueDBDataSource");
                ycmsQueueDBDataSource = setMySqlConnDS(ycmsQueueDbIp, ycmsQueueDbPort, ycmsQueueDbSchema, ycmsQueueDbUsername, ycmsQueueDbPassword, 2, 2);
                logger.info("Setting ycmsDBDataSource");
                ycmsDBDataSource = setMySqlConnDS(ycmsDbIp, ycmsDbPort, ycmsDbSchema, ycmsDbUsername, ycmsDbPassword, 4, 8);
            }
            logger.info("Setting ytlcMasterDBDataSource");
            ytlcMasterDBDataSource = setMySqlConnDS(ytlMasterDbIp, ytlMasterDbPort, ytlMasterDbSchema, ytlMasterDbUsername, ytlMasterDbPassword, 2, 2);
            logger.info("Setting yosQueueDBDataSource");
            yosQueueDBDataSource = setMySqlConnDS(yosQueueDbIp, yosQueueDbPort, yosQueueDbSchema, yosQueueDbUsername, yosQueueDbPassword, 2, 2);
        }
    }

    private SQLConnectionHelper() {
    }

    private static HikariDataSource setMySqlConnDS(String ip, String port, String schema, String userName, String password, int min, int max) {
        logger.info("calling setMySqlConnDS");
        HikariConfig config = new HikariConfig();
        HikariDataSource hikariDataSource;
        config.setJdbcUrl("jdbc:mysql://" + ip + ":" + port + "/" + schema + "?autoReconnect=true&useSSL=false");
        config.setMinimumIdle(0);
        config.setMaximumPoolSize(100);
        config.setUsername(userName);
        config.setPassword(password);
        config.addDataSourceProperty("cachePrepStmts", "true");
        config.addDataSourceProperty("prepStmtCacheSize", "250");
        config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
        hikariDataSource = new HikariDataSource(config);
        return hikariDataSource;
    }

    public static Connection getPMASDBConnectionStepnewSchema() {
        try {
            logger.info("Getting the PMAS New database connection from the pool");
            return pmasDataSource.getConnection();
        } catch (SQLException sqe) {
            logger.error("Error in getting the database connection from the pool\n", sqe);
        }
        return null;
    }

    public static Connection getPMASDBConnectionDstSchema() {
        try {
            logger.info("Getting the PMAS New DST database connection from the pool");
            return pmasDstDataSource.getConnection();
        } catch (SQLException sqe) {
            logger.error("Error in getting the DST database connection from the pool\n", sqe);
        }
        return null;
    }

    public static Connection getDBConnection(String dbname) {
        try {
            switch (dbname) {
                case "YCMS":
                    return ycmsDBDataSource.getConnection();
                case "YOS":
                    return yosDBDataSource.getConnection();
                case "SCM":
                    return scmDBDataSource.getConnection();
                case "YCMS_QUEUE":
                    return ycmsQueueDBDataSource.getConnection();
                case "YTLC_XPAY":
                    return ytlcXpayDBDataSource.getConnection();
                case "YTLC_RNR":
                    return ytlcRnRDataSource.getConnection();
                case "YTL_MASTER":
                    return ytlcMasterDBDataSource.getConnection();
                case "YOS_QUEUE":
                    return yosQueueDBDataSource.getConnection();
                case "YTLC_MNP":
                    return ytlcMNPDBDataSource.getConnection();
                default:
                    throw new IllegalStateException("Unexpected value: " + dbname);
            }
        } catch (SQLException e) {
            logger.error("Error while accessing the connection\n", e);
        }
        return null;
    }

    public static Connection getYCMSDBConnection() {
        try {
            logger.info("Getting the YCMS database connection from the pool");
            return ycmsDBDataSource.getConnection();
        } catch (SQLException sqe) {
            logger.error("Error in getting the YCMS database connection from the pool\n", sqe);
        }
        return null;
    }

    public static Connection getPlanConfigDBConnection() throws Exception {
        try {
            logger.info("Getting the Plan Config database connection from the pool");
            return ycmsPlanConfigDBDataSource.getConnection();
        } catch (SQLException sqe) {
            logger.error("Error in getting the Plan Config database connection from the pool\n", sqe);
        }
        return null;
    }

    public static void closeDBConnPool() {
        {
            logger.info("Closing the DB connection pool");
            if (pmasDataSource != null) {
                logger.info("Closing pmasDataSource");
                pmasDataSource.close();
            }
            if (pmasDstDataSource != null) {
                logger.info("Closing pmasDstDataSource");
                pmasDstDataSource.close();
            }
            if (ycmsPlanConfigDBDataSource != null) {
                logger.info("Closing ycmsPlanConfigDBDataSource");
                ycmsPlanConfigDBDataSource.close();
            }
            if (ytlcXpayDBDataSource != null) {
                logger.info("Closing ytlcXpayDBDataSource");
                ytlcXpayDBDataSource.close();
            }
            if (ytlcRnRDataSource != null) {
                logger.info("Closing ytlcXpayRnRDataSource");
                ytlcRnRDataSource.close();
            }
            if (!System.getProperty("location").equalsIgnoreCase("remote")) {
                if (scmDBDataSource != null) {
                    logger.info("Closing scmDBDataSource");
                    scmDBDataSource.close();
                }
                if (ytlcMasterDBDataSource != null) {
                    logger.info("Closing ytlcMasterDBDataSource");
                    ytlcMasterDBDataSource.close();
                }
                if (yosQueueDBDataSource != null) {
                    logger.info("Closing yosQueueDBDataSource");
                    yosQueueDBDataSource.close();
                }
                if (ycmsQueueDBDataSource != null) {
                    logger.info("Closing ycmsQueueDBDataSource");
                    ycmsQueueDBDataSource.close();
                }
                if (ycmsDBDataSource != null) {
                    logger.info("Closing ycmsDBDataSource");
                    ycmsDBDataSource.close();
                }
                if (yosDBDataSource != null) {
                    logger.info("Closing yosDBDataSource");
                    yosDBDataSource.close();
                }
            }
        }
    }
}
