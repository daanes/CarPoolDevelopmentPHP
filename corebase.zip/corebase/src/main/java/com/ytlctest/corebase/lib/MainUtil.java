package com.ytlctest.corebase.lib;

import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.ytlctest.corebase.base.DriverFactory;
import com.ytlctest.querywebservices.GetEmailMessage;
import io.appium.java_client.MobileDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.NoSuchElementException;
import java.util.*;

import static com.ytlctest.corebase.listener.ExtentTestNGITestListener.getTest;

public class MainUtil {
    public static Map<String, String> storeVariable = new HashMap<>();
    public static String parentWin = null;
    public static String APPLICATION_NAME;
    public static String Image_Path;
    public static String ENVIRONMENT = System.getProperty("env");
    public static String SIMRECYCLE = System.getProperty("simrecycle");
    public static String dataId = System.getProperty("dataId");
    public static String HubUrl;
    public static String MCMCREMARKS;
    public static HashMap<Integer, String> details = new HashMap<Integer, String>();
    public static ArrayList<String> TestCaseNOs;
    static Markup m;
    private static Logger logger = LogManager.getLogger(MainUtil.class);

    /**
     * Method to launch the URL
     *
     * @param url    Provide the URL
     * @param driver Pass the driver
     */
    public static synchronized void launchURL(String url, RemoteWebDriver driver) {
        try {
            logger.info("Launching the URL");
            if (System.getProperty("pmas").equalsIgnoreCase("true"))
                DriverFactory.getProxy().newHar(url);
            driver.get(url);
            getTest().get().pass("URL Launched Successfully", ExtentScreenCapture.captureSrceenPass("URL", driver));
        } catch (Exception e) {
            logger.error("Text not typed");
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD + " " + "launchURL", e);
            getTest().get().fail("URL Launched UnSuccessful", ExtentScreenCapture.captureSrceenFail("URL", driver));
        }
    }

    /**
     * Method for sending enter key
     *
     * @param element Pass the element against which you want to press enter
     */
    public static synchronized void sendEnterKey(WebElement element) {
        try {
            logger.info("Entering the keys");
            element.sendKeys(Keys.ENTER);
        } catch (NoSuchElementException e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD + " " + "sendEnterKey", e);
        }
    }

    /**
     * To check element is displayed or not
     *
     * @param element pass the element
     * @return return the boolean
     */
    public static boolean IsElementDisplayed(WebElement element) {
        boolean ElementDisplayed = false;
        try {
            if (element.isDisplayed()) {
                ElementDisplayed = true;
            }
        } catch (Exception ex) {
            ElementDisplayed = false;
            logger.error("Got an Exception!!");
            logger.error("Element not visible...");
        }
        return ElementDisplayed;
    }

    /**
     * Method to input text by xpath with Store Variable
     *
     * @param element     Pass the element name against which you want to pass the text
     * @param text        Pass the text to be entered
     * @param elementName Pass the element name for logging
     * @param storeVar    Pass the store variable
     * @param driver      Pass the driver
     */
    public static synchronized void inputTextByXpath(WebElement element, String text, String elementName, String storeVar, RemoteWebDriver driver) {
        try {
            logger.info("Input by xpath");
            element.sendKeys(text);
            if (!(storeVar.equalsIgnoreCase(""))) {
                storeVariable.put(storeVar, element.getAttribute("value"));
                logger.info(new StringBuilder("storeVar======>").append(storeVariable.get(storeVar)));
            }
            if (elementName.toLowerCase().contains("password")) {
                getTest().get().pass(elementName + " Typed Successfully ", ExtentScreenCapture.captureSrceenPass(elementName, driver));
            } else {
                getTest().get().pass(elementName + " " + text + " Typed Successfully ", ExtentScreenCapture.captureSrceenPass(elementName, driver));
            }

        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "inputTextByXpath", e);
            if (elementName.toLowerCase().contains("password")) {
                getTest().get().fail(elementName + " Typed UnSuccessfully ", ExtentScreenCapture.captureSrceenPass(elementName, driver));
            } else {
                getTest().get().fail(elementName + " " + text + " Type UnSuccessful", ExtentScreenCapture.captureSrceenFail(elementName, driver));
            }
        }
    }

    public static synchronized void inputPassword(WebElement element, String password, String elementName, String storeVar, RemoteWebDriver driver) {
        try {
            logger.info("Entering the password");
            element.sendKeys(password);
            if (!(storeVar.equalsIgnoreCase(""))) {
                storeVariable.put(storeVar, element.getAttribute("value"));
                logger.info(new StringBuilder("storeVar ======> ").append(storeVariable.get(storeVar)));
            }
            getTest().get().pass("Password Typed Successfully ", ExtentScreenCapture.captureSrceenPass(elementName, driver));
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "inputTextByXpath", e);
            getTest().get().fail("Password Type UnSuccessful", ExtentScreenCapture.captureSrceenFail(elementName, driver));
        }
    }

    /**
     * Method to click on an element
     *
     * @param elementToClick Pass the element to be clicked
     * @param elementName    Pass the element name for logging purpose
     * @param driver         Pass the driver
     * @return returns the boolean value
     */
    public static synchronized boolean clickByXpath(WebElement elementToClick, String elementName, RemoteWebDriver driver) {
        boolean status = false;
        try {
            logger.info(new StringBuilder("Click by xpath on: ").append(elementName));
            if (System.getProperty("pmas").equalsIgnoreCase("true"))
                DriverFactory.getProxy().newHar(elementName);
            elementToClick.click();
            status = true;
            getTest().get().pass(elementName + " Clicked Successfully", ExtentScreenCapture.captureSrceenPass(elementName, driver));
        } catch (UnhandledAlertException e) {
            clickOnAlert("Ok", "Ok on alert", driver);
            getTest().get().pass(elementName + " Clicked Successfully", ExtentScreenCapture.captureSrceenPass(elementName, driver));
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + "\n" + ProjectConst.ELEMENTNOTFOUNDEXCEPTIONTXT.getMsg(), e);
            getTest().get().fail(elementName + " Click Unsuccessful", ExtentScreenCapture.captureSrceenFail(elementName, driver));
        }
        return status;
    }

    /**
     * Javascript code for clicking
     *
     * @param elementToClick Pass the webelement to be clicked
     * @param elementName    Pass the element name
     * @param driver         Pass the driver object reference
     * @return
     */
    public static synchronized boolean javaScriptClick(WebElement elementToClick, String elementName, RemoteWebDriver driver) {
        boolean status = false;
        try {
            logger.info(new StringBuilder("Click by xpath using JavaScript: ").append(elementName));
            if (System.getProperty("pmas").equalsIgnoreCase("true"))
                DriverFactory.getProxy().newHar(elementName);
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].click();", elementToClick);
            status = true;
            getTest().get().pass(elementName + " Clicked Successfully", ExtentScreenCapture.captureSrceenPass(elementName, driver));
        } catch (UnhandledAlertException e) {
            clickOnAlert("Ok", "Ok on alert", driver);
            getTest().get().pass(elementName + " Clicked Successfully", ExtentScreenCapture.captureSrceenPass(elementName, driver));
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + "\n" + ProjectConst.ELEMENTNOTFOUNDEXCEPTIONTXT.getMsg(), e);
            getTest().get().fail(elementName + " Click Unsuccessful", ExtentScreenCapture.captureSrceenFail(elementName, driver));
        }
        return status;
    }

    /**
     * Method to click on the element and open in the new tab
     *
     * @param elementToClick :Pass the element to be clicked
     * @param elementName    :Pass the element name for logging purpose
     * @param driver         :Pass the driver
     * @return :returns the boolean value
     */
    public static synchronized boolean clickAndOpenInNewTab(WebElement elementToClick, String elementName, RemoteWebDriver driver) {
        boolean status = false;
        try {
            logger.info("click And Open In NewTab");
            Actions action = new Actions(driver);
            action.keyDown(Keys.CONTROL).build().perform();
            elementToClick.click();
            action.keyUp(Keys.CONTROL).build().perform();
            status = true;
            getTest().get().pass(elementName + " Clicked Successfully", ExtentScreenCapture.captureSrceenPass(elementName, driver));
        } catch (UnhandledAlertException e) {
            clickOnAlert("Ok", "Ok on alert", driver);
            getTest().get().pass(elementName + " Clicked Successfully", ExtentScreenCapture.captureSrceenPass(elementName, driver));
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD + " " + ProjectConst.ELEMENTNOTFOUNDEXCEPTIONTXT, e);
            getTest().get().fail(elementName + " Click Unsuccessful", ExtentScreenCapture.captureSrceenFail(elementName, driver));
        }
        return status;
    }

    /**
     * Method switch to new window
     *
     * @param driver :Pass the driver
     */
    public static synchronized void switchToNewTab(RemoteWebDriver driver) {
        try {
            ArrayList tabs;
            tabs = new ArrayList(driver.getWindowHandles());
            logger.info(tabs.size());
            driver.switchTo().window((String) tabs.get(0));
        } catch (Exception e) {
            logger.error("Unable to switch to new tab:", e);
//			getTest().get().fail("Unable to switch to new tab", ExtentScreenCapture.captureSrceenFail("switchToNewTab", driver));
        }
    }

    /**
     * Method to scroll and click
     *
     * @param elementToClick Pass the element to which it has to be scrolled
     * @param elementName    Pass the element name for logging purpose
     * @param driver         Pass the driver
     * @return returns the boolean value
     */
    public static synchronized boolean scrollandClick(WebElement elementToClick, String elementName, RemoteWebDriver driver) {
        boolean status = false;
        try {
            logger.info(new StringBuilder("Scroll and click: ").append(elementToClick));
            WebDriverWait wait = new WebDriverWait(driver, 50);
            Point hoverItem = elementToClick.getLocation();
            ((JavascriptExecutor) driver).executeScript("return window.title;");
            ((JavascriptExecutor) driver).executeScript("window.scrollBy(0," + (hoverItem.getY() - 400) + ");");
            wait.until(ExpectedConditions.elementToBeClickable(elementToClick));
            getTest().get().pass(elementName + " Clicked Successfully", ExtentScreenCapture.captureSrceenPass(elementName, driver));
            if (System.getProperty("pmas").equalsIgnoreCase("true"))
                DriverFactory.getProxy().newHar(elementName);
            elementToClick.click();
            status = true;
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "scrollandClick", e);
            getTest().get().fail(elementName + " Click Unsuccessful", ExtentScreenCapture.captureSrceenFail(elementName, driver));
            throw e;
        }
        return status;
    }

    /**
     * Method to return text value from an element
     *
     * @param storeTextFromElement Pass the element from which the text need to be stored
     * @return returns the text from the after fetching from the element
     */
    public static synchronized String storeTextValue(WebElement storeTextFromElement) {
        String text = "NA";
        try {
            logger.info(new StringBuilder("Store text value in: ").append(storeTextFromElement));
            text = storeTextFromElement.getText();
        } catch (Exception e) {
            logger.error("Element not stored");
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "storeTextValue", e);
            throw e;
        }
        return text;
    }

    /**
     * Method to mousehover and click on an element by Xpath
     *
     * @param mousehover     pass the element on which the mouse needs to hover
     * @param elementTOclick Pass the element to be clicked
     * @param driver         pass the driver
     * @throws InterruptedException throws InterruptedException
     */
    public static synchronized void mouseHoverandClickbyxpath(WebElement mousehover, WebElement elementTOclick, RemoteWebDriver driver) throws InterruptedException {
        try {
            logger.info(new StringBuilder("Mouse hover and click by xpath on: ").append(elementTOclick));
            Thread.sleep(3000);
            logger.info("Instantiating the Actions driver");
            Actions action = new Actions(driver);
            logger.info("Moving the mouse");
            action.moveToElement(mousehover).build().perform();
            Thread.sleep(3000);
            logger.info("clicking on the element");
            elementTOclick.click();
            getTest().get().pass("Mouse Hover and Clicked Successfully", ExtentScreenCapture.captureSrceenPass("mouseHoverandClickbyxpath", driver));
            Thread.sleep(1000);
        } catch (Exception e) {
            logger.error("Mouse Hover Element not found");
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "mouseHoverandClickbyxpath", e);
            getTest().get().fail("Mouse Hover and Click Unsuccessful", ExtentScreenCapture.captureSrceenFail("mouseHoverandClickbyxpath", driver));
        }
    }

    /**
     * Method to mousehover on an element
     *
     * @param mousehover Pass the element on which the mouse needs to hover
     * @param driver     Pass the driver
     */
    public static synchronized void mouseHoveronElement(WebElement mousehover, RemoteWebDriver driver) {
        try {
            logger.info(new StringBuilder("Mouse hovering no: ").append(mousehover));
            Actions action = new Actions(driver);
            logger.info("Moving the mouse");
            action.moveToElement(mousehover).build().perform();
            getTest().get().pass("Mouse Hover Successfully", ExtentScreenCapture.captureSrceenPass("mouseHover", driver));
        } catch (Exception e) {
            logger.error("Mouse Hover Element not found");
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "mouseHover", e);
            getTest().get().fail("Mouse Hover Unsuccessful", ExtentScreenCapture.captureSrceenFail("mouseHover", driver));
        }
    }

    /**
     * Method to switch to certain frame by Xpath
     *
     * @param switchFrame Pass the target i-frame name where need to switch
     * @param driver      Pass the driver
     */
    public static synchronized void switchToFramebyXpath(WebElement switchFrame, RemoteWebDriver driver) {
        try {
            logger.info(new StringBuilder("Switch to frame by xpath: ").append(switchFrame));
            driver.switchTo().frame(switchFrame);
            getTest().get().pass("Switch to Frame Successful", ExtentScreenCapture.captureSrceenPass("switchToFramebyXpath", driver));
        } catch (Exception e) {
            logger.error("Not switched to Frame");
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "switchToFramebyXpath", e);
            getTest().get().fail("Switch to Frame Unsuccessful", ExtentScreenCapture.captureSrceenFail("switchToFramebyXpath", driver));
        }
    }

    /**
     * Method to switch back to DefaultContent / Parent frame
     *
     * @param driver pass the driver
     */
    public static synchronized void switchBackFromFrame(RemoteWebDriver driver) {
        try {
            logger.info("Switch back from frame");
            driver.switchTo().defaultContent();
            getTest().get().pass("Switch back from Frame Successful", ExtentScreenCapture.captureSrceenPass("switchBackFromFrame", driver));
        } catch (Exception e) {
            logger.error("Not switched back from  Frame");
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD + " " + "switchToFramebyXpath", e);
            getTest().get().fail("switched back from Frame Unsuccessful", ExtentScreenCapture.captureSrceenFail("switchBackFromFrame", driver));
        }
    }

    /**
     * Method to select drop down option by its value or visible text using
     *
     * @param dropDown      Pass the element of dropdown
     * @param dropdownValue Pass the element of value of the dropdown
     * @param driver        Pass the driver
     */
    public static synchronized void selectValueByDropdown(WebElement dropDown, String dropdownValue, RemoteWebDriver driver) {
        try {
            logger.info(new StringBuilder("Select value by dropdown: ").append(dropDown));
            WebElement dropdownValues = dropDown;
            Select dropdowm = new Select(dropdownValues);
            WebDriverWait wait = new WebDriverWait(driver, 60);
            wait.until(ExpectedConditions.elementToBeClickable(dropDown));
            dropdowm.selectByVisibleText(dropdownValue);
            getTest().get().pass("Selected value " + dropdownValue + " from Dropdown Successfully", ExtentScreenCapture.captureSrceenPass("selectValueByDropdown", driver));
        } catch (Exception e) {
            logger.error("Dropdown value not found");
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "selectValueByDropdown", e);
            getTest().get().fail("Value not Selected", ExtentScreenCapture.captureSrceenFail("selectValueByDropdown", driver));
        }
    }

    /**
     * Method to verify text of an element by Xpath
     *
     * @param checkForText  Pass the element name against which you want to check the text
     * @param textToCompare pass the text to compare
     * @param elementName   Pass the element name for logging purpose
     * @param driver        pass the driver
     * @return a String value
     */
    public static synchronized String verifyTextByXpath(WebElement checkForText, String textToCompare, String elementName, RemoteWebDriver driver) {
        String successmsg = null;
        String xpathText = null;
        try {
            logger.info(new StringBuilder("Verify text by xpath: ").append(checkForText));
            xpathText = checkForText.getText();
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].setAttribute('style', arguments[1]);", checkForText, "border: 5px solid red;");
            if (xpathText.trim().replaceAll("\\s", "").equalsIgnoreCase(textToCompare.trim().replaceAll("\\s", ""))) {
                logger.info("Text matches with the given text");
                successmsg = xpathText;
                getTest().get().pass(elementName + " Text matches with the given text. Expected Value:" + textToCompare + " Actual Value:" + xpathText, ExtentScreenCapture.captureSrceenPass("verifyTextByXpath", driver));
            } else if (xpathText.trim().toLowerCase().matches(textToCompare.trim().toLowerCase())) {
                logger.info("Text matches with the given text");
                successmsg = xpathText;
                getTest().get().pass(elementName + " Text matches with the given text. Expected Value:" + textToCompare + " Actual Value:" + xpathText, ExtentScreenCapture.captureSrceenPass("verifyTextByXpath", driver));
            } else {
                logger.info("Text does not match with the given text");
                getTest().get().fail(elementName + " Text does not match with the given text. Expected Value:" + textToCompare + " Actual Value:" + xpathText, ExtentScreenCapture.captureSrceenFail("verifyTextByXpath", driver));
            }
            js.executeScript("arguments[0].setAttribute('style', arguments[1]);", checkForText, "border: none;");
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "verifyTextByXpath", e);
            getTest().get().fail("Some Exception Occur in verifyTextByXpath for " + elementName + ". Expected Value:" + textToCompare + " Actual Value:" + xpathText, ExtentScreenCapture.captureSrceenFail("verifyTextByXpath", driver));
        }
        return successmsg;
    }

    /**
     * Method to get Date and Time
     *
     * @return a String value
     */
    public static String getDateTime() {
        DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy_HH_mm_ss");
        Date date = new Date();
        return dateFormat.format(date);
    }

    /**
     * Method to select drop down value by option using tagName
     *
     * @param element Pass the element of dropdown
     * @param text    Pass the text which need to select from the dropdown
     * @param driver  Pass the driver
     */
    public static synchronized void fetchOptionFromDropDown(WebElement element, String text, RemoteWebDriver driver) {
        try {
            logger.info("Fetch option from dropdown from: " + element);
            List<WebElement> allOptions = element.findElements(By.tagName("option"));
            for (WebElement option : allOptions) {
                if (option.getText().equalsIgnoreCase(text)) {
                    option.click();
                    break;
                }
            }
            getTest().get().pass("Fetched " + text + " From Dropdown", ExtentScreenCapture.captureSrceenPass("fetchOptionFromDropDown", driver));
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "getDateTime", e);
            getTest().get().fail("Some Exception Occured", ExtentScreenCapture.captureSrceenFail("fetchOptionFromDropDown", driver));
        }
    }

    /**
     * Method to verify for text in android
     *
     * @param storeVar    Pass the storevariable
     * @param element     Pass the element for which you want to check the text
     * @param data        Pass the data need to compare
     * @param elementName Pass the element name for which you want to check the text
     * @param driver      Pass the driver
     */
    public static synchronized void checkForText(String storeVar, WebElement element, String data, String elementName, AndroidDriver driver) {
        try {
            logger.info("Check for text in: " + element);
            String actualOutput = element.getText();
            if (!(storeVar.equalsIgnoreCase(""))) {
                storeVariable.put(storeVar, actualOutput);
            }
            logger.info(new StringBuilder("### Check for Text: Target element verification first:").append(element));
            if (element.isDisplayed()) {
                if (actualOutput.trim().replaceAll("\\s", "").equalsIgnoreCase(data.trim().replaceAll("\\s", ""))) {
                    logger.info("Text matches with the given text");
                    getTest().get().pass("Text matches! " + elementName + " - Expected: " + data + "\n - Actual: " + actualOutput, ExtentScreenCapture.captureSrceenPass("checkForText", driver));
                } else if (element.getText().trim().toLowerCase().matches(data.trim().toLowerCase())) {
                    logger.info("#### Text Found in the Target location ####");
                    getTest().get().pass(elementName + " Text Found in the Target location", ExtentScreenCapture.captureSrceenPass("checkForText", driver));
                } else if (element.getText().trim().equalsIgnoreCase(data.trim())) {
                    logger.info("#### Text Found in the Target location ####");
                    getTest().get().pass(elementName + " Text Found in the Target location", ExtentScreenCapture.captureSrceenPass("checkForText", driver));
                } else {
                    logger.info("#### Text Not found in the Target location ####");
                    getTest().get().fail("Text does not matches " + elementName + " - Expected: " + data + "\n - Actual: " + actualOutput, ExtentScreenCapture.captureSrceenFail("checkForText", driver));
                }
            } else {
                logger.info("#### The Element is not found & Unable to verify Text");
                getTest().get().fail(elementName + "The Element is not found & Unable to verify Text", ExtentScreenCapture.captureSrceenFail("checkForText", driver));
            }
        } catch (Exception e) {
            logger.error("#### Error occured while checking the text in the " + elementName);
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "checkForText", e);
            getTest().get().fail("Error occured while checking the text in the " + elementName, ExtentScreenCapture.captureSrceenFail("checkForText", driver));
        }
    }

    /**
     * Method to verify for text in iOS
     *
     * @param storeVar    Pass the storevariable
     * @param element     Pass the element for which you want to check the text
     * @param data        Pass the data need to compare
     * @param elementName Pass the element name for which you want to check the text
     * @param driver      Pass the driver
     */
    public static synchronized void checkForText(String storeVar, WebElement element, String data, String elementName, IOSDriver driver) {
        try {
            logger.info("Check for text in the element: " + elementName);
            String actualOutput = element.getText();
            if (!(storeVar.equalsIgnoreCase(""))) {
                storeVariable.put(storeVar, actualOutput);
            }
            logger.info("### Check for Text: Target element verification first:" + element);
            if (element.isDisplayed()) {
                if (actualOutput.trim().replaceAll("\\s", "").equalsIgnoreCase(data.trim().replaceAll("\\s", ""))) {
                    logger.info("Text matches with the given text");
                    getTest().get().pass("Text matches! " + elementName + " - Expected: " + data + "\n - Actual: " + actualOutput, ExtentScreenCapture.captureSrceenPass("checkForText", driver));
                } else if (element.getText().trim().toLowerCase().matches(data.trim().toLowerCase())) {
                    logger.info("#### Text Found in the Target location ####");
                    getTest().get().pass(elementName + " Text Found in the Target location", ExtentScreenCapture.captureSrceenPass("checkForText", driver));
                } else if (element.getText().trim().equalsIgnoreCase(data.trim())) {
                    logger.info("#### Text Found in the Target location ####");
                    getTest().get().pass(elementName + " Text Found in the Target location", ExtentScreenCapture.captureSrceenPass("checkForText", driver));
                } else {
                    logger.info("#### Text Not found in the Target location ####");
                    getTest().get().fail("Text does not matches " + elementName + " - Expected: " + data + "\n - Actual: " + actualOutput, ExtentScreenCapture.captureSrceenFail("checkForText", driver));
                }
            } else {
                logger.info("#### The Element is not found & Unable to verify Text");
                getTest().get().fail(elementName + "The Element is not found & Unable to verify Text", ExtentScreenCapture.captureSrceenFail("checkForText", driver));
            }
        } catch (Exception e) {
            logger.error("#### Error occured while checking the text in the " + elementName);
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "checkForText", e);
            getTest().get().fail("Error occured while checking the text in the " + elementName, ExtentScreenCapture.captureSrceenFail("checkForText", driver));
        }
    }

    /**
     * Method to verify for text in web
     *
     * @param storeVar    Pass the storevariable
     * @param element     Pass the element for which you want to check the text
     * @param data        Pass the data to compare
     * @param elementName Pass the element for which you want to check the text
     * @param driver      Pass the driver
     */
    public static synchronized void checkForText(String storeVar, WebElement element, String data, String elementName, RemoteWebDriver driver) {
        try {
            logger.info("Check for text " + data);
            String actualOutput = element.getText();
            if (!(storeVar.equalsIgnoreCase(""))) {
                storeVariable.put(storeVar, actualOutput);
            }
            logger.info("### Check for Text: Target element verification first:" + element);
            if (element.isDisplayed()) {
                if (MainUtil.APPLICATION_NAME.equalsIgnoreCase("ycms") || MainUtil.APPLICATION_NAME.equalsIgnoreCase("scm"))
                    scrollToWebElement(element, driver);
                else
                    scrollToElement(element, driver);
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "border: 5px solid red;");
                if (actualOutput.trim().replaceAll("\\s", "").equalsIgnoreCase(data.trim().replaceAll("\\s", ""))) {
                    logger.info("Text matches with the given text");
                    getTest().get().pass("Text matches! " + elementName + " - Expected: " + data + "\n - Actual: " + actualOutput, ExtentScreenCapture.captureSrceenPass("checkForText", driver));
                } else if (element.getText().trim().toLowerCase().matches(data.trim().toLowerCase())) {
                    logger.info("#### Text Found in the Target location ####");
                    getTest().get().pass(elementName + " Text Found in the Target location", ExtentScreenCapture.captureSrceenPass("checkForText", driver));
                } else if (element.getText().trim().equalsIgnoreCase(data.trim())) {
                    logger.info("#### Text Found in the Target location ####");
                    getTest().get().pass(elementName + " Text Found in the Target location", ExtentScreenCapture.captureSrceenPass("checkForText", driver));
                } else {
                    logger.info("#### Text Not found in the Target location ####");
                    getTest().get().fail("Text does not matches " + elementName + " - Expected: " + data + "\n - Actual: " + actualOutput, ExtentScreenCapture.captureSrceenFail("checkForText", driver));
                }
                js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "border: none;");
            } else {
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "border: 5px solid red;");
                logger.info("#### The Element is not found & Unable to verify Text");
                js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "border: none;");
                getTest().get().fail(elementName + "The Element is not found & Unable to verify Text", ExtentScreenCapture.captureSrceenFail("checkForText", driver));
            }
        } catch (Exception e) {
            logger.error("#### Error occured while checking the text in the " + elementName);
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "checkForText", e);
            getTest().get().fail("Error occured while checking the text in the " + elementName, ExtentScreenCapture.captureSrceenFail("checkForText", driver));
        }
    }

    /**
     * Method to check whether element is present for web
     *
     * @param storeVar    Pass the store variable
     * @param element     Pass the element for which the text need to check
     * @param elementName Pass the element name for which the text need to check
     * @param driver      Pass the driver
     */
    public static synchronized void checkForElement(String storeVar, WebElement element, String elementName, RemoteWebDriver driver) {
        try {
            logger.info("Check for the element:" + elementName);
            if (!(storeVar.equalsIgnoreCase("") || storeVar == null)) {
                storeVariable.put(storeVar, element.getText());
                logger.info("### Check for Text: Target element verification first:" + element);
                logger.info("### @@@ The element to be found:" + element);
            }
            if (element.isDisplayed()) {
                if (MainUtil.APPLICATION_NAME.equalsIgnoreCase("ycms") || MainUtil.APPLICATION_NAME.equalsIgnoreCase("scm"))
                    scrollToWebElement(element, driver);
                else
                    scrollToElement(element, driver);
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "border: 5px solid red;");
                logger.info("### The Element is verified successfully");
                getTest().get().pass(elementName + "Element is verified successfully", ExtentScreenCapture.captureSrceenPass("checkForElement", driver));
                js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "border: none;");
            } else {
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "border: 5px solid red;");
                logger.info("### The Element is not verified successfully");
                getTest().get().fail(elementName + "Element is not verified successfully", ExtentScreenCapture.captureSrceenFail("checkForElement", driver));
                js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "border: none;");
            }
        } catch (NoSuchElementException e) {
            logger.error("### Error occured while checking the element " + elementName);
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + " Error in checkForElement", e);
            getTest().get().fail("Error occured while checking the element ", ExtentScreenCapture.captureSrceenFail("checkForElement", driver));
        }
    }

    /**
     * Method to check whether element is present for android (mobile)
     *
     * @param storeVar    Pass the store variable
     * @param element     Pass the element for which need to check the element exist or not
     * @param elementName Pass the element name for which need to check the element exist or not
     * @param driver      Pass the Android driver
     */
    public static synchronized void checkForElement(String storeVar, WebElement element, String elementName, AndroidDriver driver) {
        try {
            logger.info("Check for the element: " + elementName);
            if (!(storeVar.equalsIgnoreCase("") || storeVar == null)) {
                logger.info("line 3511 --inside the if where storevariable is not null");
                storeVariable.put(storeVar, element.getText());
                logger.info("### Check for Text: Target element verification first:" + element);
                logger.info("### @@@ The element to be found:" + element);
            }
            if (element.isDisplayed()) {
                logger.info("### The Element is verified successfully");
                getTest().get().pass(elementName + "Element is verified successfully", ExtentScreenCapture.captureSrceenPass("checkForElement", driver));

            } else {
                logger.info("### The Element is not verified successfully");
                getTest().get().fail(elementName + "Element is not verified successfully", ExtentScreenCapture.captureSrceenFail("checkForElement", driver));
            }
        } catch (Exception e) {
            logger.error("### Error occured while checking the element " + elementName);
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + " Error in checkForElement", e);
            getTest().get().fail("Error occured while checking the element ", ExtentScreenCapture.captureSrceenFail("checkForElement", driver));
        }
    }

    /**
     * Method to check whether element is present for android (mobile)
     *
     * @param storeVar    Pass the store variable
     * @param element     Pass the element for which need to check the element exist or not
     * @param elementName Pass the element name for which need to check the element exist or not
     * @param driver      Pass the IOS driver
     */
    public static synchronized void checkForElement(String storeVar, WebElement element, String elementName, IOSDriver driver) {
        try {
            logger.info("Check for the element");
            if (!(storeVar.equalsIgnoreCase("") || storeVar == null)) {
                logger.info("line 3511 --inside the if where storevariable is not null");
                storeVariable.put(storeVar, element.getText());
                logger.info("### Check for Text: Target element verification first:" + element);
                logger.info("### @@@ The element to be found:" + element);
            }
            if (element.isDisplayed()) {
                logger.info("### The Element is verified successfully");
                getTest().get().pass(elementName + "Element is verified successfully", ExtentScreenCapture.captureSrceenPass("checkForElement", driver));
            } else {
                logger.info("### The Element is not verified successfully");
                getTest().get().fail(elementName + "Element is not verified successfully", ExtentScreenCapture.captureSrceenFail("checkForElement", driver));
            }
        } catch (Exception e) {
            logger.error("### Error occured while checking the element " + elementName);
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + " Error in checkForElement", e);
            getTest().get().fail("Error occured while checking the element ", ExtentScreenCapture.captureSrceenFail("checkForElement", driver));
        }
    }

    public static synchronized void verifyElementIsNotDisplayed(WebElement element, String ElementName, RemoteWebDriver driver) {
        boolean ElementDisplayed = false;
        try {
            if (element.isDisplayed()) {
                ElementDisplayed = true;
            }

        } catch (Exception ex) {
            ElementDisplayed = false;
            System.out.println("Element not present...");
        }
        if (ElementDisplayed == false) {
            getTest().get().pass(ElementName + " Element is not present", ExtentScreenCapture.captureSrceenFail(ElementName, driver));
        } else {
            getTest().get().fail(ElementName + " Element is present", ExtentScreenCapture.captureSrceenFail(ElementName, driver));
        }
    }

    /**
     * Method to select/switch to new window
     *
     * @param driver pass the driver
     */
    public static synchronized void selectNewWindow(RemoteWebDriver driver) {
        try {
            logger.info("Switch new window");
            parentWin = driver.getWindowHandle();
            logger.info("parentWin: " + parentWin);
            String childWin = null;
            Set<String> winHandles = driver.getWindowHandles();
            Iterator<String> iterator = winHandles.iterator();
            while (iterator.hasNext())
                childWin = iterator.next();
            driver.switchTo().window(childWin);
            getTest().get().pass(" New Window Selected ", ExtentScreenCapture.captureSrceenPass("selectNewWindow", driver));
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "Error Selecting the new window", e);
            getTest().get().fail("New Window Nots Selected", ExtentScreenCapture.captureSrceenFail("selectNewWindow", driver));
        }
    }

    /**
     * Method to click on an element and switch back to parent window
     *
     * @param element Pass the element of the parent window
     * @param driver  Pass the driver
     */
    public static synchronized void clickAndSwitchBack(WebElement element, RemoteWebDriver driver) {
        try {
            logger.info("Click and swich back");
            if (element.isDisplayed()) {
                logger.info("### Eelement is displayed ");
                element.click();
                logger.info("### Click is done successfully");
                driver.switchTo().window(parentWin);
                logger.info("### Switched to parent window");
                getTest().get().pass("Click is done successfully", ExtentScreenCapture.captureSrceenPass("clickAndSwitchBack", driver));
            } else {
                logger.info("### Eelement was not found");
                getTest().get().fail("Eelement was not found", ExtentScreenCapture.captureSrceenFail("clickAndSwitchBack", driver));
            }
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg(), e);
            getTest().get().fail("Error Occured in click And Switch Back ", ExtentScreenCapture.captureSrceenFail("clickAndSwitchBack", driver));
        }
    }

    /**
     * Method to compare two strings
     *
     * @param actual      pass the actual String to compare
     * @param expected    pass the expected String
     * @param driver      pass the driver
     * @param elementName pass the element name for logging purpose
     */
    public synchronized static void compareString(String actual, String expected, RemoteWebDriver driver, String elementName) {
        try {
            //logger.info(actual.replaceAll("\\s+", ""));
            //logger.info(expected.replaceAll("\\s+", ""));
            if (actual.replaceAll("\\s+", "").equalsIgnoreCase(expected.replaceAll("\\s+", ""))) {
                logger.info(elementName + " comparision is successful - actual : expected -> " + actual + " : " + expected);
                getTest().get().pass(elementName + " comparison Successful ,actual value = " + actual + " expected value = " + expected);
            } else {
                logger.info(elementName + " comparision is unsuccessful - actual : expected -> " + actual + " : " + expected);
                getTest().get().fail(elementName + " comparison unsuccessful ,actual value = " + actual + " expected value = " + expected);
            }
        } catch (Exception e) {
            logger.error("comparision unsuccessfull");
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "compareString", e);
        }
    }

    /**
     * Method to click by Mouse
     *
     * @param element pass the element which need to be clicked
     * @param driver  pass the driver
     */
    public static synchronized void mouseClick(WebElement element, RemoteWebDriver driver) {
        Actions click = new Actions(driver);
        try {
            logger.info("Mouse click on: " + element);
            click.moveToElement(element).click().perform();
            getTest().get().pass("Mouse Click Successful", ExtentScreenCapture.captureSrceenPass("mouseClick", driver));
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "mouseClick", e);
            getTest().get().fail("Mouse Click UnSuccessful", ExtentScreenCapture.captureSrceenFail("mouseClick", driver));
        }
    }

    /**
     * Method to store path of the image to be stored
     */
    public static synchronized void storeImagePath() {
        try {
            logger.info("Store image path");
            storeVariable.put("IMAGE_TO_STORE", Image_Path);
            getTest().get().pass("storeImagePath : Image Stored Successfully");
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "Error in storeImagePath", e);
            getTest().get().fail("storeImagePath : Image Stored Unsuccessful");
            throw e;
        }
    }

    /**
     * Method to click on element twice
     *
     * @param element pass the elemet which need to double clicked
     * @param driver  pass the driver
     */
    public static synchronized void doubleClickOnElement(WebElement element, RemoteWebDriver driver) {
        try {
            Actions actions = new Actions(driver);
            actions.moveToElement(element).doubleClick().perform();
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "Error while doubleClickOnElement", e);
            getTest().get().fail("doubleClickOnElement : Double click failed");
            throw e;
        }
    }

    /**
     * Method to move/scroll/view to the element
     *
     * @param elementToClick pass the element to be clicked
     * @param driver         pass the driver
     */
    public static synchronized void scrollToElement(WebElement elementToClick, RemoteWebDriver driver) {
        try {
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", elementToClick);
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "Error while scrollToElement", e);
            getTest().get().fail("scrollToElement:  Scroll to Element failed");
            throw e;
        }
    }

    /**
     * Method to clear browsing data
     *
     * @param driver Pass the driver
     */
    public static void ClearBrowsingData(RemoteWebDriver driver) {
        try {
            logger.info("clearng the browser");
            driver.get("chrome://settings/clearBrowserData");
            //WebDriverWait wait = new WebDriverWait(driver, 60);
            //  WebElement element = driver.findElement(By.cssSelector("*/deep/ #clearBrowsingDataConfirm"));
            // wait.until(ExpectedConditions.visibilityOf(element));
            //  element.click();
            // wait for the button to be gone before returning
            //  wait.until(ExpectedConditions.invisibilityOf(element));
            Actions action = new Actions(driver);
            Thread.sleep(5000);
            action.sendKeys(Keys.ENTER).build().perform();
            Thread.sleep(5000);
            logger.info("clearng the browser done");
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "ClearBrowsingData", e);
        }
    }

    /**
     * Method to scroll into the view of a web element
     *
     * @param elementToClick pass the element which need to scroll and click
     * @param driver         pass the driver
     */
    public static synchronized void scrollToWebElement(WebElement elementToClick, RemoteWebDriver driver) {
        Point hoverItem = elementToClick.getLocation();
        ((JavascriptExecutor) driver).executeScript("return window.title;");
        ((JavascriptExecutor) driver).executeScript("window.scrollBy(0," + (hoverItem.getY() - 400) + ");");
    }

    /**
     * Method to check value not null
     *
     * @param storeVar    pass the store variable
     * @param element     pass the element for which you want to check the value
     * @param elementName pass the element name for logging purpose
     * @param driver      pass the driver
     */
    public static synchronized void checkValueNotNull(String storeVar, WebElement element, String elementName,
                                                      RemoteWebDriver driver) {
        try {
            logger.info("Check for the element");
            if (!(storeVar.equalsIgnoreCase("") || storeVar == null)) {
                logger.info("line 3511 --inside the if where storevariable is not null");
                storeVariable.put(storeVar, element.getText());
                logger.info("### Check for Text: Target element verification first:" + element);
                logger.info("### @@@ The element to be found:" + element);
            }
            String textinelement = element.getAttribute("value");
            logger.info("text is " + textinelement);
            if (textinelement != null && !("".equals(textinelement))) {
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element,
                        "border: 5px solid red;");
                logger.info("### The Element is verified successfully");
                getTest().get().pass(elementName + "Element is verified successfully", ExtentScreenCapture.captureSrceenPass("checkForElement", driver));
                js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "border: none;");
            } else {
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element,
                        "border: 5px solid red;");
                logger.info("### The Element is not verified successfully");
                getTest().get().fail(elementName + "Element is not verified successfully", ExtentScreenCapture.captureSrceenFail("checkForElement", driver));
                js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "border: none;");
            }
        } catch (Exception e) {
            logger.error("### Error occured while checking the element " + elementName);
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + " Error in checkForElement", e);
            getTest().get().fail("Error occured while checking the element ", ExtentScreenCapture.captureSrceenFail("checkForElement", driver));
        }
    }

    /**
     * Method to check text not null
     *
     * @param storeVar    Pass the store variable
     * @param element     Pass the element for which you want to check the value
     * @param elementName Pass the element name for logging purpose
     * @param driver      Pass the driver
     */
    public static synchronized void checkTextNotNull(String storeVar, WebElement element, String elementName, RemoteWebDriver driver) {
        try {
            logger.info("Check for the element");
            if (!(storeVar.equalsIgnoreCase("") || storeVar == null)) {
                logger.info("line 3511 --inside the if where storevariable is not null");
                storeVariable.put(storeVar, element.getText());
                logger.info("### Check for Text: Target element verification first:" + element);
                logger.info("### @@@ The element to be found:" + element);
            }
            String textinelement = element.getText();
            System.out.println("text is " + textinelement);
            if (textinelement != null && !("".equals(textinelement))) {
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element,
                        "border: 5px solid red;");
                logger.info("### The Element is verified successfully");
                getTest().get().pass(elementName + "Element is verified successfully", ExtentScreenCapture.captureSrceenPass("checkForElement", driver));
                js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "border: none;");
            } else {
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element,
                        "border: 5px solid red;");
                logger.info("### The Element is not verified successfully");
                getTest().get().fail(elementName + "Element is not verified successfully", ExtentScreenCapture.captureSrceenFail("checkForElement", driver));
                js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "border: none;");
            }
        } catch (Exception e) {
            logger.error("### Error occured while checking the element " + elementName);
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + " Error in checkForElement", e);
            getTest().get().fail("Error occured while checking the element ", ExtentScreenCapture.captureSrceenFail("checkForElement", driver));
        }
    }

    /**
     * Method to click on an alert button
     *
     * @param confirmationMessage pass the confirmation message
     * @param elementName         pass the element where need to click
     * @param driver              pass the driver
     */
    public static synchronized String clickOnAlert(String confirmationMessage, String elementName, RemoteWebDriver driver) {
        String alertText = null;
        try {
            logger.info("Clicking on Alert");
            Alert alert = driver.switchTo().alert();
            if (confirmationMessage.equalsIgnoreCase("Ok")) {
                alert.accept();
                alertText = alert.getText();
                logger.info("Ok Clicked Successfully");
                getTest().get().pass(elementName + "Element is Selected successfully", ExtentScreenCapture.captureSrceenPass("clickOnAlert", driver));
            } else if (confirmationMessage.equalsIgnoreCase("Cancel")) {
                alert.dismiss();
                logger.info("Cancel Clicked Successfully");
                getTest().get().pass(elementName + "Element is selected successfully", ExtentScreenCapture.captureSrceenFail("clickOnAlert", driver));
            }
        } catch (Exception e) {
            logger.error("### Error occured while clicking the element " + elementName);
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + " Error in clickOnAlert", e);
            getTest().get().fail("Error occured while clicking the element ", ExtentScreenCapture.captureSrceenFail("clickOnAlert", driver));
        }
        return alertText;
    }

    /**
     * Method to scroll in Android (mobile)
     *
     * @param driver  Pass the driver
     * @param seconds Pass the time for which duration you need to scroll
     */
    public static synchronized void scroll(MobileDriver driver, int seconds) {
        try {
            logger.info("Scrolling");
            Dimension size = driver.manage().window().getSize();
            logger.info("size ---" + size + "::::;" + size.height + ":::::" + size.width);
            int starty = (int) (size.height * 0.50);
            int endy = (int) (size.height * 0.20);
            int startx = size.getWidth() / 2;
            logger.info(startx + "::::::" + starty + "::::::" + endy + "dfugv");
            TouchAction action = new TouchAction(driver);
            action.press(PointOption.point(startx, starty)).waitAction(WaitOptions.waitOptions(Duration.ofSeconds(seconds))).moveTo(PointOption.point(startx, endy)).release()
                    .perform();
        } catch (Exception e) {
            logger.info("Not Scrolled");
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + "\n" + ProjectConst.ELEMENTNOTFOUNDEXCEPTIONTXT.getMsg(), e);
        }
    }

    /**
     * Method to scroll/swipe Up Down left right in mobile
     *
     * @param driver    Pass the instance of mobile driver
     * @param duration  Pass the time for which duration you need to scroll
     * @param direction Pass the direction
     */
    public static synchronized void scrollUDLR(MobileDriver driver, int duration, String direction) {
        try {
            logger.info("Scrolling UDLR");
            Thread.sleep(1000);
            Dimension size = driver.manage().window().getSize();
            logger.info("size ---" + size + "::::;" + size.height + ":::::" + size.width);
            TouchAction action = new TouchAction(driver);
            int starty = 0;
            int endy = 0;
            int startx = 0;
            switch (direction) {
                case "R":
                    starty = (int) (size.height * 0.50);
                    endy = (int) (size.width * 0.70);
                    startx = size.getWidth() / 2;
                    break;
                case "L":
                    starty = (int) (size.height * 0.50);
                    endy = (int) (size.width * 0.20);
                    startx = size.getWidth() / 2;
                    break;
                case "U":
                    starty = (int) (size.height * 0.50);
                    endy = (int) (size.height * 0.20);
                    startx = size.getWidth() / 2;
                    break;
                case "D":
                    starty = (int) (size.height * 0.50);
                    endy = (int) (size.height * 0.70);
                    startx = size.getWidth() / 2;
                    break;
            }
            logger.info(startx + "::::::" + starty + "::::::" + endy + "dfugv");
            action.press(PointOption.point(startx, starty)).waitAction(WaitOptions.waitOptions(Duration.ofSeconds(duration))).moveTo(PointOption.point(startx, endy)).release()
                    .perform();
        } catch (Exception e) {
            logger.info("Not Scrolled");
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + "\n" + ProjectConst.ELEMENTNOTFOUNDEXCEPTIONTXT.getMsg(), e);
        }
    }

    /**
     * Method to scroll/swipe Up Down left right in mobile
     *
     * @param driver    Pass the instance of mobile driver
     * @param duration  Pass the time for which duration you need to scroll
     * @param direction Pass the direction
     */
    public static synchronized void scrollUDLRShort(MobileDriver driver, int duration, String direction) {
        try {
            logger.info("Scrolling UDLR");
            Thread.sleep(1000);
            Dimension size = driver.manage().window().getSize();
            TouchAction action = new TouchAction(driver);
            int starty = 0;
            int endy = 0;
            int startx = 0;
            switch (direction) {
                case "R":
                    starty = (int) (size.height * 0.50);
                    endy = (int) (size.width * 0.60);
                    startx = size.getWidth() / 2;
                    break;
                case "L":
                    starty = (int) (size.height * 0.50);
                    endy = (int) (size.width * 0.30);
                    startx = size.getWidth() / 2;
                    break;
                case "U":
                    starty = (int) (size.height * 0.50);
                    endy = (int) (size.height * 0.30);
                    startx = size.getWidth() / 2;
                    break;
                case "D":
                    starty = (int) (size.height * 0.50);
                    endy = (int) (size.height * 0.60);
                    startx = size.getWidth() / 2;
                    break;
            }
            action.press(PointOption.point(startx, starty)).waitAction(WaitOptions.waitOptions(Duration.ofSeconds(duration))).moveTo(PointOption.point(startx, endy)).release()
                    .perform();
        } catch (Exception e) {
            logger.info("Not Scrolled");
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + "\n" + ProjectConst.ELEMENTNOTFOUNDEXCEPTIONTXT.getMsg(), e);
        }
    }

    /**
     * Method to scroll/swipe Up Down left right in mobile
     *
     * @param driver    Pass the instance of mobile driver
     * @param duration  Pass the time for which duration you need to scroll
     * @param direction Pass the direction
     */
    public static synchronized void scrollUDLRLong(MobileDriver driver, int duration, String direction) {
        try {
            logger.info("Scrolling UDLR");
            Thread.sleep(1000);
            Dimension size = driver.manage().window().getSize();
            TouchAction action = new TouchAction(driver);
            int starty = 0;
            int endy = 0;
            int startx = 0;
            switch (direction) {
                case "R":
                    starty = (int) (size.height * 0.50);
                    endy = (int) (size.width * 0.60);
                    startx = size.getWidth() / 2;
                    break;
                case "L":
                    starty = (int) (size.height * 0.50);
                    endy = (int) (size.width * 0.30);
                    startx = size.getWidth() / 2;
                    break;
                case "U":
                    starty = (int) (size.height * 0.80);
                    endy = (int) (size.height * 0.30);
                    startx = size.getWidth() / 2;
                    break;
                case "D":
                    starty = (int) (size.height * 0.30);
                    endy = (int) (size.height * 0.80);
                    startx = size.getWidth() / 2;
                    break;
            }
            action.press(PointOption.point(startx, starty)).waitAction(WaitOptions.waitOptions(Duration.ofSeconds(duration))).moveTo(PointOption.point(startx, endy)).release()
                    .perform();
        } catch (Exception e) {
            logger.info("Not Scrolled");
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + "\n" + ProjectConst.ELEMENTNOTFOUNDEXCEPTIONTXT.getMsg(), e);
        }
    }

    /**
     * Mobile scroll for using JavaScript
     *
     * @param driver
     * @param element
     */
    public static synchronized void jsMobileScroll(MobileDriver driver, MobileElement element) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        HashMap<String, String> scrollObject = new HashMap<String, String>();
        scrollObject.put("direction", "down");
        scrollObject.put("element", ((RemoteWebElement) element).getId());
        js.executeScript("mobile: scroll", scrollObject);
    }

    /**
     * Method to hide keyboard in mobile
     *
     * @param driver pass the driver
     */
    public static synchronized void hideKeyboard(MobileDriver driver) {
        try {
            logger.info("Hide the keyboard");
            driver.hideKeyboard();
        } catch (Exception e) {
            logger.error("Exception occured while hiding the Keyboard:");
        }
    }

    /**
     * Method to get element middle point
     *
     * @param element pass the element for which you need the middle point
     * @return a String
     */
    public static String getElementMiddlePoint(WebElement element) {
        int length = 0;
        int height;
        int middleY = 0;
        try {
            logger.info("Get element from Middle point");
            Point point = element.getLocation();
            length = element.getSize().getWidth();
            height = element.getSize().getHeight();
            int getY = point.getY();
            middleY = (int) (getY + height * 1.5) / 2;
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + ProjectConst.ELEMENTNOTFOUNDEXCEPTIONTXT, e);
        }
        return length + "" + "" + "|" + middleY + "";
    }

    /**
     * Method to clear data
     *
     * @param element Pass the element against which the data has to be cleared
     */
    public synchronized static void clearData(WebElement element) {
        try {
            logger.info("Clearing the log file");
            element.clear();
        } catch (Exception e) {
            logger.info("Error clearing data");
            throw e;
        }
    }

    public static synchronized String extractDigits(String src) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < src.length(); i++) {
            char c = src.charAt(i);
            if (Character.isDigit(c)) {
                builder.append(c);
            }
        }
        return builder.toString();
    }

    /**
     * Method to check element is not present for web
     *
     * @param elementXpath Pass the elements Xpath
     * @param elementName  Pass the element name
     * @param driver       Pass the driver
     */
    public static synchronized void checkElementNotPresent(String elementXpath, String elementName, RemoteWebDriver driver) {
        try {
            logger.info("Check for the element:" + elementName);
            if (!(driver.findElements(By.xpath(elementXpath)).size() > 0)) {
                getTest().get().pass(elementName + "Element is not present - successful", ExtentScreenCapture.captureSrceenPass("checkElementNotPresent", driver));
            } else {
                WebElement element = driver.findElement(By.xpath(elementXpath));
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "border: 5px solid red;");
                logger.info("### The Element is present -  unsuccessful");
                getTest().get().fail(elementName + "The Element is present -  unsuccessful", ExtentScreenCapture.captureSrceenFail("checkElementNotPresent", driver));
                js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "border: none;");
            }
        } catch (NoSuchElementException e) {
            logger.error("### Error occured while checking the element " + elementName);
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + " Error in checkElementNotPresent", e);
            getTest().get().fail("Error occured while checking the element ", ExtentScreenCapture.captureSrceenFail("checkForElement", driver));
            throw e;
        }
    }

    /**
     * Method used to customised the report while creating a label in test case id level
     *
     * @param applicationName pass application name
     * @param JiraID          pass jira id of the test case
     */
    public static void customisedReport(String applicationName, String JiraID) {
        m = MarkupHelper.createLabel("<a href=\"https://ytlcomms.jira.com/browse/" + JiraID + "\">" + JiraID + "</a>", ExtentColor.WHITE);
        getTest().get().info(m);
        String[][] data = {{applicationName, JiraID}};
        m = MarkupHelper.createTable(data);
        getTest().get().assignCategory(m.getMarkup());
    }

    public static synchronized boolean clickByXpathonNewWindow(WebElement elementToClick, String elementName, RemoteWebDriver driver) {
        boolean status = false;
        try {
            logger.info("Click by xpath on:" + elementName);
            if (System.getProperty("pmas").equalsIgnoreCase("true"))
                DriverFactory.getProxy().newHar(elementName);
            elementToClick.click();
            status = true;
        } catch (UnhandledAlertException e) {
            clickOnAlert("Ok", "Ok on alert", driver);
            getTest().get().pass(elementName + " Clicked Successfully", ExtentScreenCapture.captureSrceenPass(elementName, driver));
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + "\n" + ProjectConst.ELEMENTNOTFOUNDEXCEPTIONTXT.getMsg(), e);
            getTest().get().fail(elementName + " Click Unsuccessful", ExtentScreenCapture.captureSrceenFail(elementName, driver));
        }
        return status;
    }

    /**
     * To get the attribute details of the element
     *
     * @param element     pass the element
     * @param elementName pass the element name
     * @param attribute   get the attribute which we need to take
     * @param driver      pass the driver
     * @return returns the value
     */
    public static String getElementAttributeValue(WebElement element, String elementName, String attribute, RemoteWebDriver driver) {
        String status = "false";
        try {
            status = element.getAttribute(attribute);
        } catch (Exception e) {
            logger.error("Exception occured", e);
            status = "false";
        }
        return status;
    }

    /**
     * Extract the value of OTP
     *
     * @param accountType
     * @param source
     * @throws SQLException
     */
    public static synchronized void getOTPValue(String accountType, String source) throws SQLException {
        logger.info("Get OPT email message");
        String OTP;
        String yesId = storeVariable.get("WOM_YES_ID");
        JSONObject result;
        try {
            GetEmailMessage message = new GetEmailMessage();
            result = message.getemailmessage(yesId, "EMAIL_OTP_USER_JOURNEY", source);
            if (result != null && !result.get("Result").equals(null)) {
                logger.info("inside if 1104");
                JSONArray elements = result.getJSONArray("Result");
                JSONObject object = elements.getJSONObject(0);
                OTP = object.get("MESSAGE_KEY_VALUE").toString().split("OTP>")[1].replace("</", "");
                logger.info("OTP :" + OTP);
                storeVariable.put("TAC_OTP", OTP);
                getTest().get().pass("Got OTP Successfully");
            } else {
                logger.info("Checking OTP in Notification History");
                result = message.getemailmessagehistory(yesId, "EMAIL_OTP_USER_JOURNEY", source);
                if (result != null && !result.get("Result").equals(null)) {
                    JSONArray elements = result.getJSONArray("Result");
                    JSONObject object = elements.getJSONObject(0);
                    OTP = object.get("MESSAGE_KEY_VALUE").toString().split("OTP>")[1].replace("</", "");
                    logger.info(new StringBuilder("OTP: ").append(OTP));
                    storeVariable.put("TAC_OTP", OTP);
                    getTest().get().pass("Got OTP In Notification History");
                } else {
                    getTest().get().fail("Unbale to getOTP");
                }
            }
        } catch (Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "getOTP", e);
            throw new SQLException();
        }
    }

    public HashMap<String, String> getDetailsKarate() {
        HashMap<String, String> data = new HashMap<String, String>();
        StringBuffer formatSecurityId = new StringBuffer();
        StringBuffer formatYesId = new StringBuffer();
        String dateAndTime = "";
        String dataTime[] = null;
        Date date = new Date();
        dateAndTime = new Timestamp(date.getTime()).toString();
        dataTime = dateAndTime.split(" ");
        formatSecurityId.append("ca");
        formatSecurityId.append(dataTime[0].split("-")[2]);
        formatSecurityId.append(dataTime[0].split("-")[1]);
        formatSecurityId.append(dataTime[0].split("-")[0]);
        formatSecurityId.append(dataTime[1].split(":")[0]);
        formatSecurityId.append(dataTime[1].split(":")[1]);
        formatSecurityId.append(dataTime[1].split(":")[2].split("\\.")[0]);
        formatSecurityId.append(dataTime[1].split("\\.")[1]);
        data.put("customerAccountSecurityId", formatSecurityId.toString());
        logger.info(data);
        return data;
    }


    public enum ProjectConst {
        EXCEPTIONTEXT("**** Exception Occurred ****"),
        ELEMENTNOTFOUNDEXCEPTIONTXT("**** Element Not Found or Xpath String passed in null ****"),
        EXCEPTIONTEXTMETHOD("**** Exception Occurred in the Method ****"),
        VALUE(" ======> ");

        private String msg;

        ProjectConst(String s) {
            msg = s;
        }

        public String getMsg() {
            return msg;
        }
    }
}
