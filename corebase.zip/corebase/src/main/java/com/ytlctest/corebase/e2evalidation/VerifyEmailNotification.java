package com.ytlctest.corebase.e2evalidation;

import com.ytlctest.corebase.lib.ExtentScreenCapture;
import com.ytlctest.corebase.lib.MainUtil;
import com.ytlctest.corebase.lib.MainUtil.ProjectConst;
import com.ytlctest.corebase.lib.PropertyHelper;
import com.ytlctest.corebase.listener.ExtentTestNGITestListener;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

import static com.ytlctest.corebase.listener.ExtentTestNGITestListener.getTest;

public class VerifyEmailNotification {
    private static Logger logger = LogManager.getLogger(VerifyEmailNotification.class);
    ExtentTestNGITestListener ex = new ExtentTestNGITestListener();

    /**
     * This method is used to verify the notification received in gmail
     *
     * @param value  Pass the Yes ID to be searched
     * @param driver Pass the driver instance
     */
    public void emailNotification(String value, RemoteWebDriver driver) {
        ExtentTestNGITestListener.createNode("Email Notification");
        String data = value;
        try {
            String sqEmailUrl = PropertyHelper.getProperties("SQUIRREL_EMAIL_URL");
            String sqEmailUname = PropertyHelper.getProperties("SQUIRREL_EMAIL_UNAME").trim();
            String sqEmailPwd = PropertyHelper.getProperties("SQUIRREL_EMAIL_PWD").trim();
            /* Login to Yes Life Web */
            MainUtil.launchURL(sqEmailUrl, driver);
            driver.findElement(By.xpath("//input[@name='login_username']")).clear();
            driver.findElement(By.xpath("//input[@name='login_username']")).sendKeys(sqEmailUname);
            driver.findElement(By.xpath("//input[@name='secretkey']")).clear();
            driver.findElement(By.xpath("//input[@name='secretkey']")).sendKeys(sqEmailPwd);
            driver.findElement(By.xpath("//input[@value='Login']")).click();
            /* Navigate to SMS */
            Thread.sleep(5000L);
            driver.switchTo().frame("right");
            if (driver.findElement(By.linkText("Search")).isDisplayed()) {
                driver.findElement(By.linkText("Search")).click();
                logger.info("### Enter Search Text");
                Thread.sleep(2000);
                driver.findElement(By.xpath("//input[@name='what']")).clear();
                driver.findElement(By.xpath("//input[@name='what']")).sendKeys(data);
                logger.info("Order ID ======> {}", data);
                /* Search with Email id */
                Thread.sleep(2000);
                logger.info("### Select Where from list box");
                int flag = 0;
                if (data.toLowerCase().contains("@yes.my") || data.toUpperCase().contains("YOS")) {
                    new Select(driver.findElement(By.xpath("//select[@name='where']")))
                            .selectByVisibleText("Everywhere");
                    driver.findElement(By.xpath("//input[@name='submit']")).click();
                    flag = 1;
                } else if (data.equalsIgnoreCase("Please click on the following link to change your password")) {
                    new Select(driver.findElement(By.xpath("//select[@name='where']"))).selectByVisibleText("Body");
                    driver.findElement(By.xpath("//input[@name='submit']")).click();
                    driver.findElement(
                            By.xpath("//tr[last()]/td/b/a[contains(text(),'Reset Yes 4G Account Password')]")).click();
                    getTest().get().pass("Email Notification Found",
                            ExtentScreenCapture.captureSrceenPass("EmailNotificationPassed", driver));
                    driver.findElement(By.xpath("//a[contains(text(),'change password here')]")).click();
                    driver.findElement(By.xpath("//a[text()='Sign Out']")).click();
                    MainUtil.selectNewWindow(driver);
                } else if (data.equalsIgnoreCase("Your password has been changed")) {
                    new Select(driver.findElement(By.xpath("//select[@name='where']")))
                            .selectByVisibleText("Everywhere");
                    driver.findElement(By.xpath("//input[@name='submit']")).click();
                    driver.findElement(By.xpath("(//tr/td/b/a[contains(text(),'Your password has been changed')])[1]"))
                            .click();
                    getTest().get().pass("Email Notification Found",
                            ExtentScreenCapture.captureSrceenPass("EmailNotificationPassed", driver));
                } else if (data.contains("CON")) {
                    new Select(driver.findElement(By.xpath("//select[@name='where']")))
                            .selectByVisibleText("Everywhere");
                    driver.findElement(By.xpath("//input[@name='submit']")).click();
                    driver.findElement(By.xpath("(//tr/td/b/a[contains(text(),'Consignment Number for your order')])[1]"))
                            .click();
                    getTest().get().pass("Email Notification Found",
                            ExtentScreenCapture.captureSrceenPass("EmailNotificationPassed", driver));
                } else if (data.contains("Rewards Notification - Welcome")) {
                    new Select(driver.findElement(By.xpath("//select[@name='where']")))
                            .selectByVisibleText("Everywhere");
                    driver.findElement(By.xpath("//input[@name='submit']")).click();
                    driver.findElement(
                            By.xpath("(//tr/td/b/a[contains(text(),'Rewards Notification - Welcome')])[1]")).click();
                    getTest().get().pass("Email Notification Found",
                            ExtentScreenCapture.captureSrceenPass("EmailNotificationPassed", driver));
                } else {
                    new Select(driver.findElement(By.xpath("//select[@name='where']"))).selectByVisibleText("Body");
                    driver.findElement(By.xpath("//input[@name='submit']")).click();
                    driver.findElement(
                            By.xpath("//tr[last()]/td/b/a[contains(text(),'YCMS - Password change request')]")).click();
                    driver.findElement(By.xpath("//a[contains(text(),'Click here to reset password')]")).click();
                    driver.findElement(By.xpath("//a[text()='Sign Out']")).click();
                    MainUtil.selectNewWindow(driver);
                }
                if (driver.getPageSource().contains("No Messages Found")) {
                    logger.info("### Email notification not received");
                    getTest().get().fail("Email notification not received",
                            ExtentScreenCapture.captureSrceenFail("EmailNotificationFailed", driver));
                } else if (flag == 1) {
                    try {
                        String records = driver.findElement(By.xpath("//form[@name='FormMsgsINBOX']/table/tbody/tr[1]"))
                                .getText();
                        logger.info("Records Text: {}", records);
                        records = records.split("\\(")[1].split(" total")[0];
                        int totalRecords = Integer.parseInt(records);
                        logger.info("Total number of records ======> {}", totalRecords);
                        int index = 3;
                        for (int i = 1; i <= totalRecords; i++) {
                            if (driver.findElement(By.xpath(
                                    "//form[@name='FormMsgsINBOX']/table/tbody/tr[5]/td/table/tbody/tr/td/table/tbody/tr["
                                            + index + "]/td[5]"))
                                    .isDisplayed()) {
                                logger.info("Record found at ======> {}", i);
                                logger.info("The Email Notification sent sucessfully");
                                Thread.sleep(3000L);
                                if (MainUtil.storeVariable.get("CREATION_TYPE") == null
                                        || MainUtil.storeVariable.get("CREATION_TYPE") == null
                                        || MainUtil.storeVariable.get("CREATION_TYPE") == ""
                                        || MainUtil.storeVariable.get("CREATION_TYPE") == "") {
                                    if (driver.findElement(By.xpath("//a[contains(text(),'Yes 4G')]"))
                                            .isDisplayed()) {
                                        driver.findElement(By.xpath("//a[contains(text(),'Yes 4G')]")).click();
                                        Thread.sleep(1000L);
                                        getTest().get().pass("Email Notification Found", ExtentScreenCapture
                                                .captureSrceenPass("EmailNotificationPassed", driver));
                                    }
                                } else if (MainUtil.storeVariable.get("CREATION_TYPE")
                                        .equalsIgnoreCase("YOS_REG")) {
                                    driver.findElement(By.xpath("//a[contains(text(),'Y E S to Education')]"))
                                            .click();
                                    Thread.sleep(1000L);
                                    getTest().get().pass("Email Notification Found", ExtentScreenCapture
                                            .captureSrceenPass("EmailNotificationPassed", driver));

                                }
                                logger.info("Records found with the given Order ID ======> {}", data);
                                break;

                            } else {
                                logger.info("Record not found at: {}", i);
                                index = index + 2;
                            }
                        }
                        logger.info("Completed");
                        driver.findElement(By.xpath("//a[text()='Sign Out']")).click();
                    } catch (Exception E) {
                        logger.error("{} emailNotification {}", ProjectConst.EXCEPTIONTEXTMETHOD.getMsg(), E);
                        getTest().get().fail("Error Occured 1",
                                ExtentScreenCapture.captureSrceenFail("Error occured in emailNotification", driver));
                    }
                }
            } else {
                logger.info("### There is no search link found");
            }
        } catch (
                Exception e) {
            logger.error(ProjectConst.EXCEPTIONTEXTMETHOD.getMsg() + " " + "emailNotification", e);
            getTest().get().fail("Error Occured",
                    ExtentScreenCapture.captureSrceenFail("Error occured in emailNotification", driver));
        }
    }

}
