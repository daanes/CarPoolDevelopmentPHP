package com.ytlctest.corebase.listener;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.ytlctest.corebase.lib.PropertyHelper;
import com.ytlctest.corebase.reports.ExtentManager;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ExtentTestNGITestListener extends TestListenerAdapter {
    public static String USER_DIR = System.getProperty("user.dir");
    public static String table_id = System.getProperty("table_id");
    public static String htmlpassLocation;
    public static String htmlfailLocation;
    public static String htmlreportname;
    static String reportL;
    private static String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
    private static String reportDirectoryName = "extentreport" + dateName;
    public static File passLocation = new File("./" + reportDirectoryName + "/images/Pass");
    public static File failLocation = new File("./" + reportDirectoryName + "/images/Fail");
    private static ExtentReports extent;
    private static Logger logger = LogManager.getLogger(ExtentTestNGITestListener.class);
    private static ThreadLocal<ExtentTest> parentTest = new ThreadLocal<>();
    private static ThreadLocal<ExtentTest> test = new ThreadLocal<>();

    public ExtentTestNGITestListener() {
        if (!failLocation.exists()) {
            failLocation.mkdirs();
        }
        if (!passLocation.exists()) {
            passLocation.mkdirs();
        }
    }

    private static void getExtent() {
        if (extent == null) {
            if (System.getProperty("reporttype").equalsIgnoreCase("localr") || System.getProperty("reporttype").equalsIgnoreCase("klov")) {
                if (System.getProperty("reporttype").equalsIgnoreCase("klov")) {
                    htmlpassLocation = "./" + reportDirectoryName + "/images/Pass";
                    htmlfailLocation = "./" + reportDirectoryName + "/images/Fail";
                } else {
                    htmlpassLocation = "images/Pass";
                    htmlfailLocation = "images/Fail";
                }
                htmlreportname = reportDirectoryName + "/" + PropertyHelper.getProperties("REPORTNAME") + "_" + dateName + ".html";
                logger.info("{}/{}", USER_DIR, htmlreportname);
                if (System.getProperty("reporttype").equalsIgnoreCase("klov")) {
//                    extent = ExtentKlovManager.createInstance();
                } else {
                    extent = ExtentManager.createInstance(USER_DIR + "/" + htmlreportname);
                }
                extent.flush();
                reportL = "R";
                logger.info("USER DIRECTORY ISS----> {}", USER_DIR);
                if (System.getProperty("reporttype").equalsIgnoreCase("localr")) {
                    if (USER_DIR.toUpperCase().contains("YCMS_SANITY")) {
                        PropertyHelper.updateReportPathToOperationSanityTrigger("N", "YCMS_SANITY/" + htmlreportname, table_id);
                    } else if (USER_DIR.toUpperCase().contains("YCMS_REGRESSION")) {
                        PropertyHelper.updateReportPathToOperationSanityTrigger("N", "YCMS_REGRESSION/" + htmlreportname, table_id);
                    } else if (USER_DIR.toUpperCase().contains("YOS_SANITY")) {
                        PropertyHelper.updateReportPathToOperationSanityTrigger("N", "YOS_SANITY/" + htmlreportname, table_id);
                    } else if (USER_DIR.toUpperCase().contains("YOS_REGRESSION")) {
                        PropertyHelper.updateReportPathToOperationSanityTrigger("N", "YOS_REGRESSION/" + htmlreportname, table_id);
                    } else if (USER_DIR.toUpperCase().contains("MYYES4G_SANITY")) {
                        PropertyHelper.updateReportPathToOperationSanityTrigger("N", "MyYes4G_SANITY/" + htmlreportname, table_id);
                    } else if (USER_DIR.toUpperCase().contains("MYYES4G_REGRESSION")) {
                        PropertyHelper.updateReportPathToOperationSanityTrigger("N", "MyYes4G_REGRESSION/" + htmlreportname, table_id);
                    } else if (USER_DIR.toUpperCase().contains("SCM_SANITY")) {
                        PropertyHelper.updateReportPathToOperationSanityTrigger("N", "SCM_SANITY/" + htmlreportname, table_id);
                    } else if (USER_DIR.toUpperCase().contains("SCM_REGRESSION")) {
                        PropertyHelper.updateReportPathToOperationSanityTrigger("N", "SCM_REGRESSION/" + htmlreportname, table_id);
                    } else if (USER_DIR.toUpperCase().contains("YESMY_SANITY")) {
                        PropertyHelper.updateReportPathToOperationSanityTrigger("N", "YESMY_SANITY/" + htmlreportname, table_id);
                    } else if (USER_DIR.toUpperCase().contains("YESMY_REGRESSION")) {
                        PropertyHelper.updateReportPathToOperationSanityTrigger("N", "YESMY_REGRESSION/" + htmlreportname, table_id);
                    } else if (USER_DIR.toUpperCase().contains("YMCA_SANITY")) {
                        PropertyHelper.updateReportPathToOperationSanityTrigger("N", "YMCA_SANITY/" + htmlreportname, table_id);
                    } else if (USER_DIR.toUpperCase().contains("YMCA_REGRESSION")) {
                        PropertyHelper.updateReportPathToOperationSanityTrigger("N", "YMCA_REGRESSION/" + htmlreportname, table_id);
                    } else if (USER_DIR.toUpperCase().contains("OPERATIONS_SANITY")) {
                        PropertyHelper.updateReportPathToOperationSanityTrigger("N", "OPERATIONS_SANITY/" + htmlreportname, table_id);
                    } else if (USER_DIR.toUpperCase().contains("YCMS_ADMIN_SANITY")) {
                        PropertyHelper.updateReportPathToOperationSanityTrigger("N", "YCMS_ADMIN_SANITY/" + htmlreportname, table_id);
                    } else if (USER_DIR.toUpperCase().contains("YOS_ADMIN_SANITY")) {
                        PropertyHelper.updateReportPathToOperationSanityTrigger("N", "YOS_ADMIN_SANITY/" + htmlreportname, table_id);
                    } else if (USER_DIR.toUpperCase().contains("OTRS_SANITY")) {
                        PropertyHelper.updateReportPathToOperationSanityTrigger("N", "OTRS_SANITY/" + htmlreportname, table_id);
                    } else if (USER_DIR.toUpperCase().contains("SUGARCRM_SANITY")) {
                        PropertyHelper.updateReportPathToOperationSanityTrigger("N", "SUGARCRM_SANITY/" + htmlreportname, table_id);
                    } else if (USER_DIR.toUpperCase().contains("EPAY_SANITY")) {
                        PropertyHelper.updateReportPathToOperationSanityTrigger("N", "EPAY_SANITY/" + htmlreportname, table_id);
                    } else if (USER_DIR.toUpperCase().contains("CAL_PARTNER_SERVICE_SANITY")) {
                        PropertyHelper.updateReportPathToOperationSanityTrigger("N", "CAL_PARTNER_SERVICE_SANITY/" + htmlreportname, table_id);
                    } else if (USER_DIR.toUpperCase().contains("YES_COVERAGE_MAPS_SANITY")) {
                        PropertyHelper.updateReportPathToOperationSanityTrigger("N", "YES_COVERAGE_MAPS_SANITY/" + htmlreportname, table_id);
                    } else if (USER_DIR.toUpperCase().contains("USSP_MOBILE_AUTOMATION_SANITY")) {
                        PropertyHelper.updateReportPathToOperationSanityTrigger("N", "USSP_MOBILE_AUTOMATION_SANITY/" + htmlreportname, table_id);
                    } else if (USER_DIR.toUpperCase().contains("MNP_SANITY")) {
                        PropertyHelper.updateReportPathToOperationSanityTrigger("N", "MNP_SANITY/" + htmlreportname, table_id);
                    } else if (USER_DIR.toUpperCase().contains("USSP_PRODUCTION_SANITY")) {
                        PropertyHelper.updateReportPathToOperationSanityTrigger("N", "USSP_PRODUCTION_SANITY/" + htmlreportname, table_id);
                    } else if (USER_DIR.toUpperCase().contains("YOS_FREE_EDUCATION_SANITY")) {
                        PropertyHelper.updateReportPathToOperationSanityTrigger("N", "YOS_FREE_EDUCATION_SANITY/" + htmlreportname, table_id);
                    } else if (USER_DIR.toUpperCase().contains("ECMR_REGRESSION")) {
                        PropertyHelper.updateReportPathToOperationSanityTrigger("N", "ECMR_REGRESSION/" + htmlreportname, table_id);
                    } else if (USER_DIR.toUpperCase().contains("YOS_RNR_SANITY")) {
                        PropertyHelper.updateReportPathToOperationSanityTrigger("N", "YOS_RNR_SANITY/" + htmlreportname, table_id);
                    }
                }
            } else {
                htmlpassLocation = "./images/Pass";
                htmlfailLocation = "./images/Fail";
                htmlreportname = reportDirectoryName + "/" + PropertyHelper.getProperties("REPORTNAME") + "_" + dateName + ".html";
                logger.info("{}/{}", USER_DIR, htmlreportname);
                extent = ExtentManager.createInstance(USER_DIR + "/" + htmlreportname);
                extent.flush();
            }
        }
    }

    // Pass type: applcation|description|jiraid
    public static synchronized void createNode(String type) {
        // Markup m = MarkupHelper.createCodeBlock("Application:
        // "+type.split("\\|")[0]+"\nDescription:
        // "+type.split("\\|")[1]+""+"\nJIRA Id: "+type.split("\\|")[2]);
        // ExtentTest child = parentTest.get().createNode(m.getMarkup());
        ExtentTest child = parentTest.get().createNode(type);
        test.set(child);
    }

    public static ThreadLocal<ExtentTest> getParentTest() {
        return parentTest;
    }

    public static ThreadLocal<ExtentTest> getTest() {
        extent.flush();
        return test;
    }

    @Override
    public synchronized void onStart(ITestContext context) {
        getExtent();
        ExtentTest parent = extent.createTest(context.getName());
        parentTest.set(parent);
    }

    /*
     * @Override public synchronized void onTestSuccess(ITestResult result) {
     * test.get().pass("PASS", ExtentScreenCapture.captureSrceenPass(result)); }
     *
     *
     * @Override public synchronized void onTestFailure(ITestResult result) {
     * test.get().fail("FAIL", ExtentScreenCapture.captureSrceenFail(result)); }
     *
     * @Override public synchronized void onTestSkipped(ITestResult result) {
     * test.get().skip(result.getThrowable()); }
     */

    @Override
    public synchronized void onFinish(ITestContext context) {
        extent.flush();
    }

    @Override
    public synchronized void onTestStart(ITestResult result) {
        String code = "Application: " + result.getMethod().getDescription().split("\\|")[0] + "\nDescription: " + result.getMethod().getMethodName() + "\nJIRA Id: " + result.getMethod().getDescription().split("\\|")[1];
        Markup m = MarkupHelper.createCodeBlock(code);
        ExtentTest child = parentTest.get().createNode(m.getMarkup());
        // ExtentTest child = parentTest.get().createNode(result.getMethod().getMethodName() + "-" + result.getMethod().getDescription());
        test.set(child);
    }

    @Override
    public synchronized void onTestFailure(ITestResult result) {
        getTest().get().fail("" + result.getName());

    }

    @Override
    public synchronized void onTestSkipped(ITestResult result) {
        System.out.println("The name of the testcase Skipped is :" + result.getName());
        getTest().get().skip("" + result.getName());
    }

}
