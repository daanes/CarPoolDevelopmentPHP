package com.ytlctest.corebase.lib.firebase4j;

import com.google.gson.annotations.SerializedName;

public class OTPResult {

    private static final String name = "04062018123115";

    @SerializedName(name)
    public OTPMessage otpMessage;

}
