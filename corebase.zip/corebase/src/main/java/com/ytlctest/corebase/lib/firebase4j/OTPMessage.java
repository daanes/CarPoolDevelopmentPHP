package com.ytlctest.corebase.lib.firebase4j;

import java.io.Serializable;

public class OTPMessage implements Serializable {
    String originalMessage;
    String bank;
    String otp;
    String amount;
    String date;
    String time;

    public OTPMessage(String originalMessage, String bank, String otp, String amount, String date, String time) {
        this.originalMessage = originalMessage;
        this.bank = bank;
        this.otp = otp;
        this.amount = amount;
        this.date = date;
        this.time = time;
    }

    public OTPMessage(String originalMessage) {
        this.originalMessage = originalMessage;
    }

    public String getOriginalMessage() {
        return originalMessage;
    }

    public void setOriginalMessage(String originalMessage) {
        this.originalMessage = originalMessage;
    }

    public String getBank() {
        return bank;
    }

    public void setBank(String bank) {
        this.bank = bank;
    }

    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    @Override
    public String toString() {
        return "OTPMessage{" + "originalMessage='" + originalMessage + '\'' + ", bank='" + bank + '\'' + ", otp='" + otp
                + '\'' + ", amount='" + amount + '\'' + ", date='" + date + '\'' + ", time='" + time + '\'' + '}';
    }
}
